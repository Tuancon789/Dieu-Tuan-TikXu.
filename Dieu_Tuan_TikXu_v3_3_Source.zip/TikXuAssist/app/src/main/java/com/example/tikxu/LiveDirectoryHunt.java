package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v3.3 experimental accessibility-only directory browser.
 * No MediaProjection, screenshots, TikTok API or text uploads. It can ONLY
 * discover room/gift controls actually exposed in TikTok's accessibility tree.
 * Never guesses an unlabeled gift icon's coordinates.
 */
final class LiveDirectoryHunt {
    private enum Stage { FIND_LIST, ENTERING, SCAN_ROOM, OPENING, WAIT_TIMER, CLOSE_MODAL, RETURN_LIST, COOLDOWN }
    private static final long SCAN_MS = 15000L;
    private static final long COOLDOWN_MS = 15000L;
    private static final long UNKNOWN_TIMER_MS = 90000L;
    private static final long MAX_MODAL_MS = 10 * 60000L;
    private static final Pattern TIME = Pattern.compile("(?<!\\d)([0-5]?\\d)[:：]([0-5]\\d)(?!\\d)");
    private final TapAccessibilityService service;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<String> tried = new HashSet<>();
    private Stage stage = Stage.FIND_LIST;
    private boolean running, paused, tickScheduled, checkingLicense;
    private long enteredStage, lastLicenseCheck, timerDeadline, modalStarted;
    private int enteredRooms, scrolls, closeTries, backTries, openTries;
    private boolean timerObserved;
    private String status = "";
    private WindowManager wm;
    private View panel;
    private TextView statusView, pauseView;
    private int screenW, screenH;

    LiveDirectoryHunt(TapAccessibilityService service) {
        this.service = service;
        DisplayMetrics m = new DisplayMetrics();
        WindowManager window = (WindowManager)service.getSystemService(Context.WINDOW_SERVICE);
        window.getDefaultDisplay().getRealMetrics(m);
        screenW = m.widthPixels;
        screenH = m.heightPixels;
    }

    boolean isRunning() { return running; }

    void start() {
        if (running) { paused = false; show("Tiếp tục săn LIVE từ danh sách"); return; }
        if (AuthApi.token(service).isEmpty()) {
            android.widget.Toast.makeText(service, "Đăng nhập TikXu trước", android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        running = true;
        paused = false;
        stage = Stage.FIND_LIST;
        enteredStage = SystemClock.elapsedRealtime();
        enteredRooms = scrolls = 0;
        tried.clear();
        lastLicenseCheck = 0;
        buildOverlay();
        show("Mở danh sách LIVE trong TikTok để bắt đầu");
        schedule();
    }

    void stop(String reason) {
        running = false;
        paused = false;
        handler.removeCallbacks(tick);
        tickScheduled = false;
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Exception ignored) { }
            panel = null;
        }
        status = reason;
    }

    void onTikTokEvent() { if (running) schedule(); }

    private void schedule() {
        if (!running || tickScheduled) return;
        tickScheduled = true;
        handler.postDelayed(tick, 950);
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            tickScheduled = false;
            if (!running) return;
            try { onTick(); }
            catch (Exception e) { show("Không đọc được giao diện LIVE; đang thử lại"); }
            schedule();
        }
    };

    private void onTick() {
        if (paused) return;
        long now = SystemClock.elapsedRealtime();
        if (lastLicenseCheck == 0 || now - lastLicenseCheck > 300000L) {
            checkLicense();
        }
        AccessibilityNodeInfo root = service.getRootInActiveWindow();
        if (root == null || root.getPackageName() == null ||
            !TapAccessibilityService.isTikTokPackage(root.getPackageName().toString())) {
            show("Hãy mở TikTok và chọn danh sách LIVE");
            return;
        }

        switch (stage) {
            case FIND_LIST:
                browseDirectory(root, now);
                break;
            case ENTERING:
                if (now - enteredStage >= 3500L) {
                    if (directoryTiles(root).size() >= 2) {
                        stage(Stage.FIND_LIST, "Không vào được phòng, thử phòng khác");
                    } else {
                        stage(Stage.SCAN_ROOM, "Đã vào LIVE, tìm rương trong 15 giây");
                    }
                }
                break;
            case SCAN_ROOM:
                AccessibilityNodeInfo gift = locateGiftIcon(root);
                if (gift != null && click(gift)) {
                    openTries = 1;
                    stage(Stage.OPENING, "Đã chạm biểu tượng, xác nhận rương mở...");
                } else if (now - enteredStage >= SCAN_MS) {
                    stage(Stage.RETURN_LIST, "Không thấy rương, quay lại danh sách");
                    backTries = 0;
                    navigateBack();
                } else {
                    show("Tìm rương: " + ((SCAN_MS - (now - enteredStage)) / 1000) + " giây");
                }
                break;
            case OPENING:
                if (hasGiftModal(root)) {
                    timerObserved = false;
                    modalStarted = now;
                    timerDeadline = now + UNKNOWN_TIMER_MS;
                    stage(Stage.WAIT_TIMER, "Rương đã mở, đang chờ hết giờ");
                } else if (now - enteredStage > 4200L) {
                    // Retry once, but only if the same accessible gift control is visible.
                    AccessibilityNodeInfo retry = locateGiftIcon(root);
                    if (openTries < 2 && retry != null && click(retry)) {
                        openTries++;
                        enteredStage = now;
                        show("Thử mở rương lần 2");
                    } else {
                        stage(Stage.RETURN_LIST, "Không xác nhận được rương mở, về danh sách");
                        backTries = 0;
                        navigateBack();
                    }
                }
                break;
            case WAIT_TIMER:
                Integer seconds = modalTimer(root);
                if (seconds != null) {
                    if (!timerObserved) timerDeadline = now + seconds * 1000L + 2500L;
                    timerObserved = true;
                    if (seconds == 0 && now - modalStarted >= 2000L) {
                        closeTries = 0;
                        stage(Stage.CLOSE_MODAL, "Hết giờ, đóng rương");
                        break;
                    }
                    timerDeadline = Math.max(timerDeadline, now + seconds * 1000L + 2500L);
                    timerDeadline = Math.min(timerDeadline, modalStarted + MAX_MODAL_MS);
                    show(String.format(Locale.ROOT, "Giữ rương đến %02d:%02d", seconds / 60, seconds % 60));
                } else {
                    show(timerObserved ? "Đợi rương hoàn tất, không rời LIVE" :
                        "Không đọc được đồng hồ; giữ rương tối đa 90 giây");
                }
                if (now >= timerDeadline || now - modalStarted >= MAX_MODAL_MS) {
                    closeTries = 0;
                    stage(Stage.CLOSE_MODAL, "Đã hết thời gian chờ, đóng rương");
                }
                break;
            case CLOSE_MODAL:
                if (!hasGiftModal(root)) {
                    stage(Stage.RETURN_LIST, "Rương đã đóng, về danh sách LIVE");
                    backTries = 0;
                    navigateBack();
                } else if (now - enteredStage > 850L && closeTries < 3) {
                    AccessibilityNodeInfo close = locateClose(root);
                    if (close != null && click(close)) {
                        show("Đã bấm đóng cửa sổ rương");
                    } else {
                        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
                        show("Thử đóng rương bằng nút Quay lại");
                    }
                    closeTries++;
                    enteredStage = now;
                } else if (closeTries >= 3 && now - enteredStage > 2200L) {
                    stop("Không đóng được rương, dừng để tránh bấm loạn");
                }
                break;
            case RETURN_LIST:
                if (!directoryTiles(root).isEmpty()) {
                    stage(Stage.COOLDOWN, "Đã về danh sách; nghỉ 15 giây");
                } else if (now - enteredStage >= 5000L) {
                    if (backTries < 2) {
                        navigateBack();
                        enteredStage = now;
                    } else {
                        stop("Không tìm lại được danh sách LIVE, đã dừng an toàn");
                    }
                }
                break;
            case COOLDOWN:
                long remaining = COOLDOWN_MS - (now - enteredStage);
                if (remaining <= 0) stage(Stage.FIND_LIST, "Tìm phòng LIVE tiếp theo");
                else show("Chờ " + ((remaining + 999) / 1000) + " giây rồi tìm phòng tiếp");
                break;
        }
    }

    private void stage(Stage next, String message) {
        stage = next;
        enteredStage = SystemClock.elapsedRealtime();
        show(message);
    }

    private void browseDirectory(AccessibilityNodeInfo root, long now) {
        if (enteredRooms >= 50) {
            stop("Đã kiểm tra 50 phòng trong phiên; mở lại để tiếp tục");
            return;
        }
        List<AccessibilityNodeInfo> cards = directoryTiles(root);
        for (AccessibilityNodeInfo card : cards) {
            String key = cardKey(card);
            if (!tried.add(key)) continue;
            if (click(card)) {
                enteredRooms++;
                stage(Stage.ENTERING, "Đang vào phòng " + enteredRooms + "/50");
                return;
            }
        }
        if (cards.isEmpty() && scrolls == 0) {
            show("Chưa thấy thẻ phòng LIVE có thể đọc; hãy mở danh sách LIVE");
            return;
        }
        if (now - enteredStage < 2200L) return;
        AccessibilityNodeInfo list = findScrollable(root, 0);
        if (list != null && scrolls < 25 && list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            scrolls++;
            enteredStage = now;
            show("Tải thêm phòng trong danh sách LIVE (" + scrolls + "/25)");
        } else {
            stop("Hết phòng đọc được từ danh sách LIVE; không vuốt LIVE ngẫu nhiên");
        }
    }

    private String cardKey(AccessibilityNodeInfo node) {
        Rect r = bounds(node);
        String title = label(node);
        if (title.isEmpty()) {
            StringBuilder b = new StringBuilder();
            for (int i=0; i<Math.min(node.getChildCount(), 4); i++) {
                AccessibilityNodeInfo n = node.getChild(i);
                if (n!=null) b.append(label(n));
            }
            title = b.toString();
        }
        return title.substring(0, Math.min(title.length(), 80)) + ":" + r.centerX() + ":" + r.centerY() + ":" + scrolls;
    }

    private List<AccessibilityNodeInfo> directoryTiles(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collect(root, nodes, 0, 350);
        ArrayList<AccessibilityNodeInfo> cards = new ArrayList<>();
        Set<String> seenBounds = new HashSet<>();
        for (AccessibilityNodeInfo n : nodes) {
            String s = label(n);
            if (!isLiveBadge(s)) continue;
            AccessibilityNodeInfo candidate = clickableCard(n);
            if (candidate == null) continue;
            Rect r = bounds(candidate);
            String rectKey = r.flattenToString();
            if (seenBounds.add(rectKey)) cards.add(candidate);
        }
        return cards;
    }

    private static boolean isLiveBadge(String label) {
        return label.equals("live") || label.equals("truc tiep") ||
            label.equals("dang live") || label.equals("phat truc tiep") ||
            label.equals("live now") ||
            (label.startsWith("live ") && label.length() < 45) ||
            (label.contains(" dang live") && label.length() < 60);
    }

    private AccessibilityNodeInfo clickableCard(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i=0; i<5 && cur!=null; i++, cur=cur.getParent()) {
            Rect r = bounds(cur);
            if (cur.isClickable() && r.width() > screenW * 0.23 &&
                r.height() > screenH * 0.07 && r.height() < screenH * 0.75 &&
                r.centerY() > screenH * 0.17 && r.centerY() < screenH * 0.89)
                return cur;
        }
        return null;
    }

    private AccessibilityNodeInfo locateGiftIcon(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collect(root, nodes, 0, 350);
        for (AccessibilityNodeInfo n : nodes) {
            String s = label(n);
            boolean chest = s.contains("ruong bau") || s.contains("ruong xu") ||
                s.contains("lucky box") || s.contains("treasure box");
            boolean bag = s.contains("tui qua") || s.contains("gift bag");
            if ((!chest || !service.getSharedPreferences("tikxu", Context.MODE_PRIVATE)
                    .getBoolean("chest_enabled", true)) &&
                (!bag || !service.getSharedPreferences("tikxu", Context.MODE_PRIVATE)
                    .getBoolean("bag_enabled", true))) continue;
            if (s.length() > 55) continue; // Skip chat messages, long descriptions.
            Rect r = bounds(n);
            if (r.centerY() < screenH * 0.10 || r.centerY() > screenH * 0.45) continue;
            AccessibilityNodeInfo current = n;
            for (int up=0; up<3 && current!=null; up++,current=current.getParent()) {
                Rect cr = bounds(current);
                if (current.isClickable() && cr.width() < screenW * 0.60 &&
                    cr.height() < screenH * 0.36) return current;
            }
        }
        return null;
    }

    private boolean hasGiftModal(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collect(root, nodes, 0, 350);
        for (AccessibilityNodeInfo node : nodes) {
            String s = label(node);
            Rect r = bounds(node);
            if (r.centerY() < screenH * 0.27 || r.centerY() > screenH * 0.83 || s.length() > 42) continue;
            if (s.contains("ruong bau") || s.contains("ruong xu") ||
                s.contains("lucky box") || s.contains("tui qua") || s.contains("gift bag"))
                return true;
        }
        return false;
    }

    private Integer modalTimer(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collect(root, nodes, 0, 350);
        for (AccessibilityNodeInfo node : nodes) {
            Rect r = bounds(node);
            if (r.centerY() < screenH * 0.29 || r.centerY() > screenH * 0.83) continue;
            Matcher m = TIME.matcher(label(node));
            if (m.find()) {
                try { return Integer.parseInt(m.group(1))*60 + Integer.parseInt(m.group(2)); }
                catch (Exception ignored) { }
            }
        }
        return null;
    }

    private AccessibilityNodeInfo locateClose(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collect(root, nodes, 0, 350);
        for (AccessibilityNodeInfo node : nodes) {
            String s = label(node);
            if (!(s.equals("dong") || s.equals("close") || s.equals("close dialog") ||
                s.equals("x") || s.equals("dismiss"))) continue;
            Rect r = bounds(node);
            if (r.centerY() < screenH * 0.17 || r.centerY() > screenH * 0.84) continue;
            AccessibilityNodeInfo clickable = node;
            for (int i=0; i<2 && clickable!=null; i++,clickable=clickable.getParent()) {
                if (clickable.isClickable()) return clickable;
            }
        }
        return null;
    }

    private void navigateBack() {
        backTries++;
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
    }

    private boolean click(AccessibilityNodeInfo n) {
        if (n == null) return false;
        if (n.isClickable() && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        Rect r = bounds(n);
        if (r.isEmpty()) return false;
        return TapAccessibilityService.tapOnce(r.centerX(), r.centerY());
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 14) return null;
        if (node.isScrollable()) {
            Rect r = bounds(node);
            if (r.height() > screenH * 0.3 && r.width() > screenW * 0.45) return node;
        }
        for (int i=0; i<node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findScrollable(node.getChild(i), depth+1);
            if (found != null) return found;
        }
        return null;
    }

    private static void collect(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out,
                                int depth, int max) {
        if (n == null || depth > 16 || out.size() >= max) return;
        out.add(n);
        for (int i=0; i<n.getChildCount() && out.size()<max; i++)
            collect(n.getChild(i), out, depth+1, max);
    }

    private static Rect bounds(AccessibilityNodeInfo node) {
        Rect r = new Rect();
        if (node != null) node.getBoundsInScreen(r);
        return r;
    }

    private static String label(AccessibilityNodeInfo node) {
        if (node == null) return "";
        CharSequence text = node.getText();
        CharSequence description = node.getContentDescription();
        String t = text != null ? text.toString() : "";
        String d = description != null ? description.toString() : "";
        String value = t.equals(d) ? t : (t + " " + d);
        if (value.length() > 250) value = value.substring(0, 250);
        return Normalizer.normalize(value.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").replace('đ', 'd').replaceAll("\\s+", " ").trim();
    }

    private void show(String newStatus) {
        if (!newStatus.equals(status)) {
            status = newStatus;
            if (statusView != null) statusView.setText("🔎 TikXu v3.3\n" + status);
        }
    }

    private int dp(float x) { return (int)(x * service.getResources().getDisplayMetrics().density + .5f); }

    private TextView button(String text) {
        TextView v = new TextView(service);
        v.setText(text);
        v.setTextSize(13);
        v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(8), dp(10), dp(8));
        return v;
    }

    private void buildOverlay() {
        try {
            wm = (WindowManager)service.getSystemService(Context.WINDOW_SERVICE);
            LinearLayout outer = new LinearLayout(service);
            outer.setOrientation(LinearLayout.VERTICAL);
            outer.setPadding(dp(12), dp(10), dp(12), dp(10));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xee111d3c);
            bg.setCornerRadius(dp(13));
            bg.setStroke(dp(1), 0xff6bcfe0);
            outer.setBackground(bg);
            statusView = button("🔎 TikXu v3.3\nĐang chuẩn bị...");
            statusView.setGravity(Gravity.LEFT);
            outer.addView(statusView);
            LinearLayout controls = new LinearLayout(service);
            pauseView = button("⏸ Tạm dừng");
            pauseView.setOnClickListener(v -> {
                paused = !paused;
                pauseView.setText(paused ? "▶ Tiếp tục" : "⏸ Tạm dừng");
                if (paused) show("Đã tạm dừng theo yêu cầu");
                else show("Đang tiếp tục");
            });
            TextView stopView = button("■ Dừng");
            stopView.setOnClickListener(v -> stop("Đã dừng"));
            controls.addView(pauseView, new LinearLayout.LayoutParams(0, dp(43), 1));
            controls.addView(stopView, new LinearLayout.LayoutParams(0, dp(43), 1));
            outer.addView(controls);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                dp(244), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.BOTTOM | Gravity.END;
            params.x = dp(8);
            params.y = dp(65);
            wm.addView(outer, params);
            panel = outer;
        } catch (Exception e) {
            android.widget.Toast.makeText(service,
                "Không hiển thị được bảng nổi Trợ năng", android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void checkLicense() {
        if (checkingLicense) return;
        checkingLicense = true;
        lastLicenseCheck = SystemClock.elapsedRealtime();
        new Thread(() -> {
            String error = null;
            try {
                JSONObject me = AuthApi.request(service, "GET", "/v1/me", null, true);
                if (me.optBoolean("emergency_stop")) error = "ADMIN đã dừng hệ thống";
            } catch (Exception e) { error = "Hết phiên đăng nhập hoặc lỗi mạng: " + e.getMessage(); }
            final String reason = error;
            handler.post(() -> {
                checkingLicense = false;
                if (running && reason != null) stop(reason);
            });
        }, "TikXu-v33-license").start();
    }
}

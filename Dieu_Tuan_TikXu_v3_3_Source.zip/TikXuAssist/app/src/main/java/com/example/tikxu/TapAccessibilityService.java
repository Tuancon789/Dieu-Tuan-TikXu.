package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

/**
 * Optional v3.3 directory hunt reads ONLY TikTok's accessible node tree after
 * the user activates it. The legacy tap and swipe helpers remain available for
 * the separate legacy screen-capture mode.
 */
public class TapAccessibilityService extends AccessibilityService {
    private static volatile TapAccessibilityService live;
    private static volatile String foregroundPackage = "";
    private LiveDirectoryHunt directoryHunt;

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        live = this;
        directoryHunt = new LiveDirectoryHunt(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (isTikTokPackage(event.getPackageName().toString())) {
            foregroundPackage = event.getPackageName().toString();
            if (directoryHunt != null) directoryHunt.onTikTokEvent();
        }
        int type = event.getEventType();
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            String pkg = event.getPackageName().toString();
            // Our non-focusable overlay should not replace the foreground app.
            if (!pkg.equals(getPackageName()) && !pkg.equals("android") &&
                !pkg.equals("com.android.systemui")) {
                foregroundPackage = pkg;
            }
        }
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (directoryHunt != null) directoryHunt.stop("Trợ năng đã tắt");
        if (live == this) live = null;
        foregroundPackage = "";
        super.onDestroy();
    }

    public static boolean isReady() { return live != null; }

    public static boolean isDirectoryHunting() {
        TapAccessibilityService current = live;
        return current != null && current.directoryHunt != null && current.directoryHunt.isRunning();
    }

    public static boolean startDirectoryHunt() {
        TapAccessibilityService current = live;
        if (current == null || current.directoryHunt == null) return false;
        current.directoryHunt.start();
        return current.directoryHunt.isRunning();
    }

    public static void stopDirectoryHunt() {
        TapAccessibilityService current = live;
        if (current != null && current.directoryHunt != null)
            current.directoryHunt.stop("Đã dừng theo yêu cầu");
    }

    static boolean isTikTokPackage(String pkg) {
        return "com.zhiliaoapp.musically".equals(pkg) ||
               "com.ss.android.ugc.trill".equals(pkg);
    }

    public static boolean isTikTokForeground() {
        String pkg = foregroundPackage;
        return isTikTokPackage(pkg);
    }

    public static boolean tapOnce(int x, int y) {
        TapAccessibilityService service = live;
        if (service == null || !isTikTokForeground() || Build.VERSION.SDK_INT < 24) return false;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, 90)).build();
        return service.dispatchGesture(gesture, null, null);
    }
    /** User-enabled LIVE browsing: one controlled upward swipe, never more than once
     * per request. CaptureService sets the delay/cap; accessibility only dispatches.
     */
    public static boolean swipeToNextLive() {
        TapAccessibilityService service=live;
        if (service==null || !isTikTokForeground() || Build.VERSION.SDK_INT<24) return false;
        WindowManager wm=(WindowManager)service.getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm=new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        int x=dm.widthPixels/2;
        Path p=new Path();
        p.moveTo(x,dm.heightPixels*0.77f);
        p.lineTo(x,dm.heightPixels*0.32f);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,390)).build();
        return service.dispatchGesture(g,null,null);
    }
}

package com.example.tikxu;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Server-backed login: ADMIN/USER roles and expiry are enforced on the backend. */
public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 111;
    private final int BG = 0xff0a1023, PANEL = 0xff162140, CYAN = 0xff49dfeb;
    private SharedPreferences prefs;
    private TextView status;
    private boolean unlocked = false;
    private boolean autoRecordOnConsent = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tikxu", MODE_PRIVATE);
        showLogin();
    }

    /** Reuse the user's own photo behind a dark scrim on the login and dashboard screens. */
    private LinearLayout page() {
        FrameLayout frame = new FrameLayout(this);
        ImageView backgroundPhoto = new ImageView(this);
        backgroundPhoto.setImageResource(R.drawable.tuan_photo);
        backgroundPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(backgroundPhoto, new FrameLayout.LayoutParams(-1, -1));

        View tint = new View(this);
        tint.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            (prefs.getBoolean("theme_neon",true) ?
                new int[] {0xd20a0820, 0x930a0c26, 0xee070a1b} :
                new int[] {0xeb080b15, 0xd0091023, 0xf5080b15})));
        frame.addView(tint, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(32), dp(22), dp(30));
        scroller.addView(root);
        frame.addView(scroller, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        return root;
    }

    private void showLogin() {
        unlocked = false;
        status = null;
        LinearLayout root = page();
        space(root, 25);
        root.addView(label("✦  ĐIỂU TUẤN  •  TikXu v3.3", 16, CYAN, true));
        space(root, 30);
        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.tuan_avatar);
        root.addView(avatar, new LinearLayout.LayoutParams(dp(88),dp(88)));
        space(root, 22);
        root.addView(label("Đăng nhập", 30, Color.WHITE, true));
        root.addView(label("Tài khoản ADMIN hoặc tài khoản được cấp hạn", 14, 0xffb9c9e8, false));
        space(root, 18);
        LinearLayout card = card(); root.addView(card);
        card.addView(label("TÊN ĐĂNG NHẬP", 12, CYAN, true));
        EditText user = entry("Ví dụ: ADM", false);
        card.addView(user, new LinearLayout.LayoutParams(-1,dp(54)));
        space(card, 10);
        card.addView(label("MẬT KHẨU", 12, CYAN, true));
        EditText password = entry("••••••••", true);
        card.addView(password, new LinearLayout.LayoutParams(-1,dp(54)));
        space(card, 15);
        card.addView(label("MÁY CHỦ XÁC THỰC HTTPS", 12, CYAN, true));
        EditText server = entry("https://ten-may-chu.workers.dev", false);
        server.setSingleLine(true);
        server.setText(AuthApi.apiUrl(this));
        card.addView(server, new LinearLayout.LayoutParams(-1,dp(54)));
        space(card, 6);
        card.addView(label("Nhập một lần địa chỉ máy chủ của ADMIN. Không điền mật khẩu Gmail hay TikTok.",
            11,0xffaab9d5,false));
        space(card, 12);
        TextView error = label("", 13, 0xffff9eac, false);
        card.addView(error);
        Button unlock = action("ĐĂNG NHẬP  →",true);
        card.addView(unlock,buttonParams());
        unlock.setOnClickListener(v -> {
            String username=user.getText().toString().trim();
            String secret=password.getText().toString();
            String url=server.getText().toString().trim();
            if(username.length()<3 || secret.isEmpty() || !url.startsWith("https://")) {
                error.setText("Nhập tài khoản, mật khẩu và máy chủ HTTPS."); return;
            }
            AuthApi.setApiUrl(this,url);
            unlock.setEnabled(false); error.setText("Đang xác minh với máy chủ…");
            new Thread(() -> {
                try {
                    JSONObject payload = new JSONObject().put("username",username).put("password",secret);
                    JSONObject result=AuthApi.request(this,"POST","/v1/login",payload,false);
                    AuthApi.saveLogin(this,result);
                    getSharedPreferences("tikxu_auth",MODE_PRIVATE).edit().putString("notice",result.optString("notice","")).apply();
                    runOnUiThread(() -> {unlocked=true; showDashboard();});
                } catch (Exception e) {
                    runOnUiThread(() -> {error.setText("Không đăng nhập được: "+e.getMessage());unlock.setEnabled(true);password.setText("");});
                }
            },"TikXu-Auth").start();
        });
        space(root, 15);
        root.addView(label("Mã thường mặc định 45 ngày. ADMIN quản lý thời hạn trên máy chủ.",
            12,0xffaab9d5,false));
        root.addView(label("Không có máy chủ thì không thể đăng nhập; không có mật khẩu ADMIN trong APK.",
            12,0xffffc3ab,false));
    }
    private EditText entry(String hint,boolean secret) {
        EditText e=new EditText(this);
        e.setSingleLine(true);e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xff8b9dbb);e.setHint(hint);e.setTextSize(16);
        e.setInputType(secret ? (InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD)
            : InputType.TYPE_CLASS_TEXT);
        if(secret) {
            e.setTransformationMethod(PasswordTransformationMethod.getInstance());
            e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
            e.setSaveEnabled(false);
        }
        e.setPadding(dp(14),0,dp(14),0);
        e.setBackground(gradient(0xff111a31,0xff172442,dp(14),0xff385075));
        return e;
    }

    private void showDashboard() {
        LinearLayout root = page();
        root.addView(label("✦  ĐIỂU TUẤN     /     LIVE ASSIST", 12, CYAN, true));
        space(root, 13);
        root.addView(label("TikXu Control   ✦", 32, Color.WHITE, true));
        root.addView(label("Rương Báu  •  Túi quà  •  Bảng nổi thông minh",
            14, 0xffb9c9e8, false));
        space(root, 12);
        root.addView(label("◉  Đăng nhập: "+AuthApi.username(this)+
            (AuthApi.isAdmin(this)?" • QUẢN TRỊ VIÊN":" • TÀI KHOẢN CÓ HẠN"),
            13,0xff6bf0c4,true));
        if(!AuthApi.isAdmin(this)) {
            long expires=getSharedPreferences("tikxu_auth",MODE_PRIVATE).getLong("expires_at",0);
            if(expires>0) {
                SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.forLanguageTag("vi-VN"));
                format.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
                root.addView(label("Hết hạn: "+format.format(new Date(expires)),13,0xffffd48d,false));
            }
        } else {
            space(root, 8);
            Button management=action("👑  QUẢN TRỊ ADMIN  •  TÀI KHOẢN",true);
            root.addView(management,buttonParams());
            management.setOnClickListener(v->startActivity(new Intent(this,AdminActivity.class)));
        }
        space(root, 10);
        String notice=getSharedPreferences("tikxu_auth",MODE_PRIVATE).getString("notice","");
        if(!notice.isEmpty()) root.addView(label("📣  THÔNG BÁO ADMIN: "+notice,12,0xffffd18e,false));
        space(root, 18);

        LinearLayout statusCard = card();
        root.addView(statusCard);
        statusCard.addView(label("●  TRẠNG THÁI HỆ THỐNG", 12, 0xff68f0bc, true));
        space(statusCard, 10);
        status = label("Đang kiểm tra quyền...", 14, Color.WHITE, false);
        statusCard.addView(status);
        space(statusCard, 11);
        statusCard.addView(label("📍  Tìm biểu tượng + đọc đồng hồ ngay trên LIVE",
            13, 0xffb4cbe8, false));
        space(root, 16);

        root.addView(label("QUYỀN ỨNG DỤNG", 12, CYAN, true));
        space(root, 9);
        Button overlay = action("①  Cấp quyền hiển thị bảng nổi", false);
        root.addView(overlay, buttonParams());
        overlay.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName()))));
        Button access = action("②  Bật Trợ năng (BẮT BUỘC cho v3.3)", false);
        root.addView(access, buttonParams());
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        if (Build.VERSION.SDK_INT >= 33) {
            Button noticeBtn = action("③  Cho phép thông báo", false);
            root.addView(noticeBtn, buttonParams());
            noticeBtn.setOnClickListener(v -> {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 10);
            });
        }
        space(root, 17);
        root.addView(label("🔎  SĂN LIVE TỪ DANH SÁCH  •  v3.3 THỬ NGHIỆM", 13, CYAN, true));
        space(root, 8);
        root.addView(label("Không cần ghi màn hình. Chỉ đọc nút/thẻ phòng LIVE qua Trợ năng. " +
            "Trước khi bắt đầu, hãy vào TikTok rồi mở danh sách LIVE; " +
            "nếu TikTok ẩn nhãn rương thì app sẽ bỏ qua phòng đó.",
            13, 0xffb9c9e8, false));
        Button directoryStart = action("▶  SĂN PHÒNG TỪ DANH SÁCH LIVE", true);
        root.addView(directoryStart, buttonParams());
        directoryStart.setOnClickListener(v -> startDirectoryHunt());
        Button directoryStop = action("■  DỪNG SĂN LIVE v3.3", false);
        root.addView(directoryStop, buttonParams());
        directoryStop.setOnClickListener(v -> {
            TapAccessibilityService.stopDirectoryHunt();
            if(status!=null) status.setText("Đã dừng săn LIVE v3.3.");
        });
        root.addView(label("Luồng v3.3: chọn phòng từ danh sách → xem 15 giây → mở rương nếu thấy " +
            "nút → giữ rương đến khi hết giờ → đóng → quay lại danh sách → nghỉ 15 giây. " +
            "Không tự đăng bình luận, chia sẻ hay gửi quà.", 12, 0xffffc3ab, false));
        space(root, 17);
        root.addView(label("⚡  TÙY CHỌN RƯƠNG / TÍNH NĂNG CŨ", 13, CYAN, true));
        space(root, 8);
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actionRow);
        Button chestMode = action("🪙 Nhặt rương", true);
        Button bagMode = action("🎁 Nhặt túi", true);
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, dp(64), 1);
        left.rightMargin=dp(7);
        actionRow.addView(chestMode,left);
        actionRow.addView(bagMode,new LinearLayout.LayoutParams(0,dp(64),1));
        chestMode.setOnClickListener(v -> {
            boolean enabled = !prefs.getBoolean("chest_enabled",true);
            prefs.edit().putBoolean("chest_enabled",enabled).apply();
            chestMode.setText(enabled?"🪙 Rương: BẬT":"🪙 Rương: TẮT");
        });
        bagMode.setOnClickListener(v -> {
            boolean enabled = !prefs.getBoolean("bag_enabled",true);
            prefs.edit().putBoolean("bag_enabled",enabled).apply();
            bagMode.setText(enabled?"🎁 Túi: BẬT":"🎁 Túi: TẮT");
        });
        chestMode.setText(prefs.getBoolean("chest_enabled",true)?"🪙 Rương: BẬT":"🪙 Rương: TẮT");
        bagMode.setText(prefs.getBoolean("bag_enabled",true)?"🎁 Túi: BẬT":"🎁 Túi: TẮT");
        Button hunt = action("↕  Vuốt chuyển LIVE kiểu cũ (không khuyên dùng)", false);
        root.addView(hunt,buttonParams());
        hunt.setText(prefs.getBoolean("auto_swipe",false)?"↕ Vuốt LIVE cũ: BẬT":"↕ Vuốt LIVE cũ: TẮT");
        hunt.setOnClickListener(v->{
            boolean e=!prefs.getBoolean("auto_swipe",false);
            prefs.edit().putBoolean("auto_swipe",e).apply();
            hunt.setText(e?"↕ Vuốt LIVE cũ: BẬT":"↕ Vuốt LIVE cũ: TẮT");
        });
        space(root, 13);
        LinearLayout modeCard = card();
        root.addView(modeCard);
        modeCard.addView(label("✧  CHẾ ĐỘ NHẬN DIỆN", 14, Color.WHITE, true));
        space(modeCard, 8);
        addToggle(modeCard, "Tự mở biểu tượng (đang thử nghiệm)", "auto_open", false);
        addToggle(modeCard, "Thử tự bấm nhận khi đủ điều kiện", "auto_tap", false);
        space(modeCard, 8);
        modeCard.addView(label("⚠ Chỉ thử nhận diện khi TikTok đang mở. Không tự đăng bình luận, gửi link, tham gia Fan Club hoặc bấm Gửi/Nạp. Nhận diện màu/OCR có thể sai; tự bấm có thể bị giới hạn tài khoản.",
            12, 0xffffc3ab, false));
        space(root, 17);
        root.addView(label("🎥  QUAY MÀN HÌNH RIÊNG", 13, CYAN, true));
        space(root,8);
        LinearLayout recordCard = card();
        root.addView(recordCard);
        recordCard.addView(label("Quay MP4 trong app, dùng chung quyền màn hình với quét rương.",
            13, Color.WHITE, false));
        recordCard.addView(label("Video không có âm thanh • lưu vào Movies/TikXu • ~8 FPS. " +
            "Nội dung TikTok được bảo vệ vẫn có thể đen; không thể vượt chặn.",
            12, 0xffb4cbe8, false));
        Button recordingToggle=action("⏺  BẮT ĐẦU QUAY VIDEO", true);
        root.addView(recordingToggle,buttonParams());
        recordingToggle.setOnClickListener(v -> {
            if (CaptureService.activeCapture) {
                Intent command=new Intent(this,CaptureService.class);
                command.setAction(CaptureService.ACTION_RECORD_TOGGLE);
                startService(command);
                status.setText("Đã gửi lệnh bật/tắt quay. Xem trạng thái trên bảng nổi.");
            } else {
                autoRecordOnConsent=true;
                startCapture();
            }
        });
        Button start = action("▶  QUÉT KIỂU CŨ (cần ghi màn hình)", true);
        root.addView(start, buttonParams());
        start.setOnClickListener(v -> { autoRecordOnConsent=false; startCapture(); });
        Button stop = action("■  DỪNG QUÉT", false);
        root.addView(stop, buttonParams());
        stop.setOnClickListener(v -> { stopService(new Intent(this, CaptureService.class));
            if (status != null) status.setText("Đã dừng quét màn hình."); });
        space(root, 13);
        root.addView(label("Cách dùng: bật quyền → Bắt đầu quét → cho phép chia sẻ TOÀN BỘ màn hình → mở TikTok LIVE. " +
            "Ứng dụng sẽ thử phát hiện bộ đếm ở góc trên. Tính năng phụ thuộc giao diện TikTok, không đảm bảo nhận xu.",
            13, 0xff9fb5d1, false));
        space(root, 14);
        root.addView(label("KẾT NỐI VÀ BẢO MẬT", 12, CYAN, true));
        space(root, 8);
        Button social = action("♪  TIKTOK CỦA ĐIỂU TUẤN   ↗", true);
        root.addView(social,buttonParams());
        social.setOnClickListener(v->{
            Intent link=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@tuan203dnbp93"));
            try { startActivity(link); } catch(Exception e) {
                if(status!=null)status.setText("Chưa có ứng dụng mở liên kết TikTok.");
            }
        });
        space(root, 12);
        Button lock = action("🔒  KHÓA ỨNG DỤNG", false);
        root.addView(lock, buttonParams());
        lock.setOnClickListener(v -> {
            stopService(new Intent(this,CaptureService.class));
            TapAccessibilityService.stopDirectoryHunt();
            new Thread(() -> {
                try {AuthApi.request(this,"POST","/v1/logout",new JSONObject(),true);} catch(Exception ignored){}
                AuthApi.clear(this);
                runOnUiThread(this::showLogin);
            },"TikXu-Logout").start();
        });
        refreshStatus();
    }

    private void addToggle(LinearLayout parent, String name, String pref, boolean defaultValue) {
        CheckBox toggle = new CheckBox(this);
        toggle.setText(name);
        toggle.setTextColor(Color.WHITE);
        toggle.setTextSize(13);
        toggle.setButtonTintList(android.content.res.ColorStateList.valueOf(CYAN));
        toggle.setChecked(prefs.getBoolean(pref, defaultValue));
        toggle.setOnCheckedChangeListener((button, value) -> prefs.edit().putBoolean(pref, value).apply());
        parent.addView(toggle, new LinearLayout.LayoutParams(-1, dp(49)));
    }

    private void startDirectoryHunt() {
        if (!unlocked) return;
        if (!TapAccessibilityService.isReady()) {
            if (status != null) status.setText("Bật Trợ năng ĐIỂU TUẤN • TikXu trước!");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        if (TapAccessibilityService.isDirectoryHunting()) {
            if (status != null) status.setText("v3.3 đang săn LIVE, hãy mở danh sách LIVE trong TikTok.");
            return;
        }
        if (status != null) status.setText("Đang kiểm tra tài khoản trước khi săn LIVE v3.3...");
        new Thread(() -> {
            try {
                JSONObject me = AuthApi.request(this, "GET", "/v1/me", null, true);
                if (me.optBoolean("emergency_stop"))
                    throw new IllegalStateException("ADMIN đã dừng hệ thống");
                runOnUiThread(() -> {
                    if (!unlocked) return;
                    // Old screen-capture runner must not swipe a LIVE under v3.3.
                    prefs.edit().putBoolean("auto_swipe",false).apply();
                    stopService(new Intent(this,CaptureService.class));
                    if (TapAccessibilityService.startDirectoryHunt()) {
                        if (status != null) status.setText("Đã bật săn LIVE v3.3. Mở TikTok → danh sách LIVE.");
                        openTikTok();
                    } else if (status != null) {
                        status.setText("Trợ năng chưa sẵn sàng; tắt rồi bật lại Trợ năng TikXu.");
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (status != null) status.setText("Không thể săn LIVE: " + e.getMessage());
                });
            }
        }, "TikXu-v33-license-check").start();
    }

    private void openTikTok() {
        Intent i = getPackageManager().getLaunchIntentForPackage("com.zhiliaoapp.musically");
        if (i == null) i = getPackageManager().getLaunchIntentForPackage("com.ss.android.ugc.trill");
        if (i != null) {
            try { startActivity(i); } catch (Exception ignored) { }
        }
    }

    private void startCapture() {
        if (!unlocked) return;
        TapAccessibilityService.stopDirectoryHunt();
        if (!Settings.canDrawOverlays(this)) { status.setText("Hãy bật quyền hiển thị nổi trước!"); return; }
        if ((prefs.getBoolean("auto_open", false) || prefs.getBoolean("auto_tap", false)) &&
            !TapAccessibilityService.isReady()) {
            status.setText("Chưa bật Trợ năng. Vẫn có thể quét và cảnh báo, nhưng không tự bấm.");
        }
        if (status != null) status.setText("Đang kiểm tra hạn và quyền truy cập trên máy chủ…");
        new Thread(() -> {
            try {
                JSONObject me=AuthApi.request(this,"GET","/v1/me",null,true);
                if(me.optBoolean("emergency_stop")) throw new IllegalStateException("ADMIN đã tạm dừng toàn hệ thống");
                runOnUiThread(() -> {
                    if (!unlocked) return;
                    MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
                    startActivityForResult(manager.createScreenCaptureIntent(),CAPTURE_REQUEST);
                });
            } catch(Exception e) {
                runOnUiThread(() -> {
                    if(status!=null)status.setText("Không được quét: "+e.getMessage());
                });
            }
        },"TikXu-License-Check").start();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != CAPTURE_REQUEST || !unlocked) return;
        if (result != RESULT_OK || data == null) {
            autoRecordOnConsent=false;
            status.setText("Chưa cấp quyền chia sẻ màn hình."); return;
        }
        Intent i = new Intent(this, CaptureService.class);
        i.setAction(CaptureService.ACTION_START);
        i.putExtra(CaptureService.EXTRA_RESULT_CODE, result);
        i.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
        i.putExtra(CaptureService.EXTRA_AUTO_RECORD,autoRecordOnConsent);
        autoRecordOnConsent=false;
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Đang khởi động. Hãy chuyển sang TikTok LIVE.");
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }
    private void refreshStatus() {
        if (status == null) return;
        status.setText("Bảng nổi: " + (Settings.canDrawOverlays(this) ? "✓ BẬT" : "✕ CHƯA BẬT") +
            "   •   Trợ năng: " + (TapAccessibilityService.isReady() ? "✓ BẬT" : "✕ CHƯA BẬT"));
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(20), dp(18), dp(20));
        box.setBackground(gradient(0xff182443, 0xff121d38, dp(20), 0xff486499));
        return box;
    }
    private Button action(String text, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(text);
        b.setTextSize(14); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setBackground(primary ? gradient(0xff247feb, 0xff754ae7, dp(14), CYAN)
            : gradient(0xff1c2d50, 0xff18233e, dp(14), 0xff385781));
        return b;
    }
    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(53));
        p.bottomMargin = dp(9); return p;
    }
    private GradientDrawable gradient(int a, int b, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {a, b});
        g.setCornerRadius(radius);
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void space(LinearLayout p, int n) { p.addView(new View(this), new LinearLayout.LayoutParams(1, dp(n))); }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
}

# 3.6.3
Sửa nhận nhầm chat chứa Rương Báu + chữ Xu của bảng nổi thành cửa sổ rương.
Tự quay về quét icon sau 12 giây nếu bảng chưa mở và vẫn xác nhận ở LIVE.
Xóa trạng thái rương cũ trước khi tìm rương tiếp theo.
Giữ bản sửa đồng hồ và Mở/Nhận của 3.6.2.
Chưa build APK hoặc kiểm thử trên điện thoại; cần chạy GitHub Actions.

# ĐIỂU TUẤN • TikXu v3.5 — bản thử nghiệm

Bản này cập nhật **ứng dụng Android**. Giữ nguyên máy chủ Worker/D1 và tài khoản ADMIN; không bao gồm mật khẩu ADMIN.

## Luồng săn rương
- **Nhiều phòng:** mở TikTok, vào mục LIVE bằng nút LIVE; nếu giao diện không có rương thì quét 6 giây rồi vuốt lên chuyển phòng. Nếu TikTok vẫn ở Đề xuất, dừng thao tác, không vuốt video thường.
- **Một phòng:** mở thủ công đúng phòng TikTok LIVE muốn canh rồi app quét rương tại phòng đó; tuyệt đối không tự vuốt hoặc mở LIVE ngẫu nhiên.
- **Rương:** tìm icon, nút MỞ, xác nhận trạng thái, đọc đếm ngược, bấm NHẬN khi sẵn sàng; đọc câu “Bạn đã nhận được ... Xu” và cộng vào tổng phiên; đóng cửa sổ kết quả rồi kiểm tra lại sau 10 giây.
- Nếu OCR/chụp ảnh/Trợ năng không nhận diện được một trạng thái thì báo và chờ thao tác của người dùng, không chạm lung tung hoặc tự đóng LIVE. Rương tổng 1 xu cũng không bỏ qua.

## Hẹn tap
- Từ bóng nổi bấm biểu tượng bánh răng và chế độ **Tap ❤️**, nhập `@ID`, giờ `HH:mm` (bỏ trống để chạy ngay), số phút, số tap (10K/20K/50K/100K), sau đó bấm **HẸN TAP**.
- Đến giờ, app thử mở trang cá nhân TikTok theo ID. Chỉ khi thấy đúng @ID và nhãn LIVE cạnh avatar mới bấm vào phòng. Vào phòng rồi ở nguyên, **không so tên LIVE lần nữa, không vuốt**.
- Đếm những đợt chạm mà Android báo hoàn tất; không bảo đảm TikTok ghi nhận đủ tim. Tap tại vùng video trống, không bấm nút mua quà.
- Khi **đạt đủ** số tap, tự động nhập câu `Bot Tuấn Đz đã hoàn thành <số> tap tay ❤️`, tìm biểu tượng gửi và gửi **một lần**. Nếu không đọc được nút gửi sẽ dừng chờ, không nhấn mò. Hết giờ trước khi đủ số tap thì dừng **không** gửi bình luận hoàn thành.
- Hẹn giờ chạy trong tiến trình Trợ năng còn hoạt động; Android có thể dừng tiến trình khi khóa máy, tiết kiệm pin hoặc hạn chế chạy nền. Vì vậy không bảo đảm tự mở LIVE đúng giờ khi thiết bị ngủ/ứng dụng bị tắt.

## Bóng nổi
- Mặc định thu nhỏ, **chạm để mở**, kéo bằng tay để di chuyển. Bảng mở có giới hạn chiều cao, có cuộn nội dung và nút Thu nhỏ.
- Hiện giờ Việt Nam `HH:mm:ss`, trạng thái, thời gian rương, số rương và tổng xu thực nhận.
- Khi nhấn Dừng, gặp lỗi hoặc chế độ bị tạm dừng, bóng nổi được giữ lại để điều khiển.
- Bật chế độ thành công chỉ khi Trợ năng trả về trạng thái chạy và tạo được bóng nổi.

## Quan trọng
- **Không quay màn hình**: chỉ dùng `AccessibilityService.takeScreenshot()` từng ảnh cần quét, xử lý trên thiết bị bằng ML Kit OCR và mẫu icon. Chụp ảnh vẫn cần quyền Trợ năng và có thể bị Android/TikTok chặn.
- **Chưa được chạy thử trên TikTok thật** trong môi trường soạn mã; Build xanh mới chứng minh mã biên dịch được, không chứng minh các thao tác trên TikTok thành công.
- Nếu có lỗi, chụp màn hình trạng thái bóng nổi và cho biết đang chạy chế độ nào. Không chia sẻ mật khẩu, token hay khóa ADMIN.

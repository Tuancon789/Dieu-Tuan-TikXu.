# TikXu v3.4.1 — sửa rương & bóng nổi (bản thử nghiệm)

Bản này **không thay đổi máy chủ Cloudflare, D1 hoặc tài khoản ADMIN**. Chỉ sửa phần Android.

## Lỗi đã sửa ở mã nguồn

- Bóng nổi xuất hiện dưới dạng nút nhỏ; bấm vào để mở, dùng **THU NHỎ** để thu lại. Giữ/kéo nút nhỏ hoặc kéo dòng tiêu đề để di chuyển. Đặt mặc định ở góc trên phải thay vì bảng lớn ở đáy màn hình, tránh che nút **Mở** của TikTok.
- Khi chưa đọc được nút MỞ, app chờ tối đa khoảng 12 giây và thử lại icon rương có giới hạn, không tự xóa bảng nổi. Nếu vẫn không thấy, **tạm dừng tại LIVE đó**, hiện cảnh báo; người dùng có thể bấm Mở thủ công trên TikTok rồi bấm **Tiếp tục** để kiểm tra lại.
- Sau khi gửi lệnh bấm MỞ, app chuyển sang bước **xác minh đã mở**; nếu nút MỞ vẫn xuất hiện thì thử lại tối đa một lần. Không tự coi một lệnh chạm là thành công.
- Sau màn hình kết quả, chỉ thử **Quay lại một lần**. Không bấm nút GỬI QUÀ TẶNG; nếu không xác minh được dialog đã đóng thì giữ nguyên phòng và tạm dừng, tránh thoát LIVE.
- Bảo toàn cách săn 6 giây/phòng, canh 1 phòng, chờ 10 giây sau khi xử lý, đếm xu thực nhận (nếu OCR đọc được).

## Thử nghiệm

1. Build từ `Dieu_Tuan_TikXu_v3_4_1_Source.zip` bằng workflow GitHub riêng.
2. Cài APK thử nghiệm, bật Trợ năng, vào TikTok LIVE.
3. Chạy Canh 1 phòng trước: thấy nút nhỏ **🎁 TikXu**; giữ và kéo để di chuyển, chạm để mở bảng điều khiển.
4. Kiểm tra chuỗi: icon rương → nút Mở → xác nhận rương mở → đồng hồ/Nhận → đóng kết quả; sau đó mới kiểm tra chế độ nhiều phòng.

## Giới hạn cần biết

- Chưa xác nhận trên TikTok LIVE thực tế. Giao diện TikTok có thể che chữ nút hoặc ảnh, khiến OCR và template nhận diện sai hoặc không nhận diện. Khi không chắc, phiên tạm dừng thay vì bấm mò. Không thể hứa tự nhặt được 100%.
- Không sử dụng MediaProjection/quay video; ảnh tức thời qua AccessibilityService.takeScreenshot và OCR ML Kit chạy trên máy Android 11+.
- GitHub Actions xanh chỉ chứng minh APK biên dịch thành công, không chứng minh TikTok chấp nhận thao tác.

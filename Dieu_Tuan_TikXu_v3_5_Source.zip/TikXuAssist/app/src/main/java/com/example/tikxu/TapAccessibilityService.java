package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

/** Gesture-only TikTok controller. No MediaProjection / screen recording. */
public class TapAccessibilityService extends AccessibilityService {
    interface GestureListener { void onDone(boolean completed); }
    private static volatile TapAccessibilityService live;
    private static volatile String foregroundPackage="";
    private LiveHuntV34 engine;

    @Override protected void onServiceConnected(){
        super.onServiceConnected();
        live=this;
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root!=null&&root.getPackageName()!=null)foregroundPackage=root.getPackageName().toString();
        engine=new LiveHuntV34(this);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        if(e==null||e.getPackageName()==null)return;
        String pkg=e.getPackageName().toString();
        if(isTikTokPackage(pkg)){
            foregroundPackage=pkg;
            if(engine!=null)engine.onTikTokEvent();
        } else if(e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            !pkg.equals("android") && !pkg.equals("com.android.systemui") &&
            !pkg.equals(getPackageName()) && !pkg.contains("inputmethod") &&
            !pkg.contains("keyboard") && !pkg.contains("gboard")){
            foregroundPackage=pkg;
        }
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){
        if(engine!=null)engine.close();
        if(live==this)live=null;
        foregroundPackage="";
        super.onDestroy();
    }
    static boolean isTikTokPackage(String pkg){
        return "com.zhiliaoapp.musically".equals(pkg)||
               "com.ss.android.ugc.trill".equals(pkg);
    }
    static String installedTikTokPackage(){
        TapAccessibilityService s=live;
        if(s==null)return "com.zhiliaoapp.musically";
        for(String candidate:new String[]{"com.zhiliaoapp.musically","com.ss.android.ugc.trill"}){
            try{s.getPackageManager().getPackageInfo(candidate,0);return candidate;}
            catch(Exception ignored){}
        }
        return "com.zhiliaoapp.musically";
    }
    static boolean isReady(){return live!=null;}
    static boolean isTikTokForeground(){
        TapAccessibilityService s=live;
        if(s==null)return false;
        try{
            for(AccessibilityWindowInfo window:s.getWindows()){
                if(window.getType()!=AccessibilityWindowInfo.TYPE_APPLICATION)continue;
                AccessibilityNodeInfo root=window.getRoot();
                if(root==null||root.getPackageName()==null)continue;
                return isTikTokPackage(root.getPackageName().toString());
            }
        }catch(Exception ignored){}
        AccessibilityNodeInfo root=s.getRootInActiveWindow();
        if(root!=null&&root.getPackageName()!=null){
            String pkg=root.getPackageName().toString();
            if(isTikTokPackage(pkg))return true;
            if(!pkg.contains("inputmethod")&&!pkg.contains("keyboard")&&
               !pkg.contains("gboard")&&!pkg.equals("com.android.systemui"))return false;
        }
        return isTikTokPackage(foregroundPackage);
    }
    static boolean isRunning(){return live!=null&&live.engine!=null&&live.engine.isRunning();}
    static boolean start(LiveHuntV34.Mode mode){
        TapAccessibilityService s=live;
        if(s==null||s.engine==null)return false;
        s.engine.start(mode);return s.engine.isRunning();
    }
    static void stop(){
        if(live!=null&&live.engine!=null)live.engine.stop("Người dùng đã dừng");
    }
    static void hideOnLogout(){
        if(live!=null&&live.engine!=null)live.engine.hideOverlay();
    }
    static boolean tapOnce(int x,int y){return tapOnce(x,y,null);}
    static boolean tapOnce(int x,int y,GestureListener cb){
        TapAccessibilityService s=live;
        if(s==null||!isTikTokForeground()||Build.VERSION.SDK_INT<24)return false;
        Path path=new Path();path.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path,0,75)).build();
        return s.dispatchGesture(g,callback(cb),null);
    }
    /** Six spaced taps per gesture. Count ONLY when Android reports completion. */
    static boolean tapBurst(int amount,int x,int y,GestureListener cb){
        TapAccessibilityService s=live;
        if(s==null||!isTikTokForeground()||Build.VERSION.SDK_INT<24||amount<=0)return false;
        GestureDescription.Builder builder=new GestureDescription.Builder();
        for(int i=0;i<amount;i++){
            Path p=new Path();p.moveTo(x,y);
            builder.addStroke(new GestureDescription.StrokeDescription(p,i*125L,55));
        }
        return s.dispatchGesture(builder.build(),callback(cb),null);
    }
    static boolean swipeToNextLive(GestureListener cb){
        TapAccessibilityService s=live;
        if(s==null||!isTikTokForeground()||Build.VERSION.SDK_INT<24)return false;
        DisplayMetrics m=new DisplayMetrics();
        WindowManager wm=(WindowManager)s.getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(m);
        Path p=new Path();p.moveTo(m.widthPixels*.48f,m.heightPixels*.80f);
        p.lineTo(m.widthPixels*.48f,m.heightPixels*.27f);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,480)).build();
        return s.dispatchGesture(g,callback(cb),null);
    }
    static boolean swipeToNextLive(){return swipeToNextLive(null);}
    private static GestureResultCallback callback(GestureListener l){
        if(l==null)return null;
        return new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription gesture){l.onDone(true);}
            @Override public void onCancelled(GestureDescription gesture){l.onDone(false);}
        };
    }
}

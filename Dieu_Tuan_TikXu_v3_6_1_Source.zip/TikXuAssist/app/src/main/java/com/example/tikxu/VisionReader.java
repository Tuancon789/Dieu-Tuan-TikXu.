package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.SystemClock;
import android.util.Log;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.TextRecognizer;

import java.io.InputStream;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** One accessibility screenshot per scan. No MediaProjection, no video stream,
 * no uploads: OCR and a user-supplied visual chest template run on device.
 * Android may deny screenshots or TikTok may conceal controls. */
final class VisionReader {
    static final class Word {
        final String raw, normalized;
        final Rect box;
        Word(String text, Rect rect) { raw=text;normalized=norm(text);box=new Rect(rect); }
    }
    static final class Frame {
        final long at;
        final int width,height;
        final List<Word> words;
        final Rect chest,redSend,pinkOpen;
        final boolean readable;
        Frame(long when,int w,int h,List<Word> words,Rect icon,Rect paperPlane,Rect openShape,boolean readable) {
            at=when;width=w;height=h;this.words=words;chest=icon;redSend=paperPlane;pinkOpen=openShape;this.readable=readable;
        }
        boolean fresh() { return SystemClock.elapsedRealtime()-at < 5500L; }
        Word find(String phrase, float minY,float maxY) {
            String key=norm(phrase);
            for (Word w: words) if(w.normalized.equals(key) &&
                (w.box.centerY()>=height*minY && w.box.centerY()<=height*maxY)) return w;
            return null;
        }
        boolean contains(String phrase) {
            String key=norm(phrase);
            for(Word w:words) if(w.normalized.contains(key)) return true;
            return false;
        }
        Integer claimed() {
            Pattern p=Pattern.compile("ban da nhan duoc\\s*([0-9.,]+)\\s*xu");
            for(int i=0;i<words.size();i++){
                String text=words.get(i).normalized;
                if(i+1<words.size()) text += " " + words.get(i+1).normalized;
                Matcher m=p.matcher(text);
                if(m.find()) try { return Integer.parseInt(m.group(1).replace(".","").replace(",","")); }
                catch(Exception ignored){}
            }
            return null;
        }
        /** Return seconds only for a timer within center / modal, not system clock. */
        Integer timer() {
            Pattern p=Pattern.compile("(?<![0-9])([0-9]{1,2})[:：]([0-5][0-9])(?![0-9])");
            for(Word w:words) {
                if(w.box.centerY() < height*.27f || w.box.centerY()>height*.87f) continue;
                Matcher m=p.matcher(w.raw);
                if(m.find()) try {return Integer.parseInt(m.group(1))*60+Integer.parseInt(m.group(2));}
                catch(Exception ignored){}
            }
            return null;
        }
        Word openButton() {
            for(Word w:words){
                float y=w.box.centerY()/(float)height;
                if(y<.69f || y>.95f || w.box.width()>width*.75f)continue;
                if(w.normalized.equals("mo") || w.normalized.equals("mo ruong") ||
                   w.normalized.equals("open") || w.normalized.equals("mo ngay")) return w;
            }
            return null;
        }
        Word claimButton() {
            for(String s:new String[]{"Nhận","Nhận xu","Nhận thưởng","Thu thập","Claim"}){
                Word w=find(s,.45f,.95f); if(w!=null)return w;
            }
            return null;
        }
        boolean giftModal() {
            return openButton()!=null || claimed()!=null ||
                (contains("ruong bau") && contains("xu")) ||
                (claimButton()!=null && contains("xu")) ||
                (contains("so nguoi xem") && contains("xu"));
        }
        boolean result() { return claimed()!=null || contains("khong nhan duoc xu") || contains("het luot"); }
    }
    interface Listener { void onFrame(Frame frame); void onError(String why); }
    private final TapAccessibilityService service;
    private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private final ArrayList<Bitmap> templates=new ArrayList<>();
    private boolean busy;
    private long lastCapture;
    VisionReader(TapAccessibilityService service){
        this.service=service;
        for(String path:new String[]{"chest_sample_01.png","chest_sample_02.png"}){
            try(InputStream stream=service.getAssets().open(path)){
                Bitmap bmp=android.graphics.BitmapFactory.decodeStream(stream);
                if(bmp!=null) templates.add(bmp);
            }catch(Exception ignored){}
        }
    }
    void close(){ recognizer.close(); for(Bitmap b:templates) b.recycle(); templates.clear(); }
    void capture(Listener listener) {
        long now=SystemClock.elapsedRealtime();
        if(busy || now-lastCapture<1800L) return;
        if(Build.VERSION.SDK_INT<30){listener.onError("Máy cần Android 11+ để chụp ảnh qua Trợ năng"); return;}
        busy=true;lastCapture=now;
        try {
            service.takeScreenshot(android.view.Display.DEFAULT_DISPLAY, service.getMainExecutor(),
                new AccessibilityService.TakeScreenshotCallback(){
                    @Override public void onSuccess(AccessibilityService.ScreenshotResult result){
                        Bitmap hardware=null, copy=null;
                        try{
                            HardwareBuffer hb=result.getHardwareBuffer();
                            try { hardware=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());
                                  if(hardware==null) throw new IllegalStateException("Không lấy được ảnh");
                                  copy=hardware.copy(Bitmap.Config.ARGB_8888,false);
                            } finally { hb.close(); }
                            if(copy==null) throw new IllegalStateException("Không tạo được ảnh");
                            final Bitmap frameBitmap=copy;
                            final long captureAt=lastCapture;
                            final Rect icon=matchChest(frameBitmap);
                            final Rect redSend=matchRedPaperPlane(frameBitmap);
                            final Rect openShape=matchWidePinkButton(frameBitmap);
                            recognizer.process(InputImage.fromBitmap(frameBitmap,0))
                                .addOnSuccessListener(text->{
                                    ArrayList<Word> list=new ArrayList<>();
                                    for(Text.TextBlock b:text.getTextBlocks())
                                      for(Text.Line line:b.getLines()){
                                        Rect r=line.getBoundingBox();
                                        if(r!=null) list.add(new Word(line.getText(),r));
                                      }
                                    listener.onFrame(new Frame(captureAt,frameBitmap.getWidth(),frameBitmap.getHeight(),list,icon,redSend,openShape,true));
                                })
                                .addOnFailureListener(e->listener.onError("OCR: "+e.getClass().getSimpleName()))
                                .addOnCompleteListener(task->{busy=false;frameBitmap.recycle();});
                        } catch(Exception e){
                            if(copy!=null) copy.recycle();
                            busy=false;
                            listener.onError("Không đọc ảnh: "+e.getClass().getSimpleName());
                        }
                    }
                    @Override public void onFailure(int code){
                        busy=false;
                        if(code==AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT)
                            listener.onError("Chụp ảnh quá nhanh, đang thử lại");
                        else listener.onError("TikTok/Android không cho chụp ảnh Trợ năng ("+code+")");
                    }
                });
        }catch(Exception e){busy=false;listener.onError("Quyền ảnh Trợ năng chưa sẵn sàng");}
    }
    /** Pixel color fallback for the broad pink "Mở" bar at bottom of an OPEN
     * chest dialog. MUST be gated by OCR confirmation of "Rương Báu" elsewhere;
     * pink alone can also mean Follow, Gifts or Give Gift buttons. */
    private Rect matchWidePinkButton(Bitmap image){
        int w=image.getWidth(),h=image.getHeight();
        int from=(int)(h*.87f),to=(int)(h*.96f);
        int left=(int)(w*.17f),right=(int)(w*.83f);
        int hits=0;int first=-1,last=-1;
        int yStep=Math.max(2,h/400),xStep=Math.max(2,w/180);
        for(int y=from;y<to;y+=yStep){
            int good=0,all=0;
            for(int x=left;x<right;x+=xStep){
                int c=image.getPixel(x,y);
                int r=(c>>16)&255,g=(c>>8)&255,b=c&255;
                if(r>205 && g>=20 && g<138 && b>=40 && b<180 && r>g+70)good++;
                all++;
            }
            if(all>0 && good>=all*.82){
                if(first<0)first=y;
                last=y;hits++;
            }
        }
        if(hits<3||last-first<Math.max(7,h/150))return null;
        return new Rect(left,first,right,last);
    }
    /** Restricted visual template search. Only matches small chest icon in upper
     * portion of LIVE; never infer a tap location from arbitrary colorful content.
     * This is a best-effort reference image, not a general object detector. */
    private Rect matchChest(Bitmap frame){
        if(templates.isEmpty())return null;
        int w=frame.getWidth(),h=frame.getHeight();
        // Pixel grid downsample keeps processing bounded even on large screens.
        int sw=Math.max(150,w/4),sh=Math.max(320,h/4);
        Bitmap tiny=Bitmap.createScaledBitmap(frame,sw,sh,false);
        try{
            int[] pixels=new int[sw*sh];tiny.getPixels(pixels,0,sw,0,0,sw,sh);
            double factor=sw/691.0;
            for(Bitmap tpl:templates){
                for(double s:new double[]{.78,1.0,1.24}){
                    int tw=(int)Math.round(tpl.getWidth()*factor*s);
                    int th=(int)Math.round(tpl.getHeight()*factor*s);
                    if(tw<10||th<10||tw>sw*.26)continue;
                    Bitmap small=Bitmap.createScaledBitmap(tpl,tw,th,false);
                    int[] sample=new int[tw*th];small.getPixels(sample,0,tw,0,0,tw,th);
                    small.recycle();
                    int step=Math.max(2,tw/11), bestX=-1,bestY=-1;
                    float best=Float.MAX_VALUE;
                    // Match high-saturation yellow/red icon; ignore original black background.
                    for(int y=(int)(sh*.105);y<(int)(sh*.46)-th;y+=3){
                      for(int x=0;x<(int)(sw*.33)-tw;x+=3){
                        int diff=0,points=0;
                        for(int yy=0;yy<th;yy+=step)for(int xx=0;xx<tw;xx+=step){
                            int v=sample[yy*tw+xx];
                            int r=(v>>16)&255,g=(v>>8)&255,b=v&255;
                            if(Math.max(r,Math.max(g,b))-Math.min(r,Math.min(g,b))<65 || r<115)continue;
                            int p=pixels[(y+yy)*sw+x+xx];
                            int pr=(p>>16)&255,pg=(p>>8)&255,pb=p&255;
                            diff+=Math.abs(pr-r)+Math.abs(pg-g)+Math.abs(pb-b);points++;
                        }
                        if(points<6)continue;
                        float score=(float)diff/(points*765);
                        if(score<best){best=score;bestX=x;bestY=y;}
                      }
                    }
                    if(best<.18f && bestX>=0) {
                        return new Rect(bestX*w/sw,bestY*h/sh,
                           (bestX+tw)*w/sw,(bestY+th)*h/sh);
                    }
                }
            }
            return null;
        }finally{tiny.recycle();}
    }
    /** Red send arrow is only a candidate: the caller must independently
     * confirm a populated, editable LIVE-comment field and visible IME. */
    private Rect matchRedPaperPlane(Bitmap bitmap){
        int w=bitmap.getWidth(),h=bitmap.getHeight();
        int stride=Math.max(2,w/270);
        int best=-1,bx=-1,by=-1;
        // Red send-plane normally lies at the right of the chat composer.
        int xmin=(int)(w*.85f),xmax=(int)(w*.98f);
        int ymin=(int)(h*.37f),ymax=(int)(h*.81f);
        for(int y=ymin;y<ymax-24;y+=Math.max(4,stride*3)){
            for(int x=xmin;x<xmax-24;x+=Math.max(4,stride*3)){
                int red=0,total=0;
                for(int dy=0;dy<24;dy+=stride)for(int dx=0;dx<24;dx+=stride){
                    int px=bitmap.getPixel(x+dx,y+dy);
                    int r=(px>>16)&255,g=(px>>8)&255,b=px&255;
                    if(r>190 && r>g+65 && r>b+45 && b<185)red++;
                    total++;
                }
                if(red>=Math.max(6,total/4) && red>best){best=red;bx=x;by=y;}
            }
        }
        if(bx<0)return null;
        return new Rect(bx,by,bx+24,by+24);
    }
    static String norm(String input) {
        if(input==null)return "";
        return Normalizer.normalize(input.toLowerCase(Locale.ROOT),Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").replace('đ','d').replaceAll("\\s+"," ").trim();
    }
}

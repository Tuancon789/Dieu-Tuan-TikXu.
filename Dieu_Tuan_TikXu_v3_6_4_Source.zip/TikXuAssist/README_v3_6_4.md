# TikXu 3.6.4 — Lịch nhiều phòng và tap mép trái

## Cách dùng
1. Mở Tap tim. Nhập @ID, giờ 24h theo Việt Nam và số tap (1–100.000).
2. Bấm + THÊM VÀO LỊCH cho từng phòng. Kiểm tra ngày/giờ hiển thị. Giờ đã qua được hẹn ngày mai.
3. Bấm CHẠY LỊCH. App thu nhỏ menu, chờ giờ, mở trang cá nhân, kiểm tra ID rồi tìm LIVE.
4. Đủ tap thì chờ lịch tiếp theo. Lịch mới đến giờ thì kết thúc phòng cũ sau đợt chạm đang gửi (tối đa khoảng nửa giây), rồi mở ID tiếp theo.
5. Dừng tắt việc chạy lịch; lịch chờ vẫn được lưu. Sau khi mở lại app phải bấm CHẠY LỊCH.

Danh sách có trạng thái và nút xóa. Hai phòng không được trùng giờ. Lịch quá giờ hơn 5 phút được đánh dấu Lỡ giờ, không chạy bù hàng loạt.
Phòng không tìm được LIVE được ghi lỗi rồi chờ lịch kế tiếp. Không tự bình luận khi hoàn thành.

## Tap và bóng menu
Điểm tap cố định ở khoảng 3% chiều rộng (ít nhất 8dp), 39% chiều cao — sát mép trái như demo.
Bóng menu kéo độc lập. Nếu bóng che điểm tap, bóng chuyển sang mép phải để không nhận nhầm cú chạm.
Mở menu hoặc kéo bóng thì tạm ngưng gửi đợt tap mới; thu nhỏ menu để tiếp tục.
Số tap là số thao tác Android báo hoàn thành, không phải số lượt thích TikTok xác nhận.

## Tối ưu rương
Giữ các sửa lỗi 3.6.2/3.6.3 (đồng hồ dưới cùng, Mở/Nhận, nhận nhầm chat, quét lại rương tiếp theo).
OCR tối thiểu 800ms, 500ms gần hết giờ nếu máy xử lý kịp; không xử lý hai ảnh đồng thời.
Gần hết giờ kiểm tra nút Mở/Nhận đang bật qua Trợ năng mỗi khoảng 100ms.
Mốc đếm ngược dựa trên thời điểm chụp, không cộng thêm thời gian OCR hoặc cộng lại từ ảnh cũ.
Quét phòng 3 giây, kiểm tra sau rương 2,5 giây. Không bỏ qua đếm ngược của TikTok.

## Điều kiện và kiểm tra
Giữ máy mở khóa, màn hình bật, TikXu/Trợ năng hoạt động và kết nối mạng. Đây là lịch trong app, không phải báo thức hệ thống có thể tự đánh thức máy.
Đã phân tích cú pháp toàn bộ mã Java và chạy kiểm tra Java trên các hàm lịch/nhận diện trích từ mã nguồn: thứ tự, chuyển trạng thái, giờ Việt Nam, ngày mai, giờ trùng, đầu vào sai, nhận diện đồng hồ và chat.
Chưa build toàn bộ APK hoặc thử trên thiết bị Android trong phiên này. Cần chạy workflow GitHub rồi kiểm tra thực tế. Không cam kết độ trễ bằng 0.

## Build
Upload Dieu_Tuan_TikXu_v3_6_4_Source.zip vào gốc repo.
Upload build_v3_6_4_GitHub_Actions.yml vào .github/workflows rồi chạy workflow phiên bản 3.6.4.

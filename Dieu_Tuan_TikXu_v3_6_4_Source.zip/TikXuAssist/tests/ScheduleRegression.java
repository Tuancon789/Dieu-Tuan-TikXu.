import java.util.*;import java.text.*;import java.util.regex.*;
public class ScheduleRegression {
static class Rect {int left,top,right,bottom;Rect(int l,int t,int r,int b){left=l;top=t;right=r;bottom=b;}Rect(Rect r){this(r.left,r.top,r.right,r.bottom);}int centerX(){return (left+right)/2;}int centerY(){return (top+bottom)/2;}int width(){return right-left;}}
static class SystemClock {static long elapsedRealtime(){return 100000;}}
static class Field {String text;Field(String v){text=v;}String getText(){return text;}}
enum Step {HEART_SCHEDULE}
ArrayList<TapJob> tapJobs=new ArrayList<>();TapJob activeJob;
boolean queueEnabled,gestureBusy,profileVerified,commentSent;int goal,tapGeneration,tapCount,heartFailures,heartMinutes;
String heartId,status;long scheduledAt,heartEndsAt,stepAt;Object frame;Step step;
Field userField,hourField,tapGoalField;
void message(String s){status=s;}void saveTapJobs(){}void renderTapJobs(){}void setMini(boolean v){}
static void check(boolean v,String msg){if(!v)throw new AssertionError(msg);}
    private static final class TapJob {
        String id, state="Chờ chạy";
        long when;
        int target, done;
        TapJob(String id,long when,int target){this.id=id;this.when=when;this.target=target;}
    }
    private String formatJobTime(long when){
        SimpleDateFormat f=new SimpleDateFormat("dd/MM HH:mm",Locale.forLanguageTag("vi-VN"));
        f.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));return f.format(new Date(when));
    }
    private TapJob nextTapJob(){
        TapJob next=null;
        long now=System.currentTimeMillis();
        boolean changed=false;
        for(TapJob j:tapJobs){
            if(!j.state.equals("Chờ chạy"))continue;
            if(now-j.when>5*60000L){j.state="Lỡ giờ";changed=true;continue;}
            if(next==null || j.when<next.when)next=j;
        }
        if(changed){saveTapJobs();renderTapJobs();}
        return next;
    }
    private void scheduleHeartFromBubble(){
        String id=userField.getText().toString().trim().replaceFirst("^@", "");
        String time=hourField.getText().toString().trim();
        if(!id.matches("[A-Za-z0-9._]{2,30}")){message("ID TikTok không hợp lệ");return;}
        if(!time.matches("(?:[01]\\d|2[0-3]):[0-5]\\d")){message("Nhập giờ 24h, ví dụ 07:30 hoặc 20:45");return;}
        int target;
        try{target=Integer.parseInt(tapGoalField.getText().toString().trim().replace(".","").replace(",",""));}
        catch(Exception e){message("Nhập số tap từ 1 đến 100.000");return;}
        if(target<1 || target>100000){message("Số tap phải từ 1 đến 100.000");return;}
        String[] parts=time.split(":");
        Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
        c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(parts[0]));c.set(Calendar.MINUTE,Integer.parseInt(parts[1]));
        c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        if(c.getTimeInMillis()<System.currentTimeMillis())c.add(Calendar.DAY_OF_MONTH,1);
        for(TapJob j:tapJobs)if(j.state.equals("Chờ chạy") && j.when==c.getTimeInMillis()){
            message("Giờ này đã có một phòng • chọn giờ khác");return;
        }
        tapJobs.add(new TapJob(id,c.getTimeInMillis(),target));
        saveTapJobs();renderTapJobs();
        message("Đã thêm @"+id+" • "+formatJobTime(c.getTimeInMillis())+
                (queueEnabled?" • lịch đang chạy":" • bấm CHẠY LỊCH để bật"));
    }
    private void beginTapJob(TapJob j){
        activeJob=j;j.state="Đang chạy";j.done=0;
        heartId=j.id;goal=j.target;scheduledAt=j.when;
        heartMinutes=120;heartEndsAt=0;tapCount=0;heartFailures=0;
        tapGeneration++;gestureBusy=false;profileVerified=false;commentSent=false;
        frame=null;step=Step.HEART_SCHEDULE;stepAt=SystemClock.elapsedRealtime();
        saveTapJobs();renderTapJobs();setMini(true);
    }
    private void finishTapJob(String result,boolean announce){
        if(activeJob!=null){activeJob.done=tapCount;activeJob.state=result;activeJob=null;}
        tapGeneration++;gestureBusy=false;frame=null;scheduledAt=0;
        step=Step.HEART_SCHEDULE;stepAt=SystemClock.elapsedRealtime();
        saveTapJobs();renderTapJobs();
        if(announce)message(result+" • chờ lịch tiếp theo");
    }
    private void cancelTapQueue(){
        queueEnabled=false;
        if(activeJob!=null){activeJob.done=tapCount;activeJob.state="Đã dừng";activeJob=null;}
        tapGeneration++;saveTapJobs();renderTapJobs();
    }
    static final class Word {
        final String raw, normalized;
        final Rect box;
        Word(String text, Rect rect) { raw=text;normalized=norm(text);box=new Rect(rect); }
    }
    static final class Frame {
        final long at;
        final int width,height;
        final List<Word> words;
        final Rect chest,redSend,pinkOpen;
        final boolean readable;
        Frame(long when,int w,int h,List<Word> words,Rect icon,Rect paperPlane,Rect openShape,boolean readable) {
            at=when;width=w;height=h;this.words=words;chest=icon;redSend=paperPlane;pinkOpen=openShape;this.readable=readable;
        }
        boolean fresh() { return SystemClock.elapsedRealtime()-at < 5500L; }
        Word find(String phrase, float minY,float maxY) {
            String key=norm(phrase);
            for (Word w: words) if(w.normalized.equals(key) &&
                (w.box.centerY()>=height*minY && w.box.centerY()<=height*maxY)) return w;
            return null;
        }
        boolean contains(String phrase) {
            String key=norm(phrase);
            for(Word w:words) if(w.normalized.contains(key)) return true;
            return false;
        }
        Integer claimed() {
            Pattern p=Pattern.compile("ban da nhan duoc\\s*([0-9.,]+)\\s*xu");
            for(int i=0;i<words.size();i++){
                String text=words.get(i).normalized;
                if(i+1<words.size()) text += " " + words.get(i+1).normalized;
                Matcher m=p.matcher(text);
                if(m.find()) try { return Integer.parseInt(m.group(1).replace(".","").replace(",","")); }
                catch(Exception ignored){}
            }
            return null;
        }
        /** Return seconds only for a timer within center / modal, not system clock. */
        Integer timer() {
            Pattern p=Pattern.compile("(?<![0-9])([0-9]{1,2})[:：]([0-5][0-9])(?![0-9])");
            for(Word w:words) {
                // Only a standalone countdown in the lower chest sheet. This excludes
                // the status clock, LIVE icon timers and our floating panel clock.
                if(w.box.centerY() < height*.57f || w.box.centerY()>height*.96f) continue;
                if(w.box.centerX()<width*.20f || w.box.centerX()>width*.80f) continue;
                Matcher m=p.matcher(w.raw.trim());
                if(m.matches()) try {return Integer.parseInt(m.group(1))*60+Integer.parseInt(m.group(2));}
                catch(Exception ignored){}
            }
            return null;
        }
        Word openButton() {
            for(Word w:words){
                float y=w.box.centerY()/(float)height;
                if(y<.69f || y>.95f || w.box.width()>width*.75f)continue;
                if(w.normalized.equals("mo") || w.normalized.equals("mo ruong") ||
                   w.normalized.equals("open") || w.normalized.equals("mo ngay")) return w;
            }
            return null;
        }
        Word claimButton() {
            for(String s:new String[]{"Nhận","Nhận xu","Nhận thưởng","Thu thập","Claim"}){
                Word w=find(s,.45f,.95f); if(w!=null)return w;
            }
            return null;
        }
        boolean giftModal() {
            if(openButton()!=null || claimed()!=null)return true;
            // Room chat can mention Rương Báu; the overlay itself contains Xu.
            // Require the explanatory text belonging to the actual lower sheet.
            StringBuilder lower=new StringBuilder();
            for(Word w:words) if(w.box.centerY()>height*.57f && w.box.centerY()<height*.96f)
                lower.append(w.normalized).append(' ');
            String sheet=lower.toString();
            boolean explanation=sheet.contains("khong can mua") ||
                sheet.contains("bang cach mo ruong") ||
                sheet.contains("sau khi thoi gian dem nguoc") ||
                sheet.contains("nguoi xem co the nhan");
            return explanation || (claimButton()!=null && sheet.contains("xu"));
        }
        boolean result() { return claimed()!=null || contains("khong nhan duoc xu") || contains("het luot"); }
    }
    static String norm(String input) {
        if(input==null)return "";
        return Normalizer.normalize(input.toLowerCase(Locale.ROOT),Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").replace('đ','d').replaceAll("\\s+"," ").trim();
    }
static Word word(String s,int y){return new Word(s,new Rect(300,y-10,390,y+10));}
static Frame frame(Word... ws){return new Frame(0,691,1536,Arrays.asList(ws),null,null,null,true);}
public static void main(String[] args){
 ScheduleRegression a=new ScheduleRegression();long now=System.currentTimeMillis();
 TapJob later=new TapJob("room2",now+60000,20000),first=new TapJob("room1",now-100,10000);
 a.tapJobs.add(later);a.tapJobs.add(first);check(a.nextTapJob()==first,"earliest schedule despite insertion order");
 a.queueEnabled=true;a.beginTapJob(first);check(a.activeJob==first&&a.goal==10000&&a.tapCount==0,"start snapshot");
 check(a.nextTapJob()==later,"running job never selected twice");
 a.tapCount=10000;a.finishTapJob("Hoàn thành",true);check(first.done==10000&&a.activeJob==null&&a.queueEnabled,"finish keeps next schedule armed");
 a.beginTapJob(later);check(a.goal==20000&&a.tapCount==0,"next room resets count and target");
 a.tapCount=30;int token=a.tapGeneration;a.finishTapJob("Đã chuyển lịch",false);
 check(a.tapGeneration>token&&later.done==30,"invalidate stale gesture callbacks on switch");
 TapJob expired=new TapJob("old",now-400000,10);a.tapJobs.add(expired);check(a.nextTapJob()==null&&expired.state.equals("Lỡ giờ"),"missed schedules not replayed");
 TapJob pending=new TapJob("pending",now+120000,10);a.tapJobs.add(pending);a.cancelTapQueue();
 check(!a.queueEnabled&&pending.state.equals("Chờ chạy"),"stop disarms but preserves future rows");
 a.userField=new Field("@demo");a.hourField=new Field("07:30");a.tapGoalField=new Field("10.000");a.goal=123;
 int before=a.tapJobs.size();a.scheduleHeartFromBubble();check(a.tapJobs.size()==before+1,"valid HH:mm and dotted count accepted");
 TapJob added=a.tapJobs.get(a.tapJobs.size()-1);check(added.target==10000&&added.id.equals("demo")&&a.goal==123,"add does not alter running target");
 check(added.when>System.currentTimeMillis()&&a.formatJobTime(added.when).endsWith("07:30"),"Vietnam next occurrence");
 a.scheduleHeartFromBubble();check(a.tapJobs.size()==before+1,"duplicate time rejected");
 a.hourField.text="25:99";a.scheduleHeartFromBubble();check(a.tapJobs.size()==before+1,"invalid time rejected");
 a.hourField.text="08:45";a.tapGoalField.text="0";a.scheduleHeartFromBubble();check(a.tapJobs.size()==before+1,"zero count rejected");
 check(frame(word("00:23",1410)).timer()==23,"bottom countdown detected");
 check(frame(word("18:18:48",1010)).timer()==null,"overlay clock rejected");
 check(!frame(word("Bảo đã gửi một Rương Báu có x10",1250),word("Xu thực nhận: 0",650)).giftModal(),"chat plus overlay not a chest modal");
 check(frame(word("Không cần mua.",1210),word("00:23",1410)).giftModal(),"real countdown sheet recognized");
 check(frame(word("Mở",1410)).openButton()!=null,"ready Open label recognized");
 System.out.println("PASS: Java regression checks (queue, validation, timezone, countdown and modal recognition)");
}
}

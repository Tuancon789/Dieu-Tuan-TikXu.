DIEU TUAN AUTO CLICK — TikTok WebView Demo

Original repository: https://github.com/Tuancon789/Dieu-Tuan-TikXu.
Original source ZIP: Dieu_Tuan_TikXu_v3_6_4_Source.zip

PURPOSE
- Preserve the exact v3.6.4 AuthApi.java, AdminActivity.java, login API and account management.
- After signing into the app, open TikTok Web within the APK.
- Keep Tap tay with fixed initial target near the left edge, adjustable position and speed.
- Remove the chest/coin-hunting UI, OCR engine and related sample screenshots.
- Show a clearly labeled manual draft-reply demo, NOT automatic AI access to TikTok messages.
- Stop auto-click when exiting the TikTok Web screen.

HOW TO BUILD
1. Upload these two files to the matching paths in the original GitHub repository:
   .github/workflows/build-autoclick-demo.yml
   scripts/make_autoclick_demo.py
2. GitHub > Actions > Build Dieu Tuan Auto Click WebView Demo > Run workflow.
3. After it passes, download artifact Dieu-Tuan-AutoClick-WebView-DEMO-APK.
4. Back up existing Android app data before upgrading. Debug APK may have a different signature.

IMPORTANT LIMITATIONS
- This is a source patch/build kit, not a prebuilt APK. It was NOT compiled in this environment.
- The in-app TikTok website may not support all LIVE and DM features in Android WebView.
- Chat AI here is a manual template preview only; no account access, auto-reading or auto-send.
- The original proprietary app login still requires the owner's backend URL to be reachable.
- Android Accessibility permission is needed for Tap tay.
- GitHub write access for this connection returned 403; the files are not uploaded to the repo yet.

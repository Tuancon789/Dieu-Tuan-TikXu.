#!/usr/bin/env python3
"""Convert the official v3.6.4 source ZIP into a login-preserving TikTok WebView auto-click demo.
Runs in GitHub Actions after the v3.6.4 source archive is extracted.
"""
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path('TikXuAssist')
PKG = ROOT / 'app/src/main/java/com/example/tikxu'
main = PKG / 'MainActivity.java'
manifest = ROOT / 'app/src/main/AndroidManifest.xml'
assert main.is_file() and manifest.is_file(), 'Expected TikXuAssist v3.6.4 source'
src = main.read_text(encoding='utf-8')
assert 'AuthApi.request(this,"POST","/v1/login",payload,false)' in src, 'Original app login changed; abort to avoid losing it'
assert 'AuthApi.saveLogin(this,result);' in src
assert 'new Intent(this,AdminActivity.class)' in src

# Keep the original login method, backend AuthApi, role handling and AdminActivity.
# After successful login, jump into the in-app TikTok browser. Back returns to dashboard.
success = 'runOnUiThread(() -> {unlocked=true; showDashboard();});'
assert src.count(success) == 1, 'Login success handler not found once'
src = src.replace(success, 'runOnUiThread(() -> {unlocked=true; showDashboard(); openTikTokInside();});', 1)

start = src.index('    private void showDashboard() {')
end = src.index('    private void startMode(', start)
new_dashboard = '''    private void showDashboard() {
        LinearLayout root = page();
        root.addView(label("✦ ĐIỂU TUẤN AUTO CLICK", 25, CYAN, true));
        space(root, 10);
        root.addView(label("Đã đăng nhập: " + AuthApi.username(this) +
                (AuthApi.isAdmin(this) ? " • ADMIN" : " • TÀI KHOẢN CÓ HẠN"),
                14, 0xff6bf0c4, true));
        if (!AuthApi.isAdmin(this)) {
            long expires = getSharedPreferences("tikxu_auth", MODE_PRIVATE).getLong("expires_at", 0);
            if (expires > 0) {
                SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.forLanguageTag("vi-VN"));
                format.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
                root.addView(label("Hết hạn: " + format.format(new Date(expires)), 13, 0xffffd48d, false));
            }
        } else {
            space(root, 8);
            Button admin = action("👑 QUẢN TRỊ TÀI KHOẢN", false);
            root.addView(admin, buttonParams());
            admin.setOnClickListener(v -> startActivity(new Intent(this, AdminActivity.class)));
        }
        space(root, 12);
        String notice = getSharedPreferences("tikxu_auth", MODE_PRIVATE).getString("notice", "");
        if (!notice.isEmpty()) root.addView(label("📣 THÔNG BÁO: " + notice, 13, 0xffffd18e, false));
        Button web = action("♪ VÀO TIKTOK TRONG APP", true);
        root.addView(web, buttonParams());
        web.setOnClickListener(v -> openTikTokInside());
        root.addView(label("Phiên bản WebView thử nghiệm. LIVE và tin nhắn phụ thuộc giới hạn TikTok Web.",
                12, 0xffc0d6ef, false));
        space(root, 14);
        root.addView(label("QUYỀN ĐIỀU KHIỂN", 12, CYAN, true));
        Button access = action("BẬT TRỢ NĂNG ĐỂ TAP TAY", false);
        root.addView(access, buttonParams());
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        space(root, 9);
        status = label("", 13, Color.WHITE, false);
        root.addView(status);
        Button lock = action("ĐĂNG XUẤT", false);
        root.addView(lock, buttonParams());
        lock.setOnClickListener(v -> {
            TapAccessibilityService.stop();
            new Thread(() -> {
                try { AuthApi.request(this, "POST", "/v1/logout", new JSONObject(), true); }
                catch (Exception ignored) {}
                AuthApi.clear(this);
                runOnUiThread(this::showLogin);
            }, "Auth-Logout").start();
        });
        refreshStatus();
    }

'''
src = src[:start] + new_dashboard + src[end:]
start = src.index('    private void startMode(')
end = src.index('    @Override protected void onResume()', start)
src = src[:start] + '''    private void openTikTokInside() {
        if (!unlocked) return;
        if (status != null) status.setText("Đang xác minh thời hạn tài khoản...");
        new Thread(() -> {
            try {
                JSONObject me = AuthApi.request(this, "GET", "/v1/me", null, true);
                if (me.optBoolean("emergency_stop"))
                    throw new IllegalStateException("ADMIN đang dừng chức năng");
                runOnUiThread(() -> {
                    if (unlocked) startActivity(new Intent(this, TikTokActivity.class));
                });
            } catch (Exception err) {
                runOnUiThread(() -> {
                    if (status != null) status.setText("Không thể mở: " + err.getMessage());
                });
            }
        }, "AutoClick-License").start();
    }

''' + src[end:]
main.write_text(src, encoding='utf-8')

# Keep the original Android package identity so app account storage is not erased on upgrade.
xml = manifest.read_text(encoding='utf-8')
assert '<activity android:name=".AdminActivity"' in xml
xml = xml.replace('<activity android:name=".AdminActivity"',
                  '<activity android:name=".TikTokActivity" android:exported="false" />\n'
                  '        <activity android:name=".AdminActivity"', 1)
xml = xml.replace('android:label="TikXu v3.6.1 • Trợ năng LIVE"',
                  'android:label="Điểu Tuấn • Auto Click"')
manifest.write_text(xml, encoding='utf-8')

# Keep AuthApi.java untouched; do not remove ADMIN management or server features.
(PKG / 'LiveHuntV34.java').unlink(missing_ok=True)
(PKG / 'VisionReader.java').unlink(missing_ok=True)
for image in (ROOT / 'app/src/main/assets').glob('chest_sample_*'):
    image.unlink()
# Remove ML Kit OCR now that chest recognition is gone.
gradle = ROOT / 'app/build.gradle'
g = gradle.read_text(encoding='utf-8')
g = g.replace("    implementation 'com.google.mlkit:text-recognition:16.0.1'", '')
g = g.replace("versionCode 14", "versionCode 15")
g = g.replace("versionName '0.3.6.4-scheduled-rooms'", "versionName '0.4.0-autoclick-webview-demo'")
gradle.write_text(g, encoding='utf-8')
# Existing drawable and auth server references are preserved.
strings = ROOT / 'app/src/main/res/values/strings.xml'
ss = strings.read_text(encoding='utf-8')
ss = ss.replace('TikXu', 'Auto Click')
strings.write_text(ss, encoding='utf-8')

(PKG / 'TapAccessibilityService.java').write_text(r'''package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

/** User-controlled repeat tapping; no TikTok text collection and no screen recording. */
public final class TapAccessibilityService extends AccessibilityService {
    private static volatile TapAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean active = false;
    private int tapX, tapY, intervalMs;
    private final Runnable tapTask = this::dispatchTap;

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopInternal(); }
    @Override public void onDestroy() {
        stopInternal();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static boolean isReady() { return instance != null; }
    public static boolean startTap(int x, int y, int interval) {
        TapAccessibilityService s = instance;
        if (s == null || Build.VERSION.SDK_INT < 26 || interval < 70) return false;
        s.stopInternal();
        s.tapX = x; s.tapY = y; s.intervalMs = interval;
        s.active = true;
        s.handler.post(s.tapTask);
        return true;
    }
    public static void stop() {
        TapAccessibilityService s = instance;
        if (s != null) s.stopInternal();
    }
    private void stopInternal() {
        active = false;
        handler.removeCallbacks(tapTask);
    }
    private void dispatchTap() {
        if (!active) return;
        // Only tap within our own activity, never other apps or system dialogs.
        if (getRootInActiveWindow() == null || getRootInActiveWindow().getPackageName() == null ||
                !getPackageName().contentEquals(getRootInActiveWindow().getPackageName())) {
            stopInternal(); return;
        }
        Path path = new Path();
        path.moveTo(tapX, tapY);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 40)).build();
        boolean sent = dispatchGesture(g, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription gesture) { scheduleNext(); }
            @Override public void onCancelled(GestureDescription gesture) { scheduleNext(); }
        }, handler);
        if (!sent) scheduleNext();
    }
    private void scheduleNext() {
        if (!active) return;
        handler.removeCallbacks(tapTask);
        handler.postDelayed(tapTask, intervalMs);
    }
}
''', encoding='utf-8')

(PKG / 'TikTokActivity.java').write_text(r'''package com.example.tikxu;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** TikTok website inside the existing app after its own account login. */
public final class TikTokActivity extends Activity {
    private FrameLayout canvas;
    private WebView web;
    private TextView feedback;
    private Button tapButton, speedButton;
    private boolean tapping = false;
    private int interval = 150, tapX, tapY;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // The parent activity only opens this after authenticated server login.
        if (AuthApi.token(this).isEmpty()) { finish(); return; }
        canvas = new FrameLayout(this);
        setContentView(canvas);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true); // TikTok Web requires JavaScript.
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        canvas.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // Compact in-app overlay; does not use TikTok APIs or scrape messages.
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(6), dp(6), dp(6), dp(6));
        controls.setBackgroundColor(0xee121c32);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        canvas.addView(controls, cp);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(buttons);
        tapButton = button("▶ TAP TAY", buttons, () -> toggleTap());
        speedButton = button("150ms", buttons, this::cycleSpeed);
        button("◎ ĐIỂM", buttons, this::pickSpot);
        LinearLayout row2 = new LinearLayout(this);
        controls.addView(row2);
        button("LIVE", row2, () -> open("https://www.tiktok.com/live"));
        button("TIN NHẮN", row2, () -> open("https://www.tiktok.com/messages"));
        button("CHAT AI", row2, this::showChatDemo);
        button("⋮", row2, this::showMore);
        feedback = new TextView(this);
        feedback.setTextColor(Color.WHITE);
        feedback.setTextSize(11);
        feedback.setText("Tap tay: chọn điểm, cấp Trợ năng rồi bấm chạy • Chat AI đang thử nghiệm");
        controls.addView(feedback);
        canvas.post(() -> {
            tapX = dp(18); // near the left edge, as requested
            tapY = canvas.getHeight() / 2;
        });
        open("https://www.tiktok.com/");
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private Button button(String caption, LinearLayout parent, Runnable action) {
        Button b = new Button(this);
        b.setText(caption);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(10);
        b.setPadding(0, 0, 0, 0);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff2c4779));
        parent.addView(b, new LinearLayout.LayoutParams(0, dp(42), 1f));
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void open(String url) {
        if (!url.startsWith("https://www.tiktok.com/")) return;
        stopTap();
        web.loadUrl(url);
    }
    private void toggleTap() {
        if (tapping) { stopTap(); return; }
        if (!TapAccessibilityService.isReady()) {
            feedback.setText("Chưa bật Trợ năng. Mở cài đặt rồi quay lại app.");
            startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        if (TapAccessibilityService.startTap(tapX, tapY, interval)) {
            tapping = true;
            tapButton.setText("■ DỪNG TAP");
            feedback.setText("Đang tap tại (" + tapX + ", " + tapY + ") • " + interval + "ms");
        } else feedback.setText("Không thể khởi động Tap tay.");
    }
    private void stopTap() {
        TapAccessibilityService.stop();
        tapping = false;
        if (tapButton != null) tapButton.setText("▶ TAP TAY");
    }
    private void cycleSpeed() {
        int[] options = {75, 100, 150, 250, 500, 1000};
        int pos = 0;
        for (int i = 0; i < options.length; i++) if (options[i] == interval) pos = i;
        interval = options[(pos+1) % options.length];
        speedButton.setText(interval + "ms");
        if (tapping) { stopTap(); toggleTap(); }
    }
    private void pickSpot() {
        stopTap();
        feedback.setText("Chạm đúng 1 lần vào vị trí muốn Auto Click.");
        View picker = new View(this);
        picker.setBackgroundColor(0x4400b1ff);
        canvas.addView(picker, new FrameLayout.LayoutParams(-1, -1));
        picker.setOnTouchListener((v, event) -> {
            if (event.getAction() != MotionEvent.ACTION_UP) return true;
            tapX = (int) event.getRawX();
            tapY = (int) event.getRawY();
            canvas.removeView(picker);
            feedback.setText("Đã chọn điểm tap (" + tapX + ", " + tapY + ")");
            return true;
        });
    }
    private void showChatDemo() {
        final EditText msg = new EditText(this);
        msg.setHint("Dán một tin nhắn để thử gợi ý trả lời");
        new AlertDialog.Builder(this)
            .setTitle("Chat AI – chế độ thử")
            .setMessage("Chưa có API TikTok được cấp quyền để đọc/gửi LIVE hoặc tin nhắn riêng tự động. " +
                "Bản này chỉ tạo câu gợi ý thủ công, không tự gửi và không giả danh AI thật.")
            .setView(msg)
            .setNegativeButton("Đóng", null)
            .setPositiveButton("Gợi ý", (d, w) -> {
                String original = msg.getText().toString().trim();
                String reply = original.contains("?") ? "Haha, câu này hay quá 😄 Để mình trả lời nhé!" :
                        "Haha cảm ơn bạn đã nhắn 😄";
                new AlertDialog.Builder(this).setTitle("Gợi ý trả lời")
                    .setMessage(reply).setPositiveButton("OK", null).show();
            }).show();
    }
    private void showMore() {
        new AlertDialog.Builder(this).setTitle("Điểu Tuấn Auto Click")
            .setItems(new String[]{"Quay về quản lý app", "Mở TikTok bằng ứng dụng chính thức", "Dừng Tap tay"},
                (dialog, which) -> {
                    if (which == 0) finish();
                    else if (which == 1) {
                        stopTap();
                        Intent t = getPackageManager().getLaunchIntentForPackage("com.zhiliaoapp.musically");
                        if (t != null) startActivity(t);
                        else feedback.setText("Không tìm thấy TikTok được cài đặt trên điện thoại.");
                    } else stopTap();
                }).show();
    }
    @Override protected void onStop() { super.onStop(); stopTap(); }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        stopTap();
        if (web != null) { canvas.removeView(web); web.destroy(); web = null; }
        super.onDestroy();
    }
}
''', encoding='utf-8')

# Sanity: compile-time cross references must not include removed feature classes.
for p in PKG.glob('*.java'):
    if p.name not in ('TapAccessibilityService.java', 'TikTokActivity.java'):
        assert 'LiveHuntV34' not in p.read_text(encoding='utf-8'), 'Chest feature remains referenced in ' + p.name
ET.parse(manifest)
print('Updated app source. AuthApi.java and AdminActivity.java preserved, chest engine removed.')

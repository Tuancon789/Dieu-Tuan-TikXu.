package com.example.tikxu;

import android.graphics.Rect;
import android.text.TextUtils;

import com.google.mlkit.vision.text.Text;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative on-device OCR heuristic, NOT an official TikTok integration. */
public final class ChestDetector {
    private static final Pattern TIMER = Pattern.compile("(?<!\\d)(\\d{1,2})\\s*[:：]\\s*(\\d{2})(?!\\d)");
    private static final Pattern CLAIM = Pattern.compile("(?i)^(mo|nhan|mo ngay|nhan ngay|open|claim|collect|receive|open now|claim now)[! .]*$");

    public static final class Result {
        public final boolean chestVisible;
        public final Integer seconds;
        public final Rect claimButton;
        public final String summary;

        private Result(boolean chestVisible, Integer seconds, Rect claimButton, String summary) {
            this.chestVisible = chestVisible;
            this.seconds = seconds;
            this.claimButton = claimButton;
            this.summary = summary;
        }
    }

    private static final class Item {
        final String value;
        final Rect rect;
        Item(String value, Rect rect) { this.value = value; this.rect = rect; }
    }

    private static String normalize(String input) {
        String s = Normalizer.normalize(input.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        s = s.replaceAll("\\p{M}+", "").replace('đ', 'd');
        return s.replaceAll("\\s+", " ").trim();
    }

    private static boolean isChest(String s) {
        return s.contains("ruong") || s.contains("kho bau") || s.contains("treasure") ||
            s.contains("lucky box") || s.contains("chest") || s.contains("gift box");
    }

    private static float distance(Rect a, Rect b) {
        float dx = a.exactCenterX() - b.exactCenterX();
        float dy = a.exactCenterY() - b.exactCenterY();
        return (float)Math.sqrt(dx * dx + dy * dy);
    }

    public static Result detect(Text text, int width, int height) {
        List<Item> items = new ArrayList<>();
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                Rect box = line.getBoundingBox();
                if (box != null) items.add(new Item(normalize(line.getText()), box));
            }
        }
        List<Item> chests = new ArrayList<>();
        for (Item i : items) if (isChest(i.value)) chests.add(i);
        if (chests.isEmpty()) return new Result(false, null, null, "Chưa thấy chữ liên quan rương xu");

        // Stay within the same small UI cluster; avoid treating other video text as a timer.
        float region = Math.max(190f, Math.min(width, height) * 0.38f);
        Integer seconds = null;
        float nearestTimer = Float.MAX_VALUE;
        for (Item item : items) {
            Matcher timer = TIMER.matcher(item.value);
            if (!timer.find()) continue;
            int min = Integer.parseInt(timer.group(1));
            int sec = Integer.parseInt(timer.group(2));
            if (sec > 59 || min > 59) continue;
            for (Item chest : chests) {
                float dist = distance(chest.rect, item.rect);
                if (dist < region && dist < nearestTimer) {
                    nearestTimer = dist;
                    seconds = min * 60 + sec;
                }
            }
        }
        Rect claim = null;
        float nearestClaim = Float.MAX_VALUE;
        for (Item item : items) {
            if (!CLAIM.matcher(item.value).matches()) continue;
            // Candidate must be near text identifying a chest, not general LIVE/chat buttons.
            for (Item chest : chests) {
                float dist = distance(chest.rect, item.rect);
                if (dist < region && dist < nearestClaim) {
                    nearestClaim = dist;
                    claim = new Rect(item.rect);
                }
            }
        }
        String summary = seconds == null ? "Có dấu hiệu rương, chưa đọc được giờ" :
            String.format(Locale.getDefault(), "Rương: %02d:%02d", seconds / 60, seconds % 60);
        if (claim != null) summary += " • thấy nút nhận";
        return new Result(true, seconds, claim, summary);
    }
}

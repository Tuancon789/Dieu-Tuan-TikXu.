package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

/**
 * Only performs a single, user-enabled gesture at a conservatively chosen location.
 * Does not read accessibility node trees, account information, or messages.
 */
public class TapAccessibilityService extends AccessibilityService {
    private static volatile TapAccessibilityService live;
    private static volatile String foregroundPackage = "";

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        live = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        int type = event.getEventType();
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            String pkg = event.getPackageName().toString();
            // Our non-focusable overlay should not replace the foreground app.
            if (!pkg.equals(getPackageName()) && !pkg.equals("android") &&
                !pkg.equals("com.android.systemui")) {
                foregroundPackage = pkg;
            }
        }
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (live == this) live = null;
        foregroundPackage = "";
        super.onDestroy();
    }

    public static boolean isReady() { return live != null; }

    public static boolean isTikTokForeground() {
        String pkg = foregroundPackage;
        return pkg.equals("com.zhiliaoapp.musically") ||
               pkg.equals("com.ss.android.ugc.trill");
    }

    public static boolean tapOnce(int x, int y) {
        TapAccessibilityService service = live;
        if (service == null || !isTikTokForeground() || Build.VERSION.SDK_INT < 24) return false;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, 90)).build();
        return service.dispatchGesture(gesture, null, null);
    }
}

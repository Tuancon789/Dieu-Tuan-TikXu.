package com.example.tikxu;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 111;
    private SharedPreferences prefs;
    private TextView status;
    private CheckBox autoTap;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tikxu", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(15, 20, 30));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(32), dp(22), dp(30));
        scroll.addView(content);

        TextView title = text("🪙 ĐIỂU TUẤN • TikXu", 27, Color.WHITE, true);
        content.addView(title);
        content.addView(text("Ứng dụng thử nghiệm của ĐIỂU TUẤN\nOCR + bảng nổi trên TikTok LIVE", 14, 0xffb9c5d7, false));
        space(content, 20);
        status = text("", 14, 0xff7dd3fc, false);
        content.addView(status);
        space(content, 16);

        addButton(content, "1. Cấp quyền hiển thị nổi", () -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });
        addButton(content, "2. Bật Trợ năng (để tự chạm)", () ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        if (Build.VERSION.SDK_INT >= 33) {
            addButton(content, "3. Cho phép thông báo", () -> {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, 10);
                }
            });
        }
        autoTap = new CheckBox(this);
        autoTap.setText("Cho phép thử tự bấm nút Mở/Nhận (rủi ro tài khoản)");
        autoTap.setTextColor(Color.WHITE);
        autoTap.setTextSize(14);
        autoTap.setChecked(prefs.getBoolean("auto_tap", false));
        autoTap.setOnCheckedChangeListener((button, enabled) -> {
            prefs.edit().putBoolean("auto_tap", enabled).apply();
        });
        content.addView(autoTap);
        space(content, 18);
        addButton(content, "▶ BẮT ĐẦU NHẬN DIỆN", this::startCapture);
        addButton(content, "■ DỪNG QUÉT", () -> stopService(new Intent(this, CaptureService.class)));
        space(content, 12);
        TextView instructions = text("Cách dùng:\n" +
            "• Cấp quyền hiển thị nổi.\n" +
            "• Chỉ bật Trợ năng nếu muốn dùng tự chạm.\n" +
            "• Bấm Bắt đầu, chọn CHIA SẺ TOÀN BỘ MÀN HÌNH.\n" +
            "• Chuyển sang TikTok LIVE và đợi app nhận diện rương.\n" +
            "• Kéo bảng nổi để không che rương xu.\n\n" +
            "Lưu ý: OCR cần nhìn thấy chữ 'rương/kho báu/treasure' và đồng hồ hoặc nút Mở/Nhận; không tự săn LIVE; không vượt CAPTCHA; không đảm bảo xu. Không gửi ảnh màn hình lên máy chủ.",
            14, 0xffccd8e7, false);
        instructions.setLineSpacing(dp(5), 1f);
        content.addView(instructions);
        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) {
            status.setText("Quyền nổi: " + (Settings.canDrawOverlays(this) ? "ĐÃ BẬT" : "CHƯA BẬT") +
                "  |  Trợ năng: " + (TapAccessibilityService.isReady() ? "ĐÃ BẬT" : "CHƯA BẬT"));
        }
    }

    private void startCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.setText("Cần cấp quyền nổi trước.");
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager)
            getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), CAPTURE_REQUEST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CAPTURE_REQUEST) return;
        if (resultCode != RESULT_OK || data == null) {
            status.setText("Bạn đã từ chối quyền chia sẻ màn hình.");
            return;
        }
        Intent i = new Intent(this, CaptureService.class);
        i.setAction(CaptureService.ACTION_START);
        i.putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode);
        i.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        status.setText("Đã xin quyền quét. Giờ mở TikTok LIVE nhé.");
    }

    private void addButton(LinearLayout parent, String label, Runnable action) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        GradientDrawable background = new GradientDrawable();
        background.setColor(0xff1d4ed8);
        background.setCornerRadius(dp(12));
        button.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(52));
        params.bottomMargin = dp(10);
        parent.addView(button, params);
        button.setOnClickListener(v -> action.run());
    }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(s);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }
    private int dp(float amount) { return (int) (amount * getResources().getDisplayMetrics().density + 0.5f); }
    private void space(LinearLayout parent, int height) {
        View view = new View(this);
        parent.addView(view, new LinearLayout.LayoutParams(1, dp(height)));
    }
}

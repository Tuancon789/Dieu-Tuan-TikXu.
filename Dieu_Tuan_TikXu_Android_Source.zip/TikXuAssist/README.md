# ĐIỂU TUẤN • TikXu

**Bản thử nghiệm Android (mã nguồn)** — bảng nổi hỗ trợ nhìn đồng hồ rương xu TikTok LIVE, cảnh báo trước khi mở, và chế độ tự bấm thử **mặc định TẮT**. Đây là dự án mẫu độc lập, **không liên kết hoặc được TikTok chứng nhận**.

## Cách lấy APK bằng Android Studio

1. Cài **Android Studio** mới, Android SDK Platform 35, Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17. Nếu dự án hỏi cấu hình Gradle, chọn bản Gradle 8.9 cài trong máy (gói mã nguồn không kèm `gradle-wrapper.jar`).
2. Giải nén và mở thư mục `TikXuAssist` trong Android Studio.
3. Đợi đồng bộ Gradle và tải mô hình OCR (cần internet trong lần build đầu).
4. Chọn **Build → Build APK(s)** hoặc chạy `gradle assembleDebug` khi đã cài Gradle.
5. File nhận được sẽ nằm tại `app/build/outputs/apk/debug/app-debug.apk`.
6. Chuyển APK vào Android và cài đặt sau khi kiểm tra nguồn gốc. Android có thể yêu cầu cho phép cài từ nguồn đã chọn.

**Có thể dùng GitHub Actions nếu không có máy tính:** tải mã nguồn lên repository GitHub có `.github/workflows/build-apk.yml`, chọn Actions → Build Android APK → Run workflow. Tải artifact `DieuTuan-TikXu-debug-APK` trong kết quả workflow (GitHub có thể yêu cầu xác nhận quyền chạy workflow). Không cần gửi mật khẩu TikTok hoặc thông tin tài khoản cho dự án.

## Cách sử dụng

1. Mở **ĐIỂU TUẤN • TikXu**, cấp quyền hiển thị trên ứng dụng khác.
2. Nếu chỉ cần cảnh báo: không cần cấp Trợ năng. Nếu muốn **thử tự bấm**: mở cài đặt Trợ năng và bật dịch vụ `ĐIỂU TUẤN • TikXu: tự chạm` sau khi đã đọc rủi ro.
3. Chọn `BẮT ĐẦU NHẬN DIỆN`, Android sẽ hỏi quyền ghi/đọc màn hình qua MediaProjection. Chọn chia sẻ **toàn màn hình**.
4. Mở TikTok LIVE. Bảng nổi có thể kéo bằng hàng tiêu đề. Từ bảng nổi, bấm `Đổi chế độ` để bật/tắt tự bấm.
5. Bấm `Dừng` khi xong để đóng đọc màn hình và bảng nổi.

## Cách nhận diện và các giới hạn

- App sử dụng **Google ML Kit Text Recognition on-device**, đọc hình từ MediaProjection. Không chụp hình lưu xuống bộ nhớ và không gửi hình lên server.
- Thuật toán chỉ tìm các từ nhận diện rương (*rương, kho báu, treasure, lucky box, chest, gift box*) và đồng hồ `mm:ss` ở gần nhau. Có thể nhầm các dòng chữ trong video/chat với rương, đặc biệt khi giao diện đổi hoặc phông chữ nhỏ.
- Khi đọc được thời gian **còn 1–5 giây**, app có thể rung và đổi nội dung thông báo. Đây là **ước lượng OCR**, không phải đồng hồ đồng bộ chính thức TikTok.
- Chế độ **tự bấm thử** dùng AccessibilityService để phát **một lần chạm** ở vị trí OCR nhận ra nút **Mở/Nhận/Open/Claim** cạnh chữ rương, khi OCR thấy `00:00` hoặc nút nhận xuất hiện vài giây sau một đồng hồ `00:05`–`00:01` đã thấy, chỉ khi TikTok đang là ứng dụng được nhận diện, và có thời gian nghỉ để tránh lặp liên tục. Nếu màn hình đổi nhanh, chữ khác, hoặc đồng hồ biến mất ngay lúc 0:00, app có thể **không bấm**. Không tự vượt captcha, không tự đăng nhập, không dò tìm LIVE.
- Cử chỉ có thể chạm **nhầm vị trí** do OCR/độ phân giải, nên **tắt tự bấm theo mặc định**. Đừng sử dụng để thao tác mua hàng, thanh toán, dữ liệu cá nhân.
- Việc tự động tương tác với TikTok có nguy cơ vi phạm điều khoản nền tảng, bị chặn thao tác hoặc hạn chế tài khoản. Không có gì bảo đảm nhận được xu.
- Phù hợp thử trên thiết bị Android 8 trở lên, mục tiêu Android 15. Android 14+ yêu cầu xác nhận chia sẻ màn hình mỗi phiên. Ứng dụng **chưa được chạy kiểm thử thực tế** trên các thiết bị và phiên bản TikTok.
- Nếu xoay màn hình, thay đổi độ phân giải hoặc quyền bị thu hồi trong lúc chạy, hãy dừng rồi bật lại.

## Quyền cần thiết

| Quyền | Mục đích |
| --- | --- |
| Hiển thị trên ứng dụng khác | Bảng nổi có thể kéo |
| Chụp/chia sẻ màn hình qua MediaProjection | OCR chữ và đồng hồ rương |
| Trợ năng (tuỳ chọn) | Chỉ để gửi cử chỉ chạm một lần trong chế độ tự bấm thử |
| Thông báo | Hiển thị tiến độ và cảnh báo |
| Rung | Rung khi rương gần hết thời gian |

## Quyền riêng tư

Không có permission `INTERNET` trong manifest. Không cần tên đăng nhập, mật khẩu, cookie TikTok. Bản mã nguồn đủ để kiểm tra logic của app trước khi cài.

## Trạng thái hiện tại

Đây là **mã nguồn chưa biên dịch**, không phải APK đã cài được. Để tạo file APK cần Android SDK/Gradle và môi trường tải phụ thuộc. Nếu ứng dụng lỗi build, xem Android Studio build log và cập nhật SDK/Gradle phù hợp.

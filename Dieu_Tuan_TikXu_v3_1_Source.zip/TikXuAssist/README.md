# ĐIỂU TUẤN • TikXu v3 — thử nghiệm Android

**Trạng thái:** Mã nguồn thử nghiệm. Chưa có APK v3 đã biên dịch và thử trực tiếp trên TikTok trong gói này. Các nút trong giao diện thật có xử lý sự kiện nhưng nhận diện phụ thuộc OCR và UI TikTok.

## Có trong mã nguồn v3

- Ảnh gốc chủ app làm nền; avatar, đăng nhập offline bằng mật khẩu cũ nhưng **ký tự được che** (không hiển thị mật khẩu dưới dạng chữ rõ).
- Nút `TikTok của ĐIỂU TUẤN` mở trang `https://www.tiktok.com/@tuan203dnbp93` trong trình duyệt/TikTok.
- Nút bật/tắt lọc `Nhặt rương` và `Nhặt túi`, có trên dashboard và bảng nổi kéo thả/thu nhỏ.
- OCR tìm đồng hồ gần biểu tượng ở vùng góc trên bên trái LIVE, kiểm tra màu đỏ/tím của biểu tượng, **thử tự mở** khi bật quyền và chế độ đó. Đọc điều kiện bình luận, chia sẻ hoặc Fan Club (heuristic).
- Phát hiện nút `Nhận/Mở` nếu sau countdown và có chữ rõ ràng, thử nhấn một lần nếu người dùng bật **Tự chạm**. Không đảm bảo nhận được xu.
- `Săn room` là chế độ **tùy chọn, mặc định tắt**, 9 giây không thấy quà thì thử vuốt sang LIVE khác, tối đa 20 lần mỗi phiên quét; có thể tạm dừng.
- Chỉ chạy thao tác chạm khi cửa sổ TikTok ở trước mặt. Không yêu cầu tài khoản/mật khẩu TikTok và không gửi ảnh màn hình lên máy chủ.

## Giới hạn quan trọng

- **KHÔNG** tự thực hiện đăng bình luận, sao chép/chia sẻ link, tham gia Fan Club, gửi quà hay nạp tiền. Khi OCR nhận ra điều kiện sẽ **hiển thị hướng dẫn để người dùng tự xác nhận**. Mọi nút `Gửi/Nạp/Tham gia` không được chọn làm nút nhận xu.
- **CHƯA có** chức năng mã 6 số tự đổi mỗi ngày lúc 00:00 và gửi tới Gmail. Muốn làm an toàn cần dịch vụ xác thực và gửi email ngoài APK, không hardcode Gmail/API key trong repo công khai; app vẫn giữ khóa offline.
- Nhận diện biểu tượng qua OCR và sắc màu có thể bỏ sót do TikTok đổi UI, độ phân giải, LIVE PK, người xem chọn quà. Cần kiểm thử riêng từng giao diện và cấp quyền hiển thị nổi/Trợ năng/chia sẻ màn hình.
- Google Play Protect có thể chặn APK thử nghiệm, nhất là APK dùng dịch vụ Trợ năng. Không tắt các cơ chế bảo vệ để buộc cài đặt.
- Tự thao tác hay tự lướt có thể không được TikTok cho phép hoặc bị hạn chế tài khoản.
- ZIP này chứa ảnh cá nhân, đừng công khai nếu không muốn người khác tải ảnh.

## Xuất APK (GitHub Actions)

Giữ cấu trúc ZIP `TikXuAssist/...` và tải lên GitHub theo tên `Dieu_Tuan_TikXu_v3_Source.zip`. Ở repo có `.github/workflows/build-apk.yml`; sửa dòng `unzip` thành `unzip -q Dieu_Tuan_TikXu_v3_Source.zip` và giữ workflow từng chạy thành công (setup-java v4, setup-android v4, setup-gradle v4, Gradle 8.9). Chạy Actions → Run workflow. Tải artifact ZIP rồi giải nén `app-debug.apk`.

Ứng dụng cần cấp quyền riêng từng bước. **Kiểm tra từng nút thủ công trên tài khoản thử nghiệm** trước khi bật các chế độ tự động.

## v3.1: Quay màn hình riêng khi xem LIVE — thử nghiệm

- Bấm `BẮT ĐẦU QUÉT LIVE`, cấp quyền **chia sẻ toàn bộ màn hình**, mở TikTok; bấm nút `⏺ Quay LIVE` trên bảng nổi. Hoặc ngay trên dashboard bấm `BẮT ĐẦU QUAY VIDEO` rồi cấp quyền chia sẻ màn hình.
- Bấm `■ Dừng quay` để hoàn tất MP4. Trên Android 10+ xem trong **Thư viện/Video → Movies/TikXu**. Video chỉ lưu cục bộ, không tự tải lên mạng và **không có tiếng**.
- Ghi video từ cùng luồng `MediaProjection` đang phục vụ OCR; không mở phiên ghi màn hình thứ hai để tránh việc app/trình quay hệ thống tranh quyền. Không cần bật trình quay của máy cùng lúc.
- Chế độ này *không* xử lý hay vượt qua nội dung bị `FLAG_SECURE`, DRM, chính sách cấm ghi hình của TikTok/Android. Nếu TikTok trả khung hình đen, MP4 vẫn đen; không thể cam kết sửa tình trạng đó.
- **Chưa có kiểm thử Android thực tế.** Phần mã mới đang ở trạng thái thử nghiệm, cần Build trên GitHub và thử quay ngắn 5–10 giây, dừng, xác minh tệp MP4 trước khi quay lâu. Hiệu năng dự kiến ~8 fps, tối đa 540×960, tiết kiệm pin hơn quay HD nhưng chất lượng hạn chế.
- Nếu nguồn TikTok có phần LIVE riêng bị đen, cần tôn trọng chặn quay từ nền tảng. Không tắt Play Protect hoặc bảo vệ máy.
- ZIP bao gồm `TikXuAssist/...`; đặt trên GitHub tên `Dieu_Tuan_TikXu_v3_1_Source.zip`, thay tên trong bước `unzip` của workflow cũ rồi mới chạy GitHub Actions.

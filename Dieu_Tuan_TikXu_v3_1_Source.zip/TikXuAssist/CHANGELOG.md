# v3
- UI: ảnh nền cá nhân, bảng neon với chế độ thu nhỏ, hai nút lọc rương/túi và chọn săn room.
- Phát hiện: OCR timer góc trên + phân biệt màu sắc biểu tượng, hướng dẫn điều kiện tham gia.
- Chạm: khóa an toàn TikTok foreground, tối đa một lần thử bấm nhận mỗi chu kỳ, chống chạm Gửi/Nạp.
- Săn room: tùy chọn, đợi 9 giây, tối đa 20 lần, có tạm dừng.
- Bảo mật: input che mật khẩu, liên kết trang cá nhân TikTok.
- Chưa hỗ trợ: Gmail mã tự đổi 0h; tự gửi bình luận/share/Fan Club.

# v3.1 — Quay màn hình trong app (bản thử nghiệm)
- Nút quay riêng trên dashboard và bảng nổi: Bắt đầu/Dừng MP4.
- Quay dùng cùng MediaProjection đã được người dùng cấp cho chế độ OCR. Không mở màn hình xin quyền lần hai trong phiên quét, tránh xung đột với trình quay khác.
- Khi nhấn Quay trước khi quét, app xin quyền chia sẻ màn hình rồi bắt đầu cả quét và quay; có trạng thái ● ĐANG QUAY MP4.
- Lưu MP4 không âm thanh, tối đa ~540x960 / 8 FPS, vào Movies/TikXu (Android 10+).
- Bỏ FLAG_SECURE khỏi bảng nổi của chính app, để bảng nổi có thể xuất hiện trong video.
- Nếu một nội dung bị TikTok/Android đánh dấu bảo vệ thì nó vẫn có thể bị đen; ứng dụng không vượt qua cơ chế bảo vệ này.
- Chưa kiểm thử ghi hình bằng điện thoại thật, hiệu năng, độ tương thích encoder/Play Protect vẫn chưa xác nhận.

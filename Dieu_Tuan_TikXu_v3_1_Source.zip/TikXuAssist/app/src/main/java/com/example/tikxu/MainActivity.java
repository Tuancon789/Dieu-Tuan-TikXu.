package com.example.tikxu;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Offline passcode gate and live-capture controls. No account credentials collected. */
public class MainActivity extends Activity {
    private static final int CAPTURE_REQUEST = 111;
    private static final String PASS_HASH =
        "b9f799a1ec95e7eb27c9752d2028d403d39c0ace2208289d590548373e7b358c";
    private final int BG = 0xff0a1023, PANEL = 0xff162140, CYAN = 0xff49dfeb;
    private SharedPreferences prefs;
    private TextView status;
    private boolean unlocked = false;
    private boolean autoRecordOnConsent = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tikxu", MODE_PRIVATE);
        showLogin();
    }

    private boolean passMatches(String input) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                .digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            for (byte c : hash) b.append(String.format("%02x", c & 0xff));
            return MessageDigest.isEqual(b.toString().getBytes(StandardCharsets.US_ASCII),
                PASS_HASH.getBytes(StandardCharsets.US_ASCII));
        } catch (Exception e) { return false; }
    }

    /** Reuse the user's own photo behind a dark scrim on the login and dashboard screens. */
    private LinearLayout page() {
        FrameLayout frame = new FrameLayout(this);
        ImageView backgroundPhoto = new ImageView(this);
        backgroundPhoto.setImageResource(R.drawable.tuan_photo);
        backgroundPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(backgroundPhoto, new FrameLayout.LayoutParams(-1, -1));

        View tint = new View(this);
        tint.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[] {0xd20a0820, 0x930a0c26, 0xee070a1b}));
        frame.addView(tint, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(32), dp(22), dp(30));
        scroller.addView(root);
        frame.addView(scroller, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        return root;
    }

    private void showLogin() {
        status = null;
        LinearLayout root = page();
        space(root, 34);
        TextView brand = label("  ✦  ĐIỂU TUẤN  •  TikXu", 14, 0xff7feaff, true);
        root.addView(brand);
        space(root, 32);
        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.tuan_avatar);
        avatar.setContentDescription("Ảnh đại diện ĐIỂU TUẤN");
        root.addView(avatar, new LinearLayout.LayoutParams(dp(88), dp(88)));
        space(root, 28);
        root.addView(label("ĐIỂU TUẤN • TikXu", 29, Color.WHITE, true));
        space(root, 9);
        root.addView(label("Đăng nhập để mở trợ lý TikTok LIVE.",
            15, 0xffb9c9e8, false));
        space(root, 32);
        LinearLayout card = card();
        root.addView(card);
        card.addView(label("🔒  MẬT KHẨU RIÊNG", 12, CYAN, true));
        space(card, 12);
        EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setTextColor(Color.WHITE);
        password.setHintTextColor(0xff8b9dbb);
        password.setHint("••••••");
        password.setTextSize(17);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.setTransformationMethod(PasswordTransformationMethod.getInstance());
        password.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        password.setSaveEnabled(false);
        password.setPadding(dp(16), 0, dp(16), 0);
        password.setBackground(gradient(0xff111a31, 0xff172442, dp(14), 0xff385075));
        card.addView(password, new LinearLayout.LayoutParams(-1, dp(56)));
        space(card, 12);
        TextView error = label("", 13, 0xffff9eac, false);
        card.addView(error);
        Button unlock = action("MỞ KHÓA  →", true);
        card.addView(unlock, buttonParams());
        unlock.setOnClickListener(v -> {
            if (passMatches(password.getText().toString())) {
                unlocked = true;
                showDashboard();
            } else {
                error.setText("Sai mật khẩu. Thử lại nhé!");
                password.setText("");
            }
        });
        space(root, 28);
        root.addView(label("◉  Dữ liệu OCR xử lý trên điện thoại. Không cần đăng nhập TikTok.",
            12, 0xff9caed0, false));
        space(root, 13);
        root.addView(label("Lưu ý: đây là khóa offline tiện dụng, không bảo mật như máy chủ xác thực.",
            12, 0xff8a9cbd, false));
    }

    private void showDashboard() {
        LinearLayout root = page();
        root.addView(label("✦  ĐIỂU TUẤN     /     LIVE ASSIST", 12, CYAN, true));
        space(root, 13);
        root.addView(label("TikXu Control   ✦", 32, Color.WHITE, true));
        root.addView(label("Rương Báu  •  Túi quà  •  Bảng nổi thông minh",
            14, 0xffb9c9e8, false));
        space(root, 21);

        LinearLayout statusCard = card();
        root.addView(statusCard);
        statusCard.addView(label("●  TRẠNG THÁI HỆ THỐNG", 12, 0xff68f0bc, true));
        space(statusCard, 10);
        status = label("Đang kiểm tra quyền...", 14, Color.WHITE, false);
        statusCard.addView(status);
        space(statusCard, 11);
        statusCard.addView(label("📍  Tìm biểu tượng + đọc đồng hồ ngay trên LIVE",
            13, 0xffb4cbe8, false));
        space(root, 16);

        root.addView(label("QUYỀN ỨNG DỤNG", 12, CYAN, true));
        space(root, 9);
        Button overlay = action("①  Cấp quyền hiển thị bảng nổi", false);
        root.addView(overlay, buttonParams());
        overlay.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName()))));
        Button access = action("②  Bật Trợ năng (nếu muốn tự chạm)", false);
        root.addView(access, buttonParams());
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        if (Build.VERSION.SDK_INT >= 33) {
            Button notice = action("③  Cho phép thông báo", false);
            root.addView(notice, buttonParams());
            notice.setOnClickListener(v -> {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 10);
            });
        }
        space(root, 17);
        root.addView(label("⚡  THAO TÁC NHANH", 13, CYAN, true));
        space(root, 8);
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(actionRow);
        Button chestMode = action("🪙 Nhặt rương", true);
        Button bagMode = action("🎁 Nhặt túi", true);
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, dp(64), 1);
        left.rightMargin=dp(7);
        actionRow.addView(chestMode,left);
        actionRow.addView(bagMode,new LinearLayout.LayoutParams(0,dp(64),1));
        chestMode.setOnClickListener(v -> {
            boolean enabled = !prefs.getBoolean("chest_enabled",true);
            prefs.edit().putBoolean("chest_enabled",enabled).apply();
            chestMode.setText(enabled?"🪙 Rương: BẬT":"🪙 Rương: TẮT");
        });
        bagMode.setOnClickListener(v -> {
            boolean enabled = !prefs.getBoolean("bag_enabled",true);
            prefs.edit().putBoolean("bag_enabled",enabled).apply();
            bagMode.setText(enabled?"🎁 Túi: BẬT":"🎁 Túi: TẮT");
        });
        chestMode.setText(prefs.getBoolean("chest_enabled",true)?"🪙 Rương: BẬT":"🪙 Rương: TẮT");
        bagMode.setText(prefs.getBoolean("bag_enabled",true)?"🎁 Túi: BẬT":"🎁 Túi: TẮT");
        Button hunt = action("🔎  Tự săn room (tối đa 20 LIVE/phiên)", false);
        root.addView(hunt,buttonParams());
        hunt.setText(prefs.getBoolean("auto_swipe",false)?"🔎 Săn room: BẬT":"🔎 Săn room: TẮT");
        hunt.setOnClickListener(v->{
            boolean e=!prefs.getBoolean("auto_swipe",false);
            prefs.edit().putBoolean("auto_swipe",e).apply();
            hunt.setText(e?"🔎 Săn room: BẬT":"🔎 Săn room: TẮT");
        });
        space(root, 13);
        LinearLayout modeCard = card();
        root.addView(modeCard);
        modeCard.addView(label("✧  CHẾ ĐỘ NHẬN DIỆN", 14, Color.WHITE, true));
        space(modeCard, 8);
        addToggle(modeCard, "Tự mở biểu tượng (đang thử nghiệm)", "auto_open", false);
        addToggle(modeCard, "Thử tự bấm nhận khi đủ điều kiện", "auto_tap", false);
        space(modeCard, 8);
        modeCard.addView(label("⚠ Chỉ thử nhận diện khi TikTok đang mở. Không tự đăng bình luận, gửi link, tham gia Fan Club hoặc bấm Gửi/Nạp. Nhận diện màu/OCR có thể sai; tự bấm có thể bị giới hạn tài khoản.",
            12, 0xffffc3ab, false));
        space(root, 17);
        root.addView(label("🎥  QUAY MÀN HÌNH RIÊNG", 13, CYAN, true));
        space(root,8);
        LinearLayout recordCard = card();
        root.addView(recordCard);
        recordCard.addView(label("Quay MP4 trong app, dùng chung quyền màn hình với quét rương.",
            13, Color.WHITE, false));
        recordCard.addView(label("Video không có âm thanh • lưu vào Movies/TikXu • ~8 FPS. " +
            "Nội dung TikTok được bảo vệ vẫn có thể đen; không thể vượt chặn.",
            12, 0xffb4cbe8, false));
        Button recordingToggle=action("⏺  BẮT ĐẦU QUAY VIDEO", true);
        root.addView(recordingToggle,buttonParams());
        recordingToggle.setOnClickListener(v -> {
            if (CaptureService.activeCapture) {
                Intent command=new Intent(this,CaptureService.class);
                command.setAction(CaptureService.ACTION_RECORD_TOGGLE);
                startService(command);
                status.setText("Đã gửi lệnh bật/tắt quay. Xem trạng thái trên bảng nổi.");
            } else {
                autoRecordOnConsent=true;
                startCapture();
            }
        });
        Button start = action("▶  BẮT ĐẦU QUÉT LIVE", true);
        root.addView(start, buttonParams());
        start.setOnClickListener(v -> { autoRecordOnConsent=false; startCapture(); });
        Button stop = action("■  DỪNG QUÉT", false);
        root.addView(stop, buttonParams());
        stop.setOnClickListener(v -> { stopService(new Intent(this, CaptureService.class));
            if (status != null) status.setText("Đã dừng quét màn hình."); });
        space(root, 13);
        root.addView(label("Cách dùng: bật quyền → Bắt đầu quét → cho phép chia sẻ TOÀN BỘ màn hình → mở TikTok LIVE. " +
            "Ứng dụng sẽ thử phát hiện bộ đếm ở góc trên. Tính năng phụ thuộc giao diện TikTok, không đảm bảo nhận xu.",
            13, 0xff9fb5d1, false));
        space(root, 14);
        root.addView(label("KẾT NỐI VÀ BẢO MẬT", 12, CYAN, true));
        space(root, 8);
        Button social = action("♪  TIKTOK CỦA ĐIỂU TUẤN   ↗", true);
        root.addView(social,buttonParams());
        social.setOnClickListener(v->{
            Intent link=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@tuan203dnbp93"));
            try { startActivity(link); } catch(Exception e) {
                if(status!=null)status.setText("Chưa có ứng dụng mở liên kết TikTok.");
            }
        });
        LinearLayout secure = card();
        root.addView(secure);
        secure.addView(label("🔐 Mã mới lúc 00:00 (giờ Việt Nam)",14,Color.WHITE,true));
        space(secure,8);
        secure.addView(label("Chưa kích hoạt gửi Gmail: cần máy chủ xác thực + dịch vụ email. " +
          "Khóa offline hiện tại vẫn hoạt động; ô nhập luôn che ký tự. " +
          "Không đưa Gmail hay khóa gửi mail vào kho GitHub công khai.",12,0xffffc3ab,false));
        space(root, 12);
        Button lock = action("🔒  KHÓA ỨNG DỤNG", false);
        root.addView(lock, buttonParams());
        lock.setOnClickListener(v -> { unlocked = false; showLogin(); });
        refreshStatus();
    }

    private void addToggle(LinearLayout parent, String name, String pref, boolean defaultValue) {
        CheckBox toggle = new CheckBox(this);
        toggle.setText(name);
        toggle.setTextColor(Color.WHITE);
        toggle.setTextSize(13);
        toggle.setButtonTintList(android.content.res.ColorStateList.valueOf(CYAN));
        toggle.setChecked(prefs.getBoolean(pref, defaultValue));
        toggle.setOnCheckedChangeListener((button, value) -> prefs.edit().putBoolean(pref, value).apply());
        parent.addView(toggle, new LinearLayout.LayoutParams(-1, dp(49)));
    }

    private void startCapture() {
        if (!unlocked) return;
        if (!Settings.canDrawOverlays(this)) { status.setText("Hãy bật quyền hiển thị nổi trước!"); return; }
        if ((prefs.getBoolean("auto_open", false) || prefs.getBoolean("auto_tap", false)) &&
            !TapAccessibilityService.isReady()) {
            status.setText("Chưa bật Trợ năng. Vẫn có thể quét và cảnh báo, nhưng không tự bấm.");
        }
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), CAPTURE_REQUEST);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != CAPTURE_REQUEST || !unlocked) return;
        if (result != RESULT_OK || data == null) {
            autoRecordOnConsent=false;
            status.setText("Chưa cấp quyền chia sẻ màn hình."); return;
        }
        Intent i = new Intent(this, CaptureService.class);
        i.setAction(CaptureService.ACTION_START);
        i.putExtra(CaptureService.EXTRA_RESULT_CODE, result);
        i.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
        i.putExtra(CaptureService.EXTRA_AUTO_RECORD,autoRecordOnConsent);
        autoRecordOnConsent=false;
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText("Đang khởi động. Hãy chuyển sang TikTok LIVE.");
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }
    private void refreshStatus() {
        if (status == null) return;
        status.setText("Bảng nổi: " + (Settings.canDrawOverlays(this) ? "✓ BẬT" : "✕ CHƯA BẬT") +
            "   •   Trợ năng: " + (TapAccessibilityService.isReady() ? "✓ BẬT" : "✕ CHƯA BẬT"));
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(20), dp(18), dp(20));
        box.setBackground(gradient(0xff182443, 0xff121d38, dp(20), 0xff486499));
        return box;
    }
    private Button action(String text, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(text);
        b.setTextSize(14); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setBackground(primary ? gradient(0xff247feb, 0xff754ae7, dp(14), CYAN)
            : gradient(0xff1c2d50, 0xff18233e, dp(14), 0xff385781));
        return b;
    }
    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(53));
        p.bottomMargin = dp(9); return p;
    }
    private GradientDrawable gradient(int a, int b, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {a, b});
        g.setCornerRadius(radius);
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void space(LinearLayout p, int n) { p.addView(new View(this), new LinearLayout.LayoutParams(1, dp(n))); }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
}

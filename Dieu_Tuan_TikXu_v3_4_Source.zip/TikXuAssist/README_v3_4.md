# ĐIỂU TUẤN • TikXu v3.4 (thử nghiệm)

**Chức năng chính:** Săn rương từ LIVE đang hiển thị. Nhặt rương 1 phòng hoặc nhiều phòng; tap tim theo ID TikTok và hẹn giờ trên bảng nổi. Giữ xác thực qua Cloudflare Worker/D1 bản cũ.

## Các điểm mới

- **Không quay màn hình / không xin MediaProjection:** dùng quyền Trợ năng với `takeScreenshot()` (Android 11+) để lấy từng ảnh màn hình và xử lý bằng OCR ML Kit **trên máy**. Không truyền ảnh TikTok lên máy chủ.
- Săn nhiều phòng: trên trang Đề xuất tìm chữ LIVE góc trên trái, nhấn vào; xác nhận giao diện LIVE trước khi vuốt. Tìm rương trong 6 giây; không thấy thì vuốt.
- Canh 1 phòng: chỉ kiểm tra rương trên LIVE hiện tại, tuyệt đối không vuốt chuyển phòng.
- Với rương: đối chiếu mẫu icon từ ảnh người dùng, hoặc nhãn Trợ năng; kiểm tra nút **Mở**, OCR đồng hồ, thử nút **Nhận**, đọc mẫu **Bạn đã nhận được X Xu!**, sau đó đóng dialog bằng BACK và kiểm tra thêm 10 giây. **Không** bấm nút Gửi Quà tặng.
- Tách bạch tổng xu trong rương (có thể từ 1 xu) với số xu thực nhận; chỉ tính `X` khi OCR đọc được thông báo TikTok.
- Bóng nổi có thống kê tổng xu thực nhận, thời gian rương, nút tạm dừng và dừng; bánh răng mở cấu hình ID, giờ HH:mm, số phút, tap tim 10K/20K/50K/100K.
- ADMIN có thể duy trì quản lý tài khoản với Worker đã cài; không đổi database và không đặt mật khẩu ADMIN vào mã nguồn.

## Cách thử

1. Cài bản debug mới sau khi GitHub Actions báo xanh. Đăng nhập tài khoản trên máy chủ HTTPS hiện có.
2. Cấp quyền Trợ năng và hiển thị bảng nổi. Trợ năng cần cho phép chụp ảnh màn hình; nếu Android/TikTok từ chối, app sẽ ngừng thay vì tự bấm mò.
3. Bấm **SĂN RƯƠNG NHIỀU PHÒNG**, app mở TikTok. Từ tab video Đề xuất, app thử tìm chữ LIVE ở góc trái; mỗi phòng quét trong 6 giây. Hoặc bấm **CANH RƯƠNG 1 PHÒNG** khi muốn ở nguyên LIVE.
4. Bấm **Tap ❤️** nếu muốn xem LIVE theo ID. Mở bánh răng trên bảng nổi, nhập `@id`, giờ `HH:mm` (bỏ trống để bắt đầu ngay), thời lượng tính theo phút; chọn 10K–100K rồi HẸN TAP. Đây chỉ đếm các cử chỉ được gửi, **không bảo đảm TikTok ghi nhận số tim**.
5. Dừng bằng nút **■ DỪNG** ở bảng nổi hoặc app.

## Giới hạn và an toàn

- Đây là **bản kỹ thuật thử nghiệm**, **chưa được xác minh trên TikTok LIVE thực tế**. GitHub Build xanh chỉ xác nhận mã APK biên dịch thành công, không bảo đảm nhận diện/tự nhận thưởng.
- Mẫu icon trích từ một ảnh chụp LIVE cung cấp. Các rương khác, túi quà, thay đổi giao diện hoặc độ phân giải có thể không trùng. Một số ảnh/nhãn trong TikTok có thể bị ẩn với Android Accessibility.
- Khi không thấy trạng thái phù hợp, app dừng an toàn; một số cửa sổ rương cần xử lý thủ công. Không bảo đảm tự nhận mọi rương và không ép người dùng bấm Gửi Quà tặng.
- Hẹn giờ chạy trong một phiên Trợ năng đang hoạt động; Android có thể đóng ứng dụng/chế độ nền khiến lịch không thực hiện.
- Không gửi ảnh hoặc ID tài khoản TikTok lên Worker. Worker chỉ dùng xác thực tài khoản TikXu.
- Việc dùng tự động hóa TikTok có thể bị TikTok giới hạn hoặc xử lý theo điều khoản nền tảng.

## Tệp quan trọng

- `app/src/main/java/com/example/tikxu/LiveHuntV34.java`: luồng trạng thái và bảng nổi
- `app/src/main/java/com/example/tikxu/VisionReader.java`: chụp ảnh tức thời + OCR + icon matcher
- `app/src/main/java/com/example/tikxu/TapAccessibilityService.java`: dispatch gestures qua Accessibility
- `app/src/main/assets/chest_sample_*.png`: mẫu icon rương do người dùng cung cấp
- `.github/workflows/build-apk.yml`: build Android v3.4

**Lưu ý:** Không tự ý thay/mất Worker ADMIN hoặc xóa cơ sở dữ liệu Cloudflare D1.

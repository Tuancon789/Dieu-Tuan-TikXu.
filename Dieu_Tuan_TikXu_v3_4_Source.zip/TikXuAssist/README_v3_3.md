# ĐIỂU TUẤN • TikXu v3.3 — Thử nghiệm săn LIVE từ danh sách

- Chức năng mới dùng `AccessibilityService` đọc cây nút/thẻ phòng **trong TikTok**; không sử dụng ghi màn hình (MediaProjection) cho chế độ này.
- Người dùng **phải tự mở danh sách TikTok LIVE** và bật Trợ năng TikXu. Bắt đầu trong ứng dụng TikXu; TikTok sẽ được mở để tự điều hướng vào danh sách LIVE.
- App chọn thẻ phòng LIVE **có nhãn có thể đọc được**, vào thử, quét nút rương/túi quà có nhãn, bấm mở, đợi đếm ngược nếu nút giờ có thể đọc; sau đó đóng modal, quay lại danh sách và chờ 15 giây.
- **Không bảo đảm** tìm được phòng có rương từ ngoài phòng. Nếu TikTok vẽ các biểu tượng bằng canvas không có accessibility label, chế độ này sẽ không thể nhận diện. Khi thiếu tín hiệu, app không tự đoán tọa độ để chạm.
- Không tự bấm nút Nhận nếu rương hết giờ, không gửi bình luận, quà hoặc tiền, không vượt captcha/giới hạn. Việc tham gia nhận xu của TikTok không được bảo đảm.
- Timeout bảo vệ: 15s quét phòng, 90s nếu không đọc được đồng hồ (có giới hạn 10 phút), 2 lần thử mở biểu tượng, 3 lần đóng modal; dừng nếu không thể quay về danh sách.
- Nút bảng nổi: Tạm dừng / Dừng.
- Tên gói Android và API backend giữ nguyên để dữ liệu đăng nhập/ADMIN không mất khi cập nhật.
- Quay màn hình kiểu cũ v3.2 vẫn ở trong app như chức năng riêng; **chế độ mới không khởi động nó**.

## Build

Android SDK 35, Gradle 8.9, JDK 17. Tại `TikXuAssist`: `gradle :app:assembleDebug`.

## Kiểm tra trước khi phát hành

Dùng màn hình TikTok LIVE thực tế (có permission) xác nhận nhận diện thẻ LIVE, nhãn nút rương, đồng hồ đếm ngược và nút đóng. Phải thử bản beta với việc không đọc được nút; app sẽ thông báo hoặc dừng, không chạy mù. Xây dựng APK thành công không đồng nghĩa tính năng sẽ hoạt động với mọi phiên bản TikTok.

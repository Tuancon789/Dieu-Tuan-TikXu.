package com.example.tikxu;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.InputType;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Administrator actions always go through the role-checked HTTPS backend. */
public class AdminActivity extends Activity {
    private LinearLayout root,usersHolder;
    private TextView result, emergencyView;
    private EditText duration, username, password, notice;
    private boolean emergency=false;
    private SharedPreferences options;
    private final int CYAN=0xff5eece5;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(!AuthApi.isAdmin(this) || AuthApi.token(this).isEmpty()){finish();return;}
        options=getSharedPreferences("tikxu",MODE_PRIVATE);
        render();
        execute(()->AuthApi.request(this,"GET","/v1/me",null,true), data->{
            if(!"ADMIN".equals(data.optString("role"))){finish();return;}
            emergency=data.optBoolean("emergency_stop");refreshEmergency();
        });
    }
    private void render(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xff090f24);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(30),dp(18),dp(48));scroll.addView(root);setContentView(scroll);
        root.addView(label("♛   ĐIỂU TUẤN • TikXu",15,CYAN,true));
        spacer(root,9);
        root.addView(label("ADMIN CENTER",30,Color.WHITE,true));
        root.addView(label("Chỉ tài khoản ADM có quyền sử dụng",13,0xffa4b7d6,false));
        spacer(root,15);
        result=label("Kiểm tra quyền trên máy chủ…",13,0xffffc89d,false);root.addView(result);
        spacer(root,14);
        LinearLayout create=panel("✦  TẠO TÀI KHOẢN MỚI");
        create.addView(label("Tên đăng nhập",12,CYAN,true));
        username=input("khach001",false);create.addView(username,layout(50));
        create.addView(label("Mật khẩu tối thiểu 8 ký tự",12,CYAN,true));
        password=input("Nhập mật khẩu người dùng",true);create.addView(password,layout(50));
        create.addView(label("Thời hạn cấp / gia hạn (ngày)",12,CYAN,true));
        duration=input("45",false);duration.setInputType(InputType.TYPE_CLASS_NUMBER);
        duration.setText("45");create.addView(duration,layout(50));
        Button createButton=button("＋  TẠO TÀI KHOẢN • MẶC ĐỊNH 45 NGÀY");create.addView(createButton,layout(54));
        createButton.setOnClickListener(v->{
            int days=days();
            if(days<1)return;
            try{
                JSONObject p=new JSONObject().put("username",username.getText().toString().trim())
                    .put("password",password.getText().toString()).put("days",days);
                execute(()->AuthApi.request(this,"POST","/v1/admin/users",p,true),d->{
                    password.setText("");feedback("Đã tạo tài khoản. Hết hạn: "+date(d.optLong("expires_at")));
                    loadUsers();
                });
            }catch(Exception e){feedback(e.getMessage());}
        });
        spacer(root,13);
        LinearLayout accounts=panel("♧  DANH SÁCH & GIA HẠN / KHÓA");
        Button reload=button("↻  TẢI DANH SÁCH TÀI KHOẢN");accounts.addView(reload,layout(49));
        reload.setOnClickListener(v->loadUsers());
        usersHolder=new LinearLayout(this);usersHolder.setOrientation(LinearLayout.VERTICAL);
        accounts.addView(usersHolder);loadUsers();
        spacer(root,13);
        LinearLayout tools=panel("⚙  QUẢN TRỊ ỨNG DỤNG");
        tools.addView(label("Thời gian chờ room không có quà (5–60 giây)",13,Color.WHITE,false));
        for (int seconds:new int[]{15,30,60}) {
            Button b=button(seconds+" GIÂY");tools.addView(b,layout(45));
            b.setOnClickListener(v->{options.edit().putInt("hunt_wait_secs",seconds).apply();feedback("Chờ "+seconds+" giây trước khi lướt room không quà");});
        }
        Button theme=button("✦  ĐỔI NỀN / HIỆU ỨNG NEON");tools.addView(theme,layout(47));
        theme.setOnClickListener(v->{boolean enabled=!options.getBoolean("theme_neon",true);
            options.edit().putBoolean("theme_neon",enabled).apply();feedback("Hiệu ứng neon: "+(enabled?"BẬT":"TẮT")+" (áp dụng lần mở app tiếp theo)");});
        spacer(root,13);
        LinearLayout stats=panel("▥  THỐNG KÊ / NHẬT KÝ CỤC BỘ");
        TextView statistics=label("",13,Color.WHITE,false);stats.addView(statistics);
        Button refreshStats=button("↻  LÀM MỚI THỐNG KÊ");stats.addView(refreshStats,layout(46));
        TextView logs=label("",12,0xffb3c5e5,false);stats.addView(logs);
        Runnable showStats=()->{
            statistics.setText("Room đã lướt: "+options.getInt("stat_swipes",0)+
                "  •  Lần thấy rương/túi: "+options.getInt("stat_detect",0)+
                "\nThao tác thử nhận: "+options.getInt("stat_claims",0)+" (không phải xu đã nhận)");
            logs.setText("Nhật ký gần đây:\n"+options.getString("log_recent","Chưa có dữ liệu"));
        };
        showStats.run();refreshStats.setOnClickListener(v->showStats.run());
        spacer(root,13);
        LinearLayout notifications=panel("✉  THÔNG BÁO ADMIN");
        notice=input("Nội dung hiển thị cho mọi tài khoản khi kiểm tra phiên",false);
        notifications.addView(notice,layout(55));
        Button push=button("GỬI THÔNG BÁO");notifications.addView(push,layout(49));
        push.setOnClickListener(v->{
            try{JSONObject p=new JSONObject().put("text",notice.getText().toString());
                execute(()->AuthApi.request(this,"POST","/v1/admin/notice",p,true),x->feedback("Đã cập nhật thông báo máy chủ"));
            }catch(Exception e){feedback(e.getMessage());}
        });
        spacer(root,13);
        LinearLayout security=panel("⏹  DỪNG KHẨN CẤP TỪ XA");
        emergencyView=label("Đang kiểm tra…",13,0xffffc89d,true);security.addView(emergencyView);
        Button stop=button("BẬT / TẮT DỪNG KHẨN CẤP");security.addView(stop,layout(50));
        stop.setOnClickListener(v->{
            try{boolean next=!emergency;JSONObject p=new JSONObject().put("stopped",next);
                execute(()->AuthApi.request(this,"POST","/v1/admin/emergency",p,true),data->{
                    emergency=next;refreshEmergency();
                    if(next)TapAccessibilityService.stop();
                    feedback(next?"Đã yêu cầu dừng các thiết bị khi kiểm tra phiên":"Đã bật lại quyền sử dụng");
                });
            }catch(Exception e){feedback(e.getMessage());}
        });
        spacer(root,15);
        root.addView(label("Tài khoản và quyền được kiểm tra trên máy chủ, không phụ thuộc đồng hồ điện thoại.",
            12,0xffa7b9d7,false));
    }
    private void loadUsers(){
        if(usersHolder==null)return;
        usersHolder.removeAllViews();usersHolder.addView(label("Đang tải…",13,0xffacbfdb,false));
        execute(()->AuthApi.request(this,"GET","/v1/admin/users",null,true),data->{
            usersHolder.removeAllViews();JSONArray list=data.optJSONArray("users");
            if(list==null||list.length()==0){usersHolder.addView(label("Chưa có tài khoản",13,Color.WHITE,false));return;}
            for(int i=0;i<list.length();i++){
                JSONObject u=list.optJSONObject(i);if(u==null)continue;
                int id=u.optInt("id");boolean blocked=u.optInt("blocked")!=0;
                long expires=u.optLong("expires_at");
                LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(10),dp(12),dp(10),dp(15));
                row.setBackground(background(0xff182447,0xff405582,13));
                LinearLayout.LayoutParams p=layout(-2);p.topMargin=dp(10);usersHolder.addView(row,p);
                row.addView(label(u.optString("username")+"  •  "+(blocked?"ĐÃ KHÓA":expires<=System.currentTimeMillis()?"HẾT HẠN":"CÒN HẠN"),14,Color.WHITE,true));
                row.addView(label("Hết hạn: "+date(expires),12,0xffb2c5e7,false));
                Button extend=button("+ GIA HẠN "+days()+" NGÀY");row.addView(extend,layout(43));
                extend.setOnClickListener(v->{
                    int n=days();if(n<1)return;
                    try {execute(()->AuthApi.request(this,"POST","/v1/admin/users/"+id+"/extend",
                        new JSONObject().put("days",n),true),r->{feedback("Đã gia hạn đến "+date(r.optLong("expires_at")));loadUsers();});}
                    catch(Exception e){feedback(e.getMessage());}
                });
                Button block=button(blocked?"MỞ KHÓA":"KHÓA TÀI KHOẢN");row.addView(block,layout(43));
                block.setOnClickListener(v->{
                    try{execute(()->AuthApi.request(this,"POST","/v1/admin/users/"+id+"/block",
                        new JSONObject().put("blocked",!blocked),true),r->{feedback("Đã đổi trạng thái");loadUsers();});}
                    catch(Exception e){feedback(e.getMessage());}
                });
                EditText newPassword=input("Mật khẩu mới (tối thiểu 8 ký tự)",true);row.addView(newPassword,layout(43));
                Button reset=button("ĐỔI MẬT KHẨU NGƯỜI DÙNG");row.addView(reset,layout(42));
                reset.setOnClickListener(v->{
                    try{execute(()->AuthApi.request(this,"POST","/v1/admin/users/"+id+"/password",
                        new JSONObject().put("password",newPassword.getText().toString()),true),r->{feedback("Đã thay đổi mật khẩu tài khoản");newPassword.setText("");});}
                    catch(Exception e){feedback(e.getMessage());}
                });
            }
        });
    }
    private int days(){
        try{int n=Integer.parseInt(duration.getText().toString());if(n>=1&&n<=3650)return n;}
        catch(Exception ignored){}
        feedback("Số ngày hợp lệ: 1–3650");return -1;
    }
    private String date(long ms){
        if(ms<=0)return "Không xác định";
        SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.forLanguageTag("vi-VN"));
        f.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));return f.format(new Date(ms));
    }
    private interface Request{JSONObject run() throws Exception;}
    private interface Done{void accept(JSONObject value);}
    private void execute(Request task,Done done){
        new Thread(()->{
            try{JSONObject data=task.run();runOnUiThread(()->{if(!isFinishing())done.accept(data);});}
            catch(Exception e){runOnUiThread(()->feedback("Lỗi: "+e.getMessage()));}
        },"TikXu-Admin-HTTPS").start();
    }
    private void refreshEmergency(){if(emergencyView!=null)emergencyView.setText(
        emergency?"● TẠM DỪNG TOÀN HỆ THỐNG":"● CHO PHÉP HOẠT ĐỘNG");}
    private void feedback(String text){if(result!=null)result.setText(text);}
    private LinearLayout panel(String title){
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(15),dp(16),dp(15),dp(18));
        panel.setBackground(background(0xff111d3b,0xff395778,17));
        root.addView(panel,new LinearLayout.LayoutParams(-1,-2));
        panel.addView(label(title,15,CYAN,true));spacer(panel,9);return panel;
    }
    private TextView label(String t,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(color);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;
    }
    private Button button(String t){
        Button b=new Button(this);b.setText(t);b.setAllCaps(false);b.setTextSize(12);
        b.setTextColor(Color.WHITE);b.setBackground(background(0xff273b79,0xff5b66ce,12));return b;
    }
    private EditText input(String hint,boolean secret){
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(14);e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xff9cb2d4);e.setHint(hint);
        if(secret){e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
            e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);e.setSaveEnabled(false);}
        e.setBackground(background(0xff101b32,0xff405681,10));e.setPadding(dp(10),0,dp(10),0);return e;
    }
    private GradientDrawable background(int fill,int border,int radius){
        GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),border);return g;
    }
    private LinearLayout.LayoutParams layout(int h){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h==-2?-2:dp(h));p.bottomMargin=dp(7);return p;}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void spacer(LinearLayout p,int height){p.addView(new View(this),new LinearLayout.LayoutParams(1,dp(height)));}
}

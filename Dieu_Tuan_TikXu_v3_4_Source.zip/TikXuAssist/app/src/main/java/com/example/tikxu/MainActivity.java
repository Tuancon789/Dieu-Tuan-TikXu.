package com.example.tikxu;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Server-backed login: ADMIN/USER roles and expiry are enforced on the backend. */
public class MainActivity extends Activity {
    private final int BG = 0xff0a1023, PANEL = 0xff162140, CYAN = 0xff49dfeb;
    private SharedPreferences prefs;
    private TextView status;
    private boolean unlocked = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tikxu", MODE_PRIVATE);
        showLogin();
    }

    /** Reuse the user's own photo behind a dark scrim on the login and dashboard screens. */
    private LinearLayout page() {
        FrameLayout frame = new FrameLayout(this);
        ImageView backgroundPhoto = new ImageView(this);
        backgroundPhoto.setImageResource(R.drawable.tuan_photo);
        backgroundPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(backgroundPhoto, new FrameLayout.LayoutParams(-1, -1));

        View tint = new View(this);
        tint.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            (prefs.getBoolean("theme_neon",true) ?
                new int[] {0xd20a0820, 0x930a0c26, 0xee070a1b} :
                new int[] {0xeb080b15, 0xd0091023, 0xf5080b15})));
        frame.addView(tint, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(32), dp(22), dp(30));
        scroller.addView(root);
        frame.addView(scroller, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        return root;
    }

    private void showLogin() {
        unlocked = false;
        status = null;
        LinearLayout root = page();
        space(root, 25);
        root.addView(label("✦  QUẢN TRỊ VIÊN ĐIỂU TUẤN ĐẸP TRAI 🖕", 16, CYAN, true));
        space(root, 30);
        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.tuan_avatar);
        root.addView(avatar, new LinearLayout.LayoutParams(dp(88),dp(88)));
        space(root, 22);
        root.addView(label("Đăng nhập", 30, Color.WHITE, true));
        root.addView(label("Tài khoản ADMIN hoặc tài khoản được cấp hạn", 14, 0xffb9c9e8, false));
        space(root, 18);
        LinearLayout card = card(); root.addView(card);
        card.addView(label("TÊN ĐĂNG NHẬP", 12, CYAN, true));
        EditText user = entry("Ví dụ: ADM", false);
        card.addView(user, new LinearLayout.LayoutParams(-1,dp(54)));
        space(card, 10);
        card.addView(label("MẬT KHẨU", 12, CYAN, true));
        EditText password = entry("••••••••", true);
        card.addView(password, new LinearLayout.LayoutParams(-1,dp(54)));
        space(card, 15);
        card.addView(label("MÁY CHỦ XÁC THỰC HTTPS", 12, CYAN, true));
        EditText server = entry("https://ten-may-chu.workers.dev", false);
        server.setSingleLine(true);
        server.setText(AuthApi.apiUrl(this));
        card.addView(server, new LinearLayout.LayoutParams(-1,dp(54)));
        space(card, 6);
        card.addView(label("Nhập một lần địa chỉ máy chủ của ADMIN. Không điền mật khẩu Gmail hay TikTok.",
            11,0xffaab9d5,false));
        space(card, 12);
        TextView error = label("", 13, 0xffff9eac, false);
        card.addView(error);
        Button unlock = action("ĐĂNG NHẬP  →",true);
        card.addView(unlock,buttonParams());
        unlock.setOnClickListener(v -> {
            String username=user.getText().toString().trim();
            String secret=password.getText().toString();
            String url=server.getText().toString().trim();
            if(username.length()<3 || secret.isEmpty() || !url.startsWith("https://")) {
                error.setText("Nhập tài khoản, mật khẩu và máy chủ HTTPS."); return;
            }
            AuthApi.setApiUrl(this,url);
            unlock.setEnabled(false); error.setText("Đang xác minh với máy chủ…");
            new Thread(() -> {
                try {
                    JSONObject payload = new JSONObject().put("username",username).put("password",secret);
                    JSONObject result=AuthApi.request(this,"POST","/v1/login",payload,false);
                    AuthApi.saveLogin(this,result);
                    getSharedPreferences("tikxu_auth",MODE_PRIVATE).edit().putString("notice",result.optString("notice","")).apply();
                    runOnUiThread(() -> {unlocked=true; showDashboard();});
                } catch (Exception e) {
                    runOnUiThread(() -> {error.setText("Không đăng nhập được: "+e.getMessage());unlock.setEnabled(true);password.setText("");});
                }
            },"TikXu-Auth").start();
        });
        space(root, 15);
        root.addView(label("Mã thường mặc định 45 ngày. ADMIN quản lý thời hạn trên máy chủ.",
            12,0xffaab9d5,false));
        root.addView(label("Không có máy chủ thì không thể đăng nhập; không có mật khẩu ADMIN trong APK.",
            12,0xffffc3ab,false));
    }
    private EditText entry(String hint,boolean secret) {
        EditText e=new EditText(this);
        e.setSingleLine(true);e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xff8b9dbb);e.setHint(hint);e.setTextSize(16);
        e.setInputType(secret ? (InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD)
            : InputType.TYPE_CLASS_TEXT);
        if(secret) {
            e.setTransformationMethod(PasswordTransformationMethod.getInstance());
            e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
            e.setSaveEnabled(false);
        }
        e.setPadding(dp(14),0,dp(14),0);
        e.setBackground(gradient(0xff111a31,0xff172442,dp(14),0xff385075));
        return e;
    }

    private void showDashboard() {
        LinearLayout root = page();
        root.addView(label("✦  QUẢN TRỊ VIÊN ĐIỂU TUẤN ĐẸP TRAI 🖕", 12, CYAN, true));
        space(root, 13);
        root.addView(label("TikXu Control   ✦", 32, Color.WHITE, true));
        root.addView(label("Quét rương LIVE  •  Canh 1 phòng  •  Tap tim theo ID",
            14, 0xffb9c9e8, false));
        space(root, 12);
        root.addView(label("◉  Đăng nhập: "+AuthApi.username(this)+
            (AuthApi.isAdmin(this)?" • QUẢN TRỊ VIÊN":" • TÀI KHOẢN CÓ HẠN"),
            13,0xff6bf0c4,true));
        if(!AuthApi.isAdmin(this)) {
            long expires=getSharedPreferences("tikxu_auth",MODE_PRIVATE).getLong("expires_at",0);
            if(expires>0) {
                SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.forLanguageTag("vi-VN"));
                format.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
                root.addView(label("Hết hạn: "+format.format(new Date(expires)),13,0xffffd48d,false));
            }
        } else {
            space(root, 8);
            Button management=action("👑  QUẢN TRỊ ADMIN  •  TÀI KHOẢN",true);
            root.addView(management,buttonParams());
            management.setOnClickListener(v->startActivity(new Intent(this,AdminActivity.class)));
        }
        space(root, 10);
        String notice=getSharedPreferences("tikxu_auth",MODE_PRIVATE).getString("notice","");
        if(!notice.isEmpty()) root.addView(label("📣  THÔNG BÁO ADMIN: "+notice,12,0xffffd18e,false));
        space(root, 18);

        LinearLayout statusCard = card();
        root.addView(statusCard);
        statusCard.addView(label("●  TRẠNG THÁI HỆ THỐNG", 12, 0xff68f0bc, true));
        space(statusCard, 10);
        status = label("Đang kiểm tra quyền...", 14, Color.WHITE, false);
        statusCard.addView(status);
        space(statusCard, 11);
        statusCard.addView(label("📍  Tìm biểu tượng + đọc đồng hồ ngay trên LIVE",
            13, 0xffb4cbe8, false));
        space(root, 16);

        root.addView(label("QUYỀN ỨNG DỤNG", 12, CYAN, true));
        space(root, 9);
        Button overlay = action("①  Cấp quyền hiển thị bảng nổi", false);
        root.addView(overlay, buttonParams());
        overlay.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName()))));
        Button access = action("②  Bật Trợ năng (v3.4, KHÔNG quay màn hình)", false);
        root.addView(access, buttonParams());
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        if (Build.VERSION.SDK_INT >= 33) {
            Button noticeBtn = action("③  Cho phép thông báo", false);
            root.addView(noticeBtn, buttonParams());
            noticeBtn.setOnClickListener(v -> {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 10);
            });
        }
        space(root, 17);
        root.addView(label("🎁  SĂN RƯƠNG KHÔNG QUAY MÀN HÌNH", 14, CYAN, true));
        space(root, 8);
        root.addView(label("App dùng ảnh chụp tức thời qua Trợ năng + OCR trên máy để tìm icon, nút MỞ, đồng hồ và NHẬN. Chế độ thử nghiệm: giao diện TikTok có thể đổi, không bảo đảm nhặt thành công.",
            13,0xffc0d6ef,false));
        space(root, 12);
        Button multi = action("↕  SĂN RƯƠNG NHIỀU PHÒNG • 6 GIÂY", true);
        root.addView(multi,buttonParams());
        multi.setOnClickListener(v->startMode(LiveHuntV34.Mode.MULTI));
        Button single = action("🎁  CANH RƯƠNG 1 PHÒNG • KHÔNG VUỐT",true);
        root.addView(single,buttonParams());
        single.setOnClickListener(v->startMode(LiveHuntV34.Mode.SINGLE));
        Button heart = action("❤️  TAP TIM THEO ID • HẸN GIỜ / 10K–100K",false);
        root.addView(heart,buttonParams());
        heart.setOnClickListener(v->startMode(LiveHuntV34.Mode.HEART));
        root.addView(label("Ô tìm @ID, giờ bắt đầu, thời lượng và số lượng tap nằm ở bóng nổi. Tap tim chỉ ở một phòng, không tự vuốt. Nếu không có LIVE đúng ID, app phải dừng và chờ.",
            12,0xffaabdd9,false));
        space(root, 7);
        Button stop = action("■  DỪNG TẤT CẢ CHẾ ĐỘ",false);
        root.addView(stop,buttonParams());
        stop.setOnClickListener(v->{TapAccessibilityService.stop();if(status!=null)status.setText("Đã dừng TikXu.");});
        space(root, 12);
        root.addView(label("QUY TẮC AN TOÀN",12,CYAN,true));
        root.addView(label("• Không dùng MediaProjection hoặc ghi video.\n• Không bấm GỬI QUÀ TẶNG / NẠP.\n• Không tự vuốt nếu không xác nhận được là LIVE.\n• Nếu không nhận diện được nút, đồng hồ hay trạng thái rương thì dừng thay vì bấm mò.\n• Tổng xu trong rương khác với xu thực nhận.",
            12,0xffffcf9f,false));
        space(root,16);
        Button social = action("♪  TIKTOK CỦA ĐIỂU TUẤN   ↗",false);
        root.addView(social,buttonParams());
        social.setOnClickListener(v->{
            try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.tiktok.com/@tuan203dnbp93")));}
            catch(Exception e){if(status!=null)status.setText("Không mở được TikTok.");}
        });
        Button lock = action("🔒  ĐĂNG XUẤT",false);
        root.addView(lock,buttonParams());
        lock.setOnClickListener(v->{
            TapAccessibilityService.stop();
            new Thread(()->{
                try{AuthApi.request(this,"POST","/v1/logout",new JSONObject(),true);}catch(Exception ignored){}
                AuthApi.clear(this);
                runOnUiThread(this::showLogin);
            },"TikXu-Logout").start();
        });
        refreshStatus();
    }

    private void startMode(LiveHuntV34.Mode mode){
        if(!unlocked)return;
        if(!TapAccessibilityService.isReady()){
            if(status!=null)status.setText("Cần bật Trợ năng TikXu!");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        if(!Settings.canDrawOverlays(this)){
            if(status!=null)status.setText("Cần cấp quyền hiển thị nổi!");
            return;
        }
        if(status!=null)status.setText("Đang xác minh giấy phép trên máy chủ...");
        new Thread(()->{
            try{
                JSONObject me=AuthApi.request(this,"GET","/v1/me",null,true);
                if(me.optBoolean("emergency_stop"))throw new IllegalStateException("ADMIN đã dừng hệ thống");
                runOnUiThread(()->{
                    if(!unlocked)return;
                    if(TapAccessibilityService.start(mode)){
                        if(status!=null)status.setText("Đã chạy v3.4 • mở TikTok để tiếp tục.");
                        if(mode!=LiveHuntV34.Mode.HEART)openTikTok();
                    }else if(status!=null)status.setText("Chưa khởi động được Trợ năng TikXu.");
                });
            }catch(Exception e){runOnUiThread(()->{if(status!=null)status.setText("Máy chủ từ chối: "+e.getMessage());});}
        },"TikXu-v34-license").start();
    }
    private void openTikTok(){
        Intent i=getPackageManager().getLaunchIntentForPackage("com.zhiliaoapp.musically");
        if(i==null)i=getPackageManager().getLaunchIntentForPackage("com.ss.android.ugc.trill");
        if(i!=null)try{startActivity(i);}catch(Exception ignored){}
        else if(status!=null)status.setText("Không tìm thấy ứng dụng TikTok.");
    }
    @Override protected void onResume() { super.onResume(); refreshStatus(); }
    private void refreshStatus() {
        if (status == null) return;
        status.setText("Bảng nổi: " + (Settings.canDrawOverlays(this) ? "✓ BẬT" : "✕ CHƯA BẬT") +
            "   •   Trợ năng: " + (TapAccessibilityService.isReady() ? "✓ BẬT" : "✕ CHƯA BẬT"));
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(20), dp(18), dp(20));
        box.setBackground(gradient(0xff182443, 0xff121d38, dp(20), 0xff486499));
        return box;
    }
    private Button action(String text, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false); b.setText(text);
        b.setTextSize(14); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setBackground(primary ? gradient(0xff247feb, 0xff754ae7, dp(14), CYAN)
            : gradient(0xff1c2d50, 0xff18233e, dp(14), 0xff385781));
        return b;
    }
    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(53));
        p.bottomMargin = dp(9); return p;
    }
    private GradientDrawable gradient(int a, int b, int radius, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[] {a, b});
        g.setCornerRadius(radius);
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void space(LinearLayout p, int n) { p.addView(new View(this), new LinearLayout.LayoutParams(1, dp(n))); }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
}

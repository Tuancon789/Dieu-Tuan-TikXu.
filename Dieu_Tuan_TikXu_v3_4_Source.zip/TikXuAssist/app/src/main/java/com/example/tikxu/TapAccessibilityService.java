package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/** Main runtime for TikXu v3.4. No MediaProjection. User must enable
 * Accessibility screenshot access explicitly in Android Settings. */
public class TapAccessibilityService extends AccessibilityService {
    private static volatile TapAccessibilityService live;
    private static volatile String foregroundPackage="";
    private LiveHuntV34 engine;

    @Override protected void onServiceConnected(){
        super.onServiceConnected();live=this;
        engine=new LiveHuntV34(this);
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        if(e==null||e.getPackageName()==null)return;
        String pkg=e.getPackageName().toString();
        if(isTikTokPackage(pkg)) {
            foregroundPackage=pkg;
            if(engine!=null)engine.onTikTokEvent();
        }
        if(e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
           e.getEventType()==AccessibilityEvent.TYPE_WINDOWS_CHANGED){
            if(!pkg.equals(getPackageName())&&!pkg.equals("android")&&
               !pkg.equals("com.android.systemui"))foregroundPackage=pkg;
        }
    }
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){
        if(engine!=null)engine.close();
        if(live==this)live=null;
        foregroundPackage="";
        super.onDestroy();
    }
    static boolean isTikTokPackage(String pkg){
        return "com.zhiliaoapp.musically".equals(pkg)||
               "com.ss.android.ugc.trill".equals(pkg);
    }
    static boolean isReady(){return live!=null;}
    static boolean isTikTokForeground(){return isTikTokPackage(foregroundPackage);}
    static boolean isRunning(){return live!=null&&live.engine!=null&&live.engine.isRunning();}
    static boolean start(LiveHuntV34.Mode mode){
        TapAccessibilityService s=live;
        if(s==null||s.engine==null)return false;
        s.engine.start(mode);return s.engine.isRunning();
    }
    static void stop(){
        if(live!=null&&live.engine!=null)live.engine.stop("Người dùng đã dừng");
    }
    static boolean tapOnce(int x,int y){
        TapAccessibilityService s=live;
        if(s==null||!isTikTokForeground()||Build.VERSION.SDK_INT<24)return false;
        Path path=new Path();path.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path,0,85)).build();
        return s.dispatchGesture(g,null,null);
    }
    static boolean swipeToNextLive(){
        TapAccessibilityService s=live;
        if(s==null||!isTikTokForeground()||Build.VERSION.SDK_INT<24)return false;
        DisplayMetrics m=new DisplayMetrics();
        WindowManager wm=(WindowManager)s.getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(m);
        Path p=new Path();p.moveTo(m.widthPixels*.50f,m.heightPixels*.79f);
        p.lineTo(m.widthPixels*.50f,m.heightPixels*.28f);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,470)).build();
        return s.dispatchGesture(g,null,null);
    }
}

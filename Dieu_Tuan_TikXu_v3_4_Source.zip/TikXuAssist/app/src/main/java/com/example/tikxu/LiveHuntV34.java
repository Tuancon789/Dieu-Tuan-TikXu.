package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * v3.4: One-room or multi-room LIVE chest hunt, or fixed-room heart-tap mode.
 * No screen recording or MediaProjection. Every gesture is gated by foreground
 * TikTok and a recognized state. When an unknown dialog is present, STOP.
 */
final class LiveHuntV34 implements VisionReader.Listener {
    enum Mode { MULTI, SINGLE, HEART }
    private enum Step { ENTER_LIVE, ENTERING, SCAN, ICON, WAIT, CLAIMING, RESULT,
                        CLOSING, RECHECK, SWIPING, HEART_SCHEDULE, HEART_ACTIVE }
    private final TapAccessibilityService service;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final VisionReader vision;
    private WindowManager wm;
    private View floating;
    private TextView headline, statusView, timerView, totalView;
    private EditText userField, hourField, durationField;
    private TextView countView, pauseBtn;
    private LinearLayout settingsPanel;
    private int goal=10000;
    private final int[] goals={10000,20000,50000,100000};
    private int goalIdx=0;
    private boolean running,paused,waitingLicense,tickScheduled;
    private Mode mode;
    private Step step;
    private long stepAt, lastLicense, timerDeadline, openAt, sessionLastReceipt, scheduledAt,
                 heartEndsAt, lastHeart, lastChestAt;
    private int total, successfulRums, visited, swipeFailures, tapCount, iconRetries, claimRetries,
                closeRetries;
    private int width,height;
    private VisionReader.Frame frame;
    private String status="",lastError="",heartId="";
    private Rect lastChest;

    LiveHuntV34(TapAccessibilityService s){
        service=s;vision=new VisionReader(s);
        DisplayMetrics m=new DisplayMetrics();
        WindowManager w=(WindowManager)s.getSystemService(Context.WINDOW_SERVICE);
        w.getDefaultDisplay().getRealMetrics(m);
        width=m.widthPixels;height=m.heightPixels;
    }
    boolean isRunning(){return running;}
    void close(){stop("Trợ năng đã tắt");vision.close();}
    void start(Mode selected){
        if(AuthApi.token(service).isEmpty()){
            Toast.makeText(service,"Đăng nhập TikXu trước",Toast.LENGTH_LONG).show();return;
        }
        stop("Đổi chế độ");
        mode=selected;running=true;paused=false;
        frame=null;total=0;successfulRums=visited=swipeFailures=tapCount=0;
        iconRetries=claimRetries=closeRetries=0;lastChest=null;
        step=Step.ENTER_LIVE;stepAt=SystemClock.elapsedRealtime();
        showOverlay();
        message(mode==Mode.MULTI?"Săn nhiều phòng: tìm LIVE → 6 giây/phòng":
               mode==Mode.SINGLE?"Canh 1 phòng: không vuốt, luôn ở lại":"Nhập @ID và bấm Hẹn tap");
        if(mode==Mode.HEART){step=Step.HEART_SCHEDULE;}
        schedule();
    }
    void stop(String reason){
        running=false;paused=false;
        handler.removeCallbacks(tick);tickScheduled=false;
        if(floating!=null && wm!=null){try{wm.removeView(floating);}catch(Exception ignored){}floating=null;}
        status=reason;
        if(!"Đổi chế độ".equals(reason) && !"Người dùng đã dừng".equals(reason))
            Toast.makeText(service,"TikXu: "+reason,Toast.LENGTH_LONG).show();
    }
    void onTikTokEvent(){if(running)schedule();}
    private void schedule(){if(running&&!tickScheduled){tickScheduled=true;handler.postDelayed(tick,850);}}
    private final Runnable tick=()->{
        tickScheduled=false;
        if(!running)return;
        try { onTick(); } catch(Exception e){message("Lỗi giao diện: "+e.getClass().getSimpleName());}
        schedule();
    };
    private void onTick(){
        if(paused)return;
        long now=SystemClock.elapsedRealtime();
        if(now-lastLicense>300000L && !waitingLicense)checkLicense();
        if(mode==Mode.HEART){heartTick(now);return;}
        if(!TapAccessibilityService.isTikTokForeground()){
            message("Hãy mở TikTok. Không thao tác ngoài TikTok.");return;
        }
        vision.capture(this);
        if(frame==null||!frame.fresh()){message("Đang đọc giao diện LIVE bằng Trợ năng…");return;}
        // Never reuse an OCR frame from before an action; avoids double clicking.
        if(frame.at<stepAt)return;
        switch(step){
            case ENTER_LIVE:
                if(isLiveRoom(frame)){
                    stage(Step.SCAN,"Đã vào LIVE • quét rương trong 6 giây");break;
                }
                VisionReader.Word live=findLiveTab(frame);
                if(live!=null && TapAccessibilityService.tapOnce(live.box.centerX(),live.box.centerY())){
                    stage(Step.ENTERING,"Đã bấm LIVE • chờ vào phòng");
                } else if(now-stepAt>12000L){
                    stop("Không thấy nút LIVE. Mở TikTok ở trang chủ rồi thử lại.");
                } else message("Đang tìm nút LIVE góc trên trái");
                break;
            case ENTERING:
                if(now-stepAt>=3500L){
                    if(isLiveRoom(frame))stage(Step.SCAN,"Đã vào LIVE • tìm rương");
                    else if(now-stepAt>9000L)stop("Không xác nhận được LIVE, dừng để tránh vuốt video thường");
                }
                break;
            case SCAN:
                Rect chest=detectChest(frame);
                if(chest!=null){
                    if(mode==Mode.MULTI && lastChest!=null &&
                      sameChest(chest,lastChest) && now-lastChestAt<15000L){
                        message("Đã xử lý icon này, chờ kiểm tra phòng");
                    } else if(TapAccessibilityService.tapOnce(chest.centerX(),chest.centerY())){
                        lastChest=new Rect(chest);lastChestAt=now;iconRetries=1;
                        stage(Step.ICON,"Thấy icon rương • đang mở cửa sổ");
                    }
                } else if(now-stepAt>=6000L){
                    if(mode==Mode.MULTI)doSwipe();
                    else stage(Step.SCAN,"Chưa có rương • ở lại phòng và quét tiếp");
                } else message("Quét icon rương: "+Math.max(0,(6000-(now-stepAt)+999)/1000)+" giây");
                break;
            case ICON:
                if(frame.claimed()!=null){stage(Step.RESULT,"Đã thấy kết quả nhận xu");break;}
                VisionReader.Word open=frame.openButton();
                if(open!=null && TapAccessibilityService.tapOnce(open.box.centerX(),open.box.centerY())){
                    openAt=now;timerDeadline=0;claimRetries=0;
                    stage(Step.WAIT,"Đã bấm MỞ • đang đọc đồng hồ rương");
                } else if(frame.timer()!=null || frame.claimButton()!=null){
                    openAt=now;timerDeadline=0;
                    stage(Step.WAIT,"Cửa sổ rương đã mở • đợi nhận");
                } else if(now-stepAt>=3000L){
                    Rect again=detectChest(frame);
                    if(iconRetries<2 && again!=null && TapAccessibilityService.tapOnce(again.centerX(),again.centerY())){
                        iconRetries++; stepAt=now;message("Thử mở icon rương lần 2");
                    } else stop("Không thấy nút MỞ sau khi chạm rương • dừng để tránh bấm nhầm");
                }
                break;
            case WAIT:
                if(frame.claimed()!=null || frame.result()){
                    stage(Step.RESULT,"Rương đã có kết quả");break;
                }
                Integer secs=frame.timer();
                if(secs!=null){
                    timerDeadline=now+secs*1000L;
                    showTimer(secs);
                } else if(timerDeadline>0){
                    showTimer((int)Math.max(0,(timerDeadline-now+999)/1000L));
                } else message("Đã mở rương • chờ đọc đồng hồ, không vuốt");
                VisionReader.Word claim=frame.claimButton();
                boolean ready=(timerDeadline>0 && now+600>=timerDeadline) ||
                    (claim!=null && timerDeadline==0 && now-openAt>=3000L);
                if(claim!=null && ready && TapAccessibilityService.tapOnce(claim.box.centerX(),claim.box.centerY())){
                    claimRetries=1;
                    stage(Step.CLAIMING,"Đã bấm NHẬN • đang xác minh");
                } else if(now-openAt>10*60000L){
                    stop("Không xác định được thời điểm nhận sau 10 phút • giữ nguyên phòng để kiểm tra");
                }
                break;
            case CLAIMING:
                if(frame.result() || frame.claimed()!=null){stage(Step.RESULT,"Đã nhận phản hồi từ TikTok");break;}
                if(!frame.giftModal() && now-stepAt>=3500L){
                    stage(Step.RECHECK,"Không thấy kết quả xu • kiểm tra lại sau 10 giây");
                    break;
                }
                if(now-stepAt>4500L){
                    VisionReader.Word retry=frame.claimButton();
                    if(claimRetries<2 && retry!=null && TapAccessibilityService.tapOnce(retry.box.centerX(),retry.box.centerY())){
                        claimRetries++;stepAt=now;message("Nhấn NHẬN lần 2");
                    } else if(now-stepAt>11000L){
                        stop("Chưa xác minh được nút NHẬN • dừng để tránh lặp vô hạn");
                    }
                }
                break;
            case RESULT:
                Integer got=frame.claimed();
                if(got!=null && now-sessionLastReceipt>5000L){
                    total+=got;successfulRums++;sessionLastReceipt=now;
                    message("🎉 Nhận được +"+got+" xu! Tổng phiên: "+total+" xu");
                } else if(got==null)message("Đã xử lý rương • chưa xác định số xu");
                closeRetries=0;
                stage(Step.CLOSING,status);
                break;
            case CLOSING:
                // Do not click pink 'Gửi Quà tặng' or TikTok room's top-right X.
                if(!frame.giftModal()){
                    stage(Step.RECHECK,"Đã đóng rương • kiểm tra phòng 10 giây");
                } else if(now-stepAt>1100L && closeRetries<2){
                    service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
                    closeRetries++;stepAt=now;
                    message("Đang đóng cửa sổ kết quả bằng Quay lại");
                } else if(closeRetries>=2 && now-stepAt>2200L){
                    stop("Không đóng được rương • đã dừng để tránh thoát khỏi LIVE");
                }
                break;
            case RECHECK:
                if(now-stepAt>=10000L){
                    if(mode==Mode.MULTI && detectChest(frame)==null)doSwipe();
                    else stage(Step.SCAN,"Kiểm tra rương mới trong phòng");
                } else message("Ở lại phòng, kiểm tra rương: "+((10000-(now-stepAt)+999)/1000)+" giây");
                break;
            case SWIPING:
                if(now-stepAt>=2500L)stage(Step.SCAN,"Phòng mới • tìm rương trong 6 giây");
                break;
            default:break;
        }
    }
    private void doSwipe(){
        // Must have reached LIVE via visible button or stayed in an observed LIVE room.
        if(mode!=Mode.MULTI)return;
        if(!isLiveRoom(frame)){stop("Không xác minh được đang ở LIVE • không vuốt trang Đề xuất");return;}
        if(TapAccessibilityService.swipeToNextLive()){
            visited++;swipeFailures=0;lastChest=null;
            stage(Step.SWIPING,"Không có rương • vuốt sang phòng "+(visited+1));
        } else if(++swipeFailures>=3)stop("Không vuốt được LIVE sau 3 lần");
    }
    private boolean isLiveRoom(VisionReader.Frame f){
        // The main For You page has the 'Đề xuất' header. It MUST NOT be swiped.
        if(f.contains("de xuat") || f.contains("da follow"))return false;
        return f.chest!=null || f.giftModal() || f.contains("fan club") ||
            f.contains("gui qua") || f.contains("binh luan") ||
            f.contains("theo doi") || f.contains("follow") ||
            f.contains("luot xem") || f.contains("xem live") || f.contains("hang ngay");
    }
    private VisionReader.Word findLiveTab(VisionReader.Frame f){
        for(VisionReader.Word w:f.words)if(w.normalized.equals("live") &&
              w.box.centerX()<=f.width*.18f && w.box.centerY()<=f.height*.19f)return w;
        return null;
    }
    private Rect detectChest(VisionReader.Frame f){
        if(f.chest!=null) return new Rect(f.chest);
        AccessibilityNodeInfo root=service.getRootInActiveWindow();
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
        for(AccessibilityNodeInfo n:nodes){
            String label=VisionReader.norm(String.valueOf(n.getText()==null?"":n.getText())+" "+
                String.valueOf(n.getContentDescription()==null?"":n.getContentDescription()));
            boolean ok=(label.contains("ruong bau")||label.contains("ruong xu")||
                label.contains("treasure box")||label.contains("lucky box"));
            if(!ok||label.length()>60)continue;
            Rect r=new Rect();n.getBoundsInScreen(r);
            if(!r.isEmpty()&&r.centerY()>height*.10&&r.centerY()<height*.48&&
                r.width()<width*.36)return r;
        }
        return null;
    }
    private void collect(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out,int depth){
        if(n==null||depth>14||out.size()>=350)return;
        out.add(n);
        for(int i=0;i<n.getChildCount() && out.size()<350;i++) collect(n.getChild(i),out,depth+1);
    }
    private boolean sameChest(Rect a,Rect b){
        return Math.abs(a.centerX()-b.centerX())<width*.05f &&
            Math.abs(a.centerY()-b.centerY())<height*.04f;
    }
    private void stage(Step next,String text){step=next;stepAt=SystemClock.elapsedRealtime();message(text);}
    @Override public void onFrame(VisionReader.Frame value){
        if(running&&!paused)frame=value;
    }
    @Override public void onError(String why){
        if(!why.equals(lastError)){
            lastError=why;
            if(step!=Step.HEART_ACTIVE && step!=Step.HEART_SCHEDULE)message(why);
        }
        if(why.contains("không cho chụp ảnh")||why.contains("Android 11")){
            stop("Trợ năng không được chụp màn hình • không thể nhận diện icon an toàn");
        }
    }
    private void heartTick(long now){
        if(step==Step.HEART_SCHEDULE){
            if(scheduledAt==0){message("Nhập ID rồi bấm HẸN TAP trên bóng nổi");return;}
            long wait=scheduledAt-System.currentTimeMillis();
            if(wait>0){message("Chờ vào LIVE @"+heartId+" • còn "+((wait+59999)/60000)+" phút");return;}
            try{
                String uri="https://www.tiktok.com/@"+heartId+"/live";
                android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(uri));
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                service.startActivity(i);
                stage(Step.HEART_ACTIVE,"Đang mở LIVE @"+heartId+" • chỉ tap, không vuốt");
                lastHeart=now+5000L;
            }catch(Exception e){stop("Không mở được ID LIVE");}
            return;
        }
        if(step!=Step.HEART_ACTIVE)return;
        if(TapAccessibilityService.isTikTokForeground())vision.capture(this);
        if(System.currentTimeMillis()>=heartEndsAt || tapCount>=goal){
            stop("Đủ giới hạn tap hoặc hết giờ");return;
        }
        if(!TapAccessibilityService.isTikTokForeground()){
            message("Đợi TikTok LIVE, không tap ngoài TikTok");return;
        }
        if(frame==null || !frame.fresh() || !isLiveRoom(frame)){
            message("Chưa xác minh được phòng LIVE đúng ID • đang chờ, không tap");
            if(now-stepAt>30000L)stop("Không mở được LIVE theo ID trong 30 giây");
            return;
        }
        if(now-lastHeart>=650L){
            // Video region is not a follow/gift button. Count dispatches, not actual likes.
            if(TapAccessibilityService.tapOnce((int)(width*.64),(int)(height*.52)))tapCount++;
            lastHeart=now;
            message("❤️ Tap đã thực hiện: "+tapCount+"/"+goal+" (TikTok có thể không tính đủ)");
        }
    }
    private void scheduleHeartFromBubble(){
        if(userField==null)return;
        String raw=userField.getText().toString().trim().replace("@","");
        if(!raw.matches("[A-Za-z0-9._]{2,30}")){
            message("ID TikTok không hợp lệ");return;
        }
        String time=hourField.getText().toString().trim();
        int duration=60;
        try {duration=Integer.parseInt(durationField.getText().toString().trim());}catch(Exception ignored){}
        if(duration<1||duration>1440){message("Thời gian tap phải 1–1440 phút");return;}
        long when=System.currentTimeMillis();
        if(!time.isEmpty()){
            try{
                if(!time.matches("(?:[01]\\d|2[0-3]):[0-5]\\d"))throw new Exception();
                String[] parts=time.split(":");
                Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
                c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(parts[0]));
                c.set(Calendar.MINUTE,Integer.parseInt(parts[1]));
                c.set(Calendar.SECOND,0);
                if(c.getTimeInMillis()<=when)c.add(Calendar.DAY_OF_MONTH,1);
                when=c.getTimeInMillis();
            }catch(Exception e){message("Giờ bắt đầu phải dạng HH:mm, ví dụ 20:00");return;}
        }
        heartId=raw; scheduledAt=when;heartEndsAt=when+duration*60000L;
        tapCount=0;
        // If a hunt was active switch to heart mode, never run simultaneously.
        mode=Mode.HEART;step=Step.HEART_SCHEDULE;stepAt=SystemClock.elapsedRealtime();
        message("Đã hẹn @"+heartId+", "+goal+" tap, "+duration+" phút");
    }
    private void showTimer(int secs){
        message(String.format(Locale.ROOT,"⏳ Rương còn %02d:%02d • không rời LIVE",secs/60,secs%60));
    }
    private void message(String text){
        if(text.equals(status))return;status=text;
        if(statusView!=null)statusView.setText(text);
        if(totalView!=null)totalView.setText("🪙 Xu thực nhận: "+total+"   •   🎁 Rương: "+successfulRums);
        if(timerView!=null){
            if(text.contains("Rương còn"))timerView.setText(text);
            else if(step!=Step.WAIT)timerView.setText(mode==Mode.HEART?"❤️ Ở nguyên phòng • không vuốt":"⏱ Quét 6s • kiểm tra lại 10s");
        }
    }
    private int dp(float n){return (int)(n*service.getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String value,int size,int color){
        TextView t=new TextView(service);t.setText(value);t.setTextColor(color);t.setTextSize(size);
        t.setPadding(dp(4),dp(5),dp(4),dp(5));return t;
    }
    private GradientDrawable bg(int color,int outline){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(15));d.setStroke(dp(1),outline);return d;
    }
    private EditText entry(String hint){
        EditText t=new EditText(service);t.setSingleLine(true);t.setTextSize(14);
        t.setTextColor(Color.WHITE);t.setHintTextColor(0xff9cafc7);t.setHint(hint);
        t.setBackground(bg(0xff14223e,0xff355473));
        t.setPadding(dp(10),0,dp(10),0);
        return t;
    }
    private void showOverlay(){
        try{
            wm=(WindowManager)service.getSystemService(Context.WINDOW_SERVICE);
            LinearLayout panel=new LinearLayout(service);panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(12),dp(12),dp(12),dp(10));
            panel.setBackground(bg(0xf2172440,0xff46dce8));
            LinearLayout top=new LinearLayout(service);
            headline=label("✦ TikXu v3.4  •  ĐIỂU TUẤN",15,0xff78ecfa);
            top.addView(headline,new LinearLayout.LayoutParams(0,dp(32),1));
            TextView toggle=label("⚙",20,0xff82e9ef);
            top.addView(toggle);panel.addView(top);
            panel.addView(label("QUẢN TRỊ VIÊN ĐIỂU TUẤN ĐẸP TRAI 🖕",10,0xfff3b4ef));
            statusView=label("Đang bắt đầu…",13,Color.WHITE);panel.addView(statusView);
            timerView=label("⏱ Quét 6s • kiểm tra 10s",13,0xffffdb86);panel.addView(timerView);
            totalView=label("🪙 Xu thực nhận: 0",12,0xff70e5c0);panel.addView(totalView);
            settingsPanel=new LinearLayout(service);
            settingsPanel.setOrientation(LinearLayout.VERTICAL);
            toggle.setOnClickListener(v->settingsPanel.setVisibility(settingsPanel.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
            settingsPanel.setVisibility(mode==Mode.HEART?View.VISIBLE:View.GONE);
            LinearLayout modes=new LinearLayout(service);
            for(String s:new String[]{"Nhiều phòng","1 phòng","Tap ❤️"}){
                TextView b=label(s,12,Color.WHITE);b.setGravity(Gravity.CENTER);
                b.setBackground(bg(0xff233b60,0xff567da8));
                modes.addView(b,new LinearLayout.LayoutParams(0,dp(35),1));
                b.setOnClickListener(v->{
                    if(s.equals("Nhiều phòng"))start(Mode.MULTI);
                    else if(s.equals("1 phòng"))start(Mode.SINGLE);
                    else {mode=Mode.HEART;step=Step.HEART_SCHEDULE;scheduledAt=0;settingsPanel.setVisibility(View.VISIBLE);message("Nhập @ID và giờ rồi bấm HẸN TAP");}
                });
            }
            settingsPanel.addView(modes);
            userField=entry("@ID TikTok");settingsPanel.addView(userField,new LinearLayout.LayoutParams(-1,dp(40)));
            LinearLayout r=new LinearLayout(service);
            hourField=entry("HH:mm (để trống = ngay)");
            durationField=entry("Phút");durationField.setInputType(InputType.TYPE_CLASS_NUMBER);durationField.setText("60");
            r.addView(hourField,new LinearLayout.LayoutParams(0,dp(40),2));
            r.addView(durationField,new LinearLayout.LayoutParams(0,dp(40),1));
            settingsPanel.addView(r);
            LinearLayout buttons=new LinearLayout(service);
            countView=label("10K tim ↻",12,Color.WHITE);
            countView.setBackground(bg(0xff26415c,0xff476b8a));
            buttons.addView(countView,new LinearLayout.LayoutParams(0,dp(36),1));
            countView.setOnClickListener(v->{goalIdx=(goalIdx+1)%goals.length;goal=goals[goalIdx];countView.setText((goal/1000)+"K tim ↻");});
            TextView schedule=label("HẸN TAP ▶",12,0xff83ffe2);schedule.setGravity(Gravity.CENTER);
            schedule.setBackground(bg(0xff214959,0xff4adbb7));
            buttons.addView(schedule,new LinearLayout.LayoutParams(0,dp(36),1));
            schedule.setOnClickListener(v->scheduleHeartFromBubble());
            settingsPanel.addView(buttons);
            panel.addView(settingsPanel);
            LinearLayout row=new LinearLayout(service);
            pauseBtn=label("⏸ Tạm dừng",12,Color.WHITE);pauseBtn.setGravity(Gravity.CENTER);
            row.addView(pauseBtn,new LinearLayout.LayoutParams(0,dp(36),1));
            pauseBtn.setOnClickListener(v->{paused=!paused;pauseBtn.setText(paused?"▶ Tiếp tục":"⏸ Tạm dừng");if(paused)message("Đã tạm dừng");});
            TextView end=label("■ DỪNG",12,0xffffadbb);end.setGravity(Gravity.CENTER);
            row.addView(end,new LinearLayout.LayoutParams(0,dp(36),1));
            end.setOnClickListener(v->stop("Đã dừng"));panel.addView(row);
            WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(300),-2,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
            p.gravity=Gravity.BOTTOM|Gravity.END;p.x=dp(6);p.y=dp(38);
            wm.addView(panel,p);floating=panel;
        }catch(Exception e){Toast.makeText(service,"Không mở được bóng nổi: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void checkLicense(){
        waitingLicense=true;lastLicense=SystemClock.elapsedRealtime();
        new Thread(()->{
            String error=null;
            try{JSONObject me=AuthApi.request(service,"GET","/v1/me",null,true);
                if(me.optBoolean("emergency_stop"))error="ADMIN đã dừng hệ thống";
            }catch(Exception e){error="Phiên đăng nhập/mạng lỗi: "+e.getMessage();}
            final String reason=error;
            handler.post(()->{waitingLicense=false;if(running&&reason!=null)stop(reason);});
        },"TikXu-AccessCheck").start();
    }
}

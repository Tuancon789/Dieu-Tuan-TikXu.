# TikXu v3.6.1 – Compact overlay + detection safety patch

Build status: **NOT YET COMPILED IN ANDROID SDK OR TESTED ON TIKTOK LIVE**.

Changes relative to v3.6:
- Compact four-button floating panel; avatar bubble 56dp, drag and collapse with minus button. Heart ID/scheduling appear only on demand.
- Existing personal photo is the bubble icon; neon finger-heart is the APK launcher icon.
- Fixed HTTPS Worker endpoint set in AuthApi.java; server field hidden from login.
- Live room swipe detection handles non-TikTok keyboard / overlay windows more reliably.
- Additional red/pink wide 'Mở' button visual detector gated by OCR of the chest modal. Never use it on the reward result, with the 'Gửi Quà tặng' button.
- Timestamp screenshots at acquisition time, preventing stale OCR frames after gestures.
- Heart tap center-right at 60% width and 50% height, eight taps per batch with callbacks, no swipe in heart mode.

Limitations:
- No MediaProjection added to this patch. The screen image is captured by Android AccessibilityService.takeScreenshot() and OCR processed locally; combined with node-based Accessibility detection. Android and TikTok can block/obscure this. This is *not* a continuous video recording feature.
- It may fail to identify chest icons, Open/Claim button, or room membership on altered TikTok UI. Never advertise guaranteed auto-collection.
- Build this in GitHub Actions and test on actual TikTok with a disposable test account before trusting it.
- TikTok automation can violate platform rules / trigger rate limiting.

Quick checks:
1. Login: username/password only; Worker URL is already configured.
2. Enable accessibility, open TikTok LIVE. Small portrait bubble should drag freely. Tap it to open compact four-button menu; tap minus to collapse.
3. Canh 1 phong: stay in room. Check if pink button "Mở" inside real chest dialog gets pressed; never press "Gửi Quà tặng".
4. Nhiều phòng: after 6 seconds without chest, swipe; manual stop if incorrect room or TikTok screenshot unavailable.
5. Tap mode: fill ID, schedule, check profile verification, and verify center-right double taps only inside the chosen LIVE.

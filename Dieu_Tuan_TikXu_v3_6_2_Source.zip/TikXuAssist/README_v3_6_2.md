# TikXu 3.6.2

Sửa nhận diện đồng hồ ở cuối cửa sổ rương (bao gồm vị trí 92% chiều cao).
Chỉ nhận chuỗi đồng hồ độc lập trong phần dưới màn hình để tránh giờ của bảng nổi.
Chuyển sang chờ khi rương đang đếm ngược. Sau đếm ngược, hỗ trợ cả Mở và Nhận.
Không bấm Mở khi vẫn đọc được số giây lớn hơn 0.

Chưa biên dịch APK hoặc thử trên điện thoại trong môi trường này.
Chạy workflow build_v3_6_2_GitHub_Actions.yml trên GitHub, tải APK và kiểm tra thực tế.

package com.example.tikxu;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * v3.5: Chest hunting in one/multiple LIVE rooms or scheduled heart tapping.
 * No screen recording or MediaProjection. Every gesture is gated by foreground
 * TikTok and a recognized state. When an unknown dialog is present, STOP.
 */
final class LiveHuntV34 implements VisionReader.Listener {
    enum Mode { MULTI, SINGLE, HEART }
    private enum Step { ENTER_LIVE, ENTERING, SCAN, ICON, VERIFY_OPEN, WAIT, CLAIMING, RESULT,
                        CLOSING, RECHECK, SWIPING, HEART_SCHEDULE, HEART_PROFILE, HEART_ROOM, HEART_ACTIVE, HEART_COMMENT, HEART_COMMENT_VERIFY }
    private final TapAccessibilityService service;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final VisionReader vision;
    private WindowManager wm;
    private View floating;
    private WindowManager.LayoutParams floatingParams;
    private View expandedPanel, miniPanel;
    private TextView miniCaption;
    private boolean mini=true;
    private TextView headline, statusView, timerView, totalView, clockView;
    private EditText userField, hourField, durationField;
    private TextView countView, pauseBtn;
    private LinearLayout settingsPanel;
    private int goal=10000;
    private final int[] goals={10000,20000,50000,100000};
    private int goalIdx=0;
    private boolean running,paused,waitingLicense,tickScheduled,liveTabConfirmed,gestureBusy,profileVerified,commentSent;
    private Mode mode;
    private Step step;
    private long stepAt, lastLicense, timerDeadline, openAt, sessionLastReceipt, scheduledAt,
                 heartEndsAt, lastHeart, lastChestAt;
    private int total, successfulRums, visited, swipeFailures, tapCount, iconRetries, claimRetries,
                closeRetries, openAttempts;
    private int width,height,heartMinutes=60,heartFailures=0;
    private VisionReader.Frame frame;
    private String status="",lastError="",heartId="",finalComment="";
    private Rect lastChest;

    LiveHuntV34(TapAccessibilityService s){
        service=s;vision=new VisionReader(s);
        DisplayMetrics m=new DisplayMetrics();
        WindowManager w=(WindowManager)s.getSystemService(Context.WINDOW_SERVICE);
        w.getDefaultDisplay().getRealMetrics(m);
        width=m.widthPixels;height=m.heightPixels;
    }
    boolean isRunning(){return running;}
    void hideOverlay(){
        running=false;paused=false;handler.removeCallbacks(tick);handler.removeCallbacks(clockTick);
        if(floating!=null&&wm!=null){try{wm.removeView(floating);}catch(Exception ignored){}}
        floating=null;floatingParams=null;expandedPanel=null;miniPanel=null;miniCaption=null;
        clockView=null;statusView=null;timerView=null;totalView=null;
    }
    void close(){
        running=false;handler.removeCallbacks(tick);handler.removeCallbacks(clockTick);
        if(floating!=null&&wm!=null){try{wm.removeView(floating);}catch(Exception ignored){}}
        floating=null;vision.close();
    }
    void start(Mode selected){
        if(AuthApi.token(service).isEmpty()){
            Toast.makeText(service,"Đăng nhập TikXu trước",Toast.LENGTH_LONG).show();return;
        }
        handler.removeCallbacks(tick);tickScheduled=false;
        mode=selected;running=true;paused=false;gestureBusy=false;liveTabConfirmed=false;
        profileVerified=false;commentSent=false;lastError="";
        scheduledAt=0;frame=null;total=0;successfulRums=visited=swipeFailures=tapCount=0;
        iconRetries=claimRetries=closeRetries=openAttempts=0;lastChest=null;sessionLastReceipt=0;
        step=mode==Mode.HEART?Step.HEART_SCHEDULE:Step.ENTER_LIVE;
        stepAt=SystemClock.elapsedRealtime();
        if(floating==null)showOverlay(); else setMini(true);
        if(floating==null){running=false;return;}
        if(settingsPanel!=null)settingsPanel.setVisibility(mode==Mode.HEART?View.VISIBLE:View.GONE);
        if(mode==Mode.HEART)setMini(false);
        if(pauseBtn!=null)pauseBtn.setText("⏸ Tạm dừng");
        message(mode==Mode.MULTI?"✅ Săn nhiều phòng đã bật • tìm LIVE":
               mode==Mode.SINGLE?"✅ Canh 1 phòng đã bật • không vuốt":"✅ Chế độ tap sẵn sàng • nhập @ID để hẹn");
        Toast.makeText(service,"TikXu: Đã bật "+(mode==Mode.MULTI?"săn nhiều phòng":mode==Mode.SINGLE?"canh 1 phòng":"hẹn tap"),Toast.LENGTH_SHORT).show();
        schedule();
    }
    /** Keep the draggable bubble even when a task finishes or encounters an error. */
    void stop(String reason){
        running=false;paused=false;gestureBusy=false;
        handler.removeCallbacks(tick);tickScheduled=false;
        message("■ "+reason+" • bóng nổi vẫn hoạt động");
        if(pauseBtn!=null)pauseBtn.setText("▶ Đã dừng");
        Toast.makeText(service,"TikXu: "+reason,Toast.LENGTH_SHORT).show();
    }
    /** Unknown screens should keep the bubble available instead of disappearing.
     * User can manually tap TikTok's MỞ button then choose Tiếp tục. */
    private void holdForUser(String why){
        paused=true;
        if(pauseBtn!=null)pauseBtn.setText("▶ Tiếp tục");
        message("⚠ "+why+" • Bấm Tiếp tục sau khi kiểm tra");
        if(miniCaption!=null)miniCaption.setText("⚠ Tạm dừng");
    }
    void onTikTokEvent(){if(running)schedule();}
    private void schedule(){if(running&&!tickScheduled){tickScheduled=true;handler.postDelayed(tick,(mode==Mode.HEART && step==Step.HEART_ACTIVE)?590L:850L);}}
    private final Runnable tick=()->{
        tickScheduled=false;
        if(!running)return;
        try { onTick(); } catch(Exception e){holdForUser("Lỗi giao diện: "+e.getClass().getSimpleName());}
        schedule();
    };
    private void onTick(){
        updateClock();
        if(paused)return;
        long now=SystemClock.elapsedRealtime();
        if(now-lastLicense>300000L && !waitingLicense)checkLicense();
        if(mode==Mode.HEART){heartTick(now);return;}
        if(!TapAccessibilityService.isTikTokForeground()){
            message("Hãy mở TikTok. Không thao tác ngoài TikTok.");return;
        }
        vision.capture(this);
        if(gestureBusy)return;
        if(frame==null||!frame.fresh()){message("Đang đọc giao diện LIVE bằng Trợ năng…");return;}
        // Never reuse an OCR frame from before an action; avoids double clicking.
        if(frame.at<stepAt)return;
        switch(step){
            case ENTER_LIVE:
                if(isLiveRoom(frame)){
                    liveTabConfirmed=true;
                    stage(Step.SCAN,"Đã vào LIVE • quét rương trong 6 giây");break;
                }
                if(mode==Mode.SINGLE){
                    message("Mở phòng TikTok LIVE muốn canh • sẽ KHÔNG chuyển phòng");
                    break;
                }
                Rect live=findLiveTabRect(frame);
                if(live!=null && TapAccessibilityService.tapOnce(live.centerX(),live.centerY())){
                    liveTabConfirmed=true;
                    frame=null;
                    stage(Step.ENTERING,"✅ Đã bấm LIVE • chờ vào phòng");
                } else if(now-stepAt>12000L){
                    holdForUser("Không thấy nút LIVE. Kiểm tra TikTok rồi tiếp tục");
                } else message("Đang tìm nút LIVE góc trên trái");
                break;
            case ENTERING:
                if(now-stepAt>=3800L){
                    if(isForYouScreen(frame)){
                        if(now-stepAt>9500L)holdForUser("TikTok vẫn ở Đề xuất • chưa vào LIVE");
                        else message("Đang đợi màn hình LIVE mở xong…");
                    }else if(liveTabConfirmed || isLiveRoom(frame)){
                        stage(Step.SCAN,"✅ Đã chuyển sang LIVE • quét rương 6 giây");
                    }else if(now-stepAt>10000L)holdForUser("Không xác nhận được LIVE • đừng vuốt video thường");
                }
                break;
            case SCAN:
                Rect chest=detectChest(frame);
                if(chest!=null){
                    if(mode==Mode.MULTI && lastChest!=null &&
                      sameChest(chest,lastChest) && now-lastChestAt<15000L){
                        if(now-stepAt>=6000L) doSwipe();
                        else message("Rương vừa xử lý • chờ "+((6000-(now-stepAt)+999)/1000)+"s rồi chuyển phòng");
                    } else if(TapAccessibilityService.tapOnce(chest.centerX(),chest.centerY())){
                        lastChest=new Rect(chest);lastChestAt=now;iconRetries=1;openAttempts=0;
                        stage(Step.ICON,"Thấy icon rương • đang mở cửa sổ");
                    }
                } else if(now-stepAt>=6000L){
                    if(mode==Mode.MULTI)doSwipe();
                    else stage(Step.SCAN,"Chưa có rương • ở lại phòng và quét tiếp");
                } else message("Quét icon rương: "+Math.max(0,(6000-(now-stepAt)+999)/1000)+" giây");
                break;
            case ICON:
                if(frame.claimed()!=null){stage(Step.RESULT,"Đã thấy kết quả nhận xu");break;}
                // A countdown sheet is already open: do not look for Mở yet.
                if(frame.giftModal() && frame.timer()!=null){
                    openAt=now;timerDeadline=0;claimRetries=0;
                    stage(Step.WAIT,"Rương đang đếm ngược • chờ nút Mở");break;
                }
                Rect open=findOpenButton(frame);
                if(open!=null && TapAccessibilityService.tapOnce(open.centerX(),open.centerY())){
                    openAt=now;timerDeadline=0;claimRetries=0;openAttempts=1;
                    stage(Step.VERIFY_OPEN,"Đã chạm MỞ • kiểm tra xem rương thật sự mở chưa");
                } else if(frame.giftModal() && (frame.timer()!=null || frame.claimButton()!=null)){
                    openAt=now;timerDeadline=0;
                    stage(Step.WAIT,"Cửa sổ rương đã mở • đợi nhận");
                } else if(now-stepAt>=6500L && !frame.giftModal() && iconRetries<2){
                    Rect again=detectChest(frame);
                    if(again!=null && TapAccessibilityService.tapOnce(again.centerX(),again.centerY())){
                        iconRetries++;stepAt=now;message("Chưa bật cửa sổ • thử icon rương lần 2");
                    }
                } else if(now-stepAt>=12000L){
                    holdForUser("Chưa đọc được nút MỞ. Rương vẫn giữ nguyên, KHÔNG tự thoát");
                } else {
                    message("Đang tìm nút MỞ • không đóng rương ("+Math.max(0,(12000-now+stepAt+999)/1000)+"s)");
                }
                break;
            case VERIFY_OPEN:
                if(frame.claimed()!=null || frame.result()){
                    stage(Step.RESULT,"Đã có kết quả rương • đọc xu thực nhận");
                } else if(frame.timer()!=null || frame.claimButton()!=null){
                    stage(Step.WAIT,"Đã xác nhận rương mở • theo dõi đồng hồ");
                } else if(now-stepAt>2200L && openAttempts<2){
                    Rect retryOpen=findOpenButton(frame);
                    if(retryOpen!=null && TapAccessibilityService.tapOnce(retryOpen.centerX(),retryOpen.centerY())){
                        openAttempts++;stepAt=now;message("Nút MỞ vẫn hiện • thử bấm lại đúng 1 lần");
                    }
                } else if(now-openAt>9000L){
                    holdForUser("Đã chạm MỞ nhưng không xác nhận rương mở • giữ nguyên LIVE");
                } else message("Kiểm tra rương đã mở chưa • không tự đóng / vuốt");
                break;
            case WAIT:
                if(frame.claimed()!=null || frame.result()){
                    stage(Step.RESULT,"Rương đã có kết quả");break;
                }
                Integer secs=frame.timer();
                if(secs!=null){
                    timerDeadline=now+secs*1000L;
                    showTimer(secs);
                } else if(timerDeadline>0){
                    showTimer((int)Math.max(0,(timerDeadline-now+999)/1000L));
                } else message("Đã mở rương • chờ đọc đồng hồ, không vuốt");
                VisionReader.Word claim=frame.claimButton();
                boolean ready=(timerDeadline>0 && now+600>=timerDeadline) ||
                    (claim!=null && timerDeadline==0 && now-openAt>=3000L);
                Rect readyButton=claim!=null ? new Rect(claim.box) : findOpenButton(frame);
                // TikTok also labels the action Mở after the countdown finishes.
                if(readyButton!=null && secs==null && timerDeadline==0 && now-openAt>=3000L)ready=true;
                if(readyButton!=null && (secs==null || secs==0) && ready &&
                   TapAccessibilityService.tapOnce(readyButton.centerX(),readyButton.centerY())){
                    claimRetries=1;
                    stage(Step.CLAIMING,"Đã bấm NHẬN • đang xác minh");
                } else if(now-openAt>10*60000L){
                    holdForUser("Không đọc được đồng hồ/nút NHẬN sau 10 phút");
                }
                break;
            case CLAIMING:
                if(frame.result() || frame.claimed()!=null){stage(Step.RESULT,"Đã nhận phản hồi từ TikTok");break;}
                if(!frame.giftModal() && now-stepAt>=3500L){
                    stage(Step.RECHECK,"Không thấy kết quả xu • kiểm tra lại sau 10 giây");
                    break;
                }
                if(now-stepAt>4500L){
                    VisionReader.Word retry=frame.claimButton();
                    Rect retryButton=retry!=null ? new Rect(retry.box) : findOpenButton(frame);
                    Integer remaining=frame.timer();
                    if(claimRetries<2 && (remaining==null || remaining==0) && retryButton!=null &&
                       TapAccessibilityService.tapOnce(retryButton.centerX(),retryButton.centerY())){
                        claimRetries++;stepAt=now;message("Nhấn NHẬN lần 2");
                    } else if(now-stepAt>11000L){
                        holdForUser("Chưa xác minh được nút NHẬN, giữ nguyên rương");
                    }
                }
                break;
            case RESULT:
                Integer got=frame.claimed();
                if(got!=null && now-sessionLastReceipt>5000L){
                    total+=got;successfulRums++;sessionLastReceipt=now;
                    message("🎉 Nhận được +"+got+" xu! Tổng phiên: "+total+" xu");
                } else if(got==null)message("Đã xử lý rương • chưa xác định số xu");
                closeRetries=0;
                stage(Step.CLOSING,status);
                break;
            case CLOSING:
                // Do not click pink 'Gửi Quà tặng' or TikTok room's top-right X.
                if(!frame.giftModal() && !frame.result() && isLiveRoom(frame)){
                    stage(Step.RECHECK,"Đã đóng rương • kiểm tra phòng 10 giây");
                } else if(now-stepAt>1400L && closeRetries==0 && frame.result()){
                    service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
                    closeRetries++;stepAt=now;
                    message("Đang đóng cửa sổ KẾT QUẢ bằng Quay lại");
                } else if(now-stepAt>5500L){
                    holdForUser("Chưa xác minh được đã đóng rương • không Back lần 2");
                }
                break;
            case RECHECK:
                if(now-stepAt>=10000L){
                    if(frame.giftModal() || frame.result()){
                        holdForUser("Vẫn còn cửa sổ rương • không vuốt");
                    } else if(mode==Mode.MULTI && detectChest(frame)==null)doSwipe();
                    else stage(Step.SCAN,"Kiểm tra rương mới trong phòng");
                } else message("Ở lại phòng, kiểm tra rương: "+((10000-(now-stepAt)+999)/1000)+" giây");
                break;
            case SWIPING:
                if(now-stepAt>=2700L){
                    if(isForYouScreen(frame))holdForUser("Đã thoát LIVE sang Đề xuất • dừng vuốt");
                    else stage(Step.SCAN,"Phòng LIVE mới • tìm rương trong 6 giây");
                }
                break;
            default:break;
        }
    }
    private void doSwipe(){
        // Must have reached LIVE via visible button or stayed in an observed LIVE room.
        if(mode!=Mode.MULTI)return;
        if(frame==null || frame.giftModal() || frame.result()){
            holdForUser("Có cửa sổ rương • không được vuốt");return;
        }
        if(isForYouScreen(frame) || (!liveTabConfirmed && !isLiveRoom(frame))){
            holdForUser("Không xác nhận được đang ở LIVE • tránh vuốt trang Đề xuất");return;
        }
        gestureBusy=true;
        boolean accepted=TapAccessibilityService.swipeToNextLive(ok->{
            gestureBusy=false;
            if(!running||mode!=Mode.MULTI)return;
            if(ok){visited++;swipeFailures=0;lastChest=null;frame=null;
                stage(Step.SWIPING,"✅ Đã vuốt • chờ phòng LIVE mới số "+(visited+1));
            } else if(++swipeFailures>=3)holdForUser("Android hủy vuốt 3 lần • giữ nguyên LIVE");
            else stage(Step.SCAN,"Vuốt chưa thành công, sẽ thử sau 6 giây");
        });
        if(!accepted){gestureBusy=false;
            if(++swipeFailures>=3)holdForUser("Trợ năng không gửi được thao tác vuốt");
            else stage(Step.SCAN,"Thao tác vuốt chưa nhận • thử lại sau 6 giây");
        } else message("↕ Đang vuốt sang phòng LIVE tiếp theo…");
    }
    private boolean isForYouScreen(VisionReader.Frame f){
        if(f==null)return false;
        // Both tab labels near the TOP form the For You video header.
        boolean recommended=false,followed=false;
        for(VisionReader.Word w:f.words){
            if(w.box.centerY()>f.height*.19f)continue;
            if(w.normalized.contains("de xuat"))recommended=true;
            if(w.normalized.contains("da follow")||w.normalized.contains("ban be"))followed=true;
        }
        return recommended&&followed;
    }
    private boolean isLiveRoom(VisionReader.Frame f){
        if(f==null || isForYouScreen(f))return false;
        return f.chest!=null || f.giftModal() || f.contains("fan club") ||
            f.contains("gui qua") || f.contains("binh luan") ||
            f.contains("theo doi") || f.contains("follow") ||
            f.contains("luot xem") || f.contains("xem live") ||
            f.contains("hang ngay") || f.contains("qua tang") ||
            f.contains("da tham gia") || f.contains("top 60%") ||
            f.contains("bang xep hang") || f.contains("quan gia") || f.contains("quy tac live");
    }
    private Rect findLiveTabRect(VisionReader.Frame f){
        for(VisionReader.Word w:f.words)if(w.normalized.equals("live") &&
              w.box.centerX()<=f.width*.20f && w.box.centerY()<=f.height*.19f)
            return new Rect(w.box);
        AccessibilityNodeInfo root=tikTokRoot();
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
        for(AccessibilityNodeInfo n:nodes){
            String name=VisionReader.norm(String.valueOf(n.getText()==null?"":n.getText())+" "+
                String.valueOf(n.getContentDescription()==null?"":n.getContentDescription()));
            Rect box=new Rect();n.getBoundsInScreen(box);
            if(name.equals("live") && !box.isEmpty() &&
                box.centerX()<width*.20f && box.centerY()<height*.19f)return box;
        }
        return null;
    }
    /** Prefer a bottom-screen OCR label. If OCR misses it, inspect an actual
     * accessible node; never guess the center of TikTok's pink gift button. */
    /** The active root can belong to Gboard when commenting. Search TikTok windows. */
    private AccessibilityNodeInfo tikTokRoot(){
        try{
            List<AccessibilityWindowInfo> windows=service.getWindows();
            if(windows!=null)for(AccessibilityWindowInfo win:windows){
                AccessibilityNodeInfo r=win.getRoot();
                if(r!=null && r.getPackageName()!=null &&
                    TapAccessibilityService.isTikTokPackage(r.getPackageName().toString()))return r;
            }
        }catch(Exception ignored){}
        AccessibilityNodeInfo root=service.getRootInActiveWindow();
        if(root!=null && root.getPackageName()!=null &&
            TapAccessibilityService.isTikTokPackage(root.getPackageName().toString()))return root;
        return null;
    }
    private boolean keyboardShowing(){
        try{for(AccessibilityWindowInfo w:service.getWindows())
            if(w.getType()==AccessibilityWindowInfo.TYPE_INPUT_METHOD)return true;
        }catch(Exception ignored){}
        return false;
    }
    private Rect findOpenButton(VisionReader.Frame f){
        Integer remaining=f.timer();
        if(remaining!=null && remaining>0)return null;
        VisionReader.Word word=f.openButton();
        if(word!=null) return new Rect(word.box);
        // Confirm chest language AND a large pink button before visual fallback.
        // Never click a pink "Gửi Quà tặng" button on the result screen.
        if(!f.result() && f.contains("ruong bau") && f.contains("xu") &&
           !f.contains("gui qua tang") && f.pinkOpen!=null)
            return new Rect(f.pinkOpen);
        AccessibilityNodeInfo root=tikTokRoot();
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
        for(AccessibilityNodeInfo n:nodes){
            String raw=String.valueOf(n.getText()==null?"":n.getText())+" "+
                String.valueOf(n.getContentDescription()==null?"":n.getContentDescription());
            String label=VisionReader.norm(raw);
            if(!label.matches("(?:mo|mo ruong|open|open chest)"))continue;
            Rect r=new Rect();n.getBoundsInScreen(r);
            if(!r.isEmpty() && r.centerY()>height*.69f && r.centerY()<height*.95f &&
              r.centerX()>width*.12f && r.centerX()<width*.90f){
                return r;
            }
        }
        return null;
    }
    private Rect detectChest(VisionReader.Frame f){
        if(f.chest!=null) return new Rect(f.chest);
        AccessibilityNodeInfo root=tikTokRoot();
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
        for(AccessibilityNodeInfo n:nodes){
            String label=VisionReader.norm(String.valueOf(n.getText()==null?"":n.getText())+" "+
                String.valueOf(n.getContentDescription()==null?"":n.getContentDescription()));
            boolean ok=(label.contains("ruong bau")||label.contains("ruong xu")||
                label.contains("treasure box")||label.contains("lucky box"));
            if(!ok||label.length()>60)continue;
            Rect r=new Rect();n.getBoundsInScreen(r);
            if(!r.isEmpty()&&r.centerY()>height*.10&&r.centerY()<height*.48&&
                r.width()<width*.36)return r;
        }
        return null;
    }
    private void collect(AccessibilityNodeInfo n,List<AccessibilityNodeInfo> out,int depth){
        if(n==null||depth>14||out.size()>=350)return;
        out.add(n);
        for(int i=0;i<n.getChildCount() && out.size()<350;i++) collect(n.getChild(i),out,depth+1);
    }
    private boolean sameChest(Rect a,Rect b){
        return Math.abs(a.centerX()-b.centerX())<width*.05f &&
            Math.abs(a.centerY()-b.centerY())<height*.04f;
    }
    private void stage(Step next,String text){step=next;stepAt=SystemClock.elapsedRealtime();message(text);}
    @Override public void onFrame(VisionReader.Frame value){
        if(running&&!paused)frame=value;
    }
    @Override public void onError(String why){
        if(!why.equals(lastError)){
            lastError=why;
            if(step!=Step.HEART_ACTIVE && step!=Step.HEART_SCHEDULE)message(why);
        }
        if(why.contains("không cho chụp ảnh")||why.contains("Android 11")){
            holdForUser("Trợ năng không được chụp ảnh • không thể nhận diện icon");
        }
    }
    /** Open profile, verify the @handle ON PROFILE, then tap its LIVE badge.
     * We deliberately do not try to compare the room display name afterwards. */
    private void heartTick(long now){
        if(step==Step.HEART_SCHEDULE){
            if(scheduledAt==0){message("Nhập @ID và bấm HẸN TAP để khởi động");return;}
            long wait=scheduledAt-System.currentTimeMillis();
            if(wait>0){message("✅ Hẹn @"+heartId+" • chờ "+((wait+999)/1000)+" giây");return;}
            try{
                android.content.Intent i=new android.content.Intent(
                    android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://www.tiktok.com/@"+heartId));
                i.setPackage(TapAccessibilityService.installedTikTokPackage());
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                service.startActivity(i);
                frame=null;profileVerified=false;heartFailures=0;
                stage(Step.HEART_PROFILE,"🔎 Đã yêu cầu mở trang cá nhân @"+heartId);
            }catch(Exception e){holdForUser("Không tự mở được trang cá nhân TikTok @"+heartId);}
            return;
        }
        if(!TapAccessibilityService.isTikTokForeground()){
            if(step==Step.HEART_PROFILE || step==Step.HEART_ROOM){
                if(now-stepAt>25000L)holdForUser("Không mở được TikTok theo ID • chưa tap");
                else message("Đang chờ TikTok mở trang cá nhân…");
            }
            else message("Không tap ngoài TikTok");
            return;
        }
        if(step==Step.HEART_PROFILE || step==Step.HEART_ROOM ||
           step==Step.HEART_COMMENT || step==Step.HEART_COMMENT_VERIFY ||
           (step==Step.HEART_ACTIVE && now-lastHeart>10000L))vision.capture(this);
        if(step==Step.HEART_PROFILE){
            if(frame==null||!frame.fresh()||frame.at<stepAt)return;
            if(profileIdMatched(frame,heartId)){
                profileVerified=true;
                Rect live=findProfileLiveBadge(frame);
                if(live!=null){
                    if(TapAccessibilityService.tapOnce(live.centerX(),live.centerY())){
                        frame=null;stage(Step.HEART_ROOM,"✅ Đúng @"+heartId+" • đã bấm avatar LIVE");
                    }else holdForUser("Không bấm được avatar LIVE");
                } else if(now-stepAt>14000L)
                    holdForUser("Đúng @ID nhưng không thấy nhãn LIVE trên avatar");
                else message("✅ Đúng @"+heartId+" • đang tìm avatar có chữ LIVE");
            }else if(now-stepAt>18000L){
                holdForUser("Chưa xác minh được @"+heartId+" trên trang cá nhân • không tap nhầm");
            }else message("Đang kiểm tra ID trên trang cá nhân: @"+heartId);
            return;
        }
        if(step==Step.HEART_ROOM){
            if(frame==null||!frame.fresh()||frame.at<stepAt)return;
            if(profileIdMatched(frame,heartId)){
                if(now-stepAt>14000L)holdForUser("Vẫn đang ở trang cá nhân • chưa vào LIVE");
                else message("Đang đợi phòng LIVE mở…");
                return;
            }
            if(isForYouScreen(frame)){
                holdForUser("TikTok mở nhầm Đề xuất • không tap");return;
            }
            if(isLiveRoom(frame) || (profileVerified && now-stepAt>4200L)){
                lastHeart=now;heartEndsAt=System.currentTimeMillis()+heartMinutes*60000L;
                gestureBusy=false;frame=null;
                stage(Step.HEART_ACTIVE,"❤️ Đã vào LIVE từ @"+heartId+" • đang tap 0/"+goal);
                Toast.makeText(service,"✅ Đã vào LIVE, bắt đầu tap",Toast.LENGTH_SHORT).show();
            }else if(now-stepAt>16000L)holdForUser("Không xác nhận được đã vào phòng LIVE");
            return;
        }
        if(step==Step.HEART_ACTIVE){
            if(tapCount>=goal){
                finalComment="Bot Tuấn Đz đã hoàn thành "+String.format(Locale.forLanguageTag("vi-VN"),"%,d",goal)+" tap tay ❤️";
                commentSent=false;gestureBusy=false;frame=null;
                stage(Step.HEART_COMMENT,"✅ Đủ "+goal+" tap • đang nhập bình luận 1 lần");
                return;
            }
            if(System.currentTimeMillis()>=heartEndsAt){
                stop("Đã hết thời gian • thực hiện "+tapCount+"/"+goal+" tap, chưa bình luận vì chưa đủ");return;
            }
            if(gestureBusy || now-lastHeart<570L)return;
            int n=Math.min(8,goal-tapCount);
            gestureBusy=true;lastHeart=now;
            boolean accepted=TapAccessibilityService.tapBurst(n,(int)(width*.60),(int)(height*.50),ok->{
                gestureBusy=false;
                if(!running||mode!=Mode.HEART||step!=Step.HEART_ACTIVE)return;
                if(ok){tapCount+=n;heartFailures=0;
                    message("❤️ Tap đã thực hiện "+tapCount+"/"+goal+" • không vuốt");
                } else if(++heartFailures>=3)holdForUser("Android đã hủy tap 3 lần");
            });
            if(!accepted){gestureBusy=false;
                if(++heartFailures>=3)holdForUser("Không gửi được thao tác tap");
            }
            return;
        }
        if(step==Step.HEART_COMMENT){
            if(frame==null||!frame.fresh()||frame.at<stepAt)return;
            if(commentSent)return;
            if(isForYouScreen(frame)){holdForUser("Đã rời LIVE trước khi gửi bình luận");return;}
            AccessibilityNodeInfo input=findCommentInput();
            if(input==null){
                VisionReader.Word w=findLowerWord(frame,"nhap");
                if(w!=null && now-stepAt<9000L){
                    TapAccessibilityService.tapOnce(w.box.centerX(),w.box.centerY());
                    frame=null;message("Đang mở ô bình luận…");
                } else if(now-stepAt>10000L)holdForUser("Không tìm thấy ô Nhập bình luận • chưa gửi");
                return;
            }
            if(!finalComment.contentEquals(input.getText()==null?"":input.getText())){
                input.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                Bundle args=new Bundle();
                args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,finalComment);
                if(!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args)){
                    if(now-stepAt>8500L)holdForUser("Không điền được bình luận • chưa gửi");
                    return;
                }
                frame=null;
                message("Đã nhập bình luận • tìm nút máy bay giấy đỏ");
                return;
            }
            Rect send=findSendButton(input,frame);
            if(send==null){
                if(now-stepAt>12000L)holdForUser("Không thấy máy bay giấy đỏ • không gửi mò");
                else message("Đã nhập • chờ nhận diện nút gửi màu đỏ");
                return;
            }
            commentSent=true; // at most one send attempt
            boolean submitted=TapAccessibilityService.tapOnce(send.centerX(),send.centerY());
            if(!submitted){commentSent=false;holdForUser("Không bấm được nút gửi");return;}
            frame=null;
            stage(Step.HEART_COMMENT_VERIFY,"💬 Đã bấm máy bay giấy • đang xác minh bình luận");
            return;
        }
        if(step==Step.HEART_COMMENT_VERIFY){
            if(frame!=null && frame.fresh() && frame.contains("bot tuan dz") && frame.contains("hoan thanh")){
                stop("✅ Đã tap đủ và thấy bình luận hoàn thành");
            }else if(now-stepAt>9000L){
                stop("Đã bấm gửi 1 lần • chưa xác minh TikTok đăng bình luận");
            }
        }
    }
    /** Require the exact @handle within the profile header, not a loose text substring. */
    private boolean profileIdMatched(VisionReader.Frame f,String id){
        String sought="@"+VisionReader.norm(id);
        for(VisionReader.Word w:f.words){
            if(w.box.centerY()<=f.height*.08f||w.box.centerY()>=f.height*.44f)continue;
            String candidate=w.normalized.trim();
            if(candidate.replace(" ","").equals(sought))return true;
        }
        AccessibilityNodeInfo root=tikTokRoot();
        if(root!=null){
            ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
            for(AccessibilityNodeInfo n:nodes){
                if(n.getText()==null)continue;
                Rect b=new Rect();n.getBoundsInScreen(b);
                if(b.centerY()>height*.08f && b.centerY()<height*.44f &&
                   VisionReader.norm(n.getText().toString()).replace(" ","").equals(sought))return true;
            }
        }
        return false;
    }
    private Rect findProfileLiveBadge(VisionReader.Frame f){
        for(VisionReader.Word w:f.words){
            if(w.normalized.equals("live") && w.box.centerX()>f.width*.56f &&
                w.box.centerY()>f.height*.12f && w.box.centerY()<f.height*.43f)
                return new Rect(w.box);
        }
        AccessibilityNodeInfo root=tikTokRoot();
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
        for(AccessibilityNodeInfo n:nodes){
            String value=VisionReader.norm(String.valueOf(n.getText()==null?"":n.getText())+" "+
                String.valueOf(n.getContentDescription()==null?"":n.getContentDescription()));
            Rect b=new Rect();n.getBoundsInScreen(b);
            if((value.equals("live")||value.contains("dang live")) &&
               b.centerX()>width*.56f && b.centerY()>height*.12f && b.centerY()<height*.43f)
                return b;
        }
        return null;
    }
    private AccessibilityNodeInfo findCommentInput(){
        AccessibilityNodeInfo root=tikTokRoot();
        if(root==null)return null;
        ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
        for(AccessibilityNodeInfo n:nodes){
            if(!n.isEditable() && (n.getClassName()==null ||
                !n.getClassName().toString().contains("EditText")))continue;
            Rect box=new Rect();n.getBoundsInScreen(box);
            if(box.centerY()>height*.28f && box.centerY()<height*.96f &&
                box.width()>width*.20f)return n;
        }
        return null;
    }
    private VisionReader.Word findLowerWord(VisionReader.Frame f,String text){
        for(VisionReader.Word w:f.words){
            if(w.box.centerY()>f.height*.77f && w.normalized.startsWith(text))return w;
        }
        return null;
    }
    private Rect findSendButton(AccessibilityNodeInfo input,VisionReader.Frame f){
        Rect textBox=new Rect();input.getBoundsInScreen(textBox);
        AccessibilityNodeInfo root=tikTokRoot();
        if(root!=null){
            ArrayList<AccessibilityNodeInfo> nodes=new ArrayList<>();collect(root,nodes,0);
            for(AccessibilityNodeInfo n:nodes){
                Rect box=new Rect();n.getBoundsInScreen(box);
                if(box.centerX()<=textBox.right || box.centerX()>width*.99f ||
                   Math.abs(box.centerY()-textBox.centerY())>dp(55))continue;
                String text=VisionReader.norm(String.valueOf(n.getText()==null?"":n.getText())+" "+
                   String.valueOf(n.getContentDescription()==null?"":n.getContentDescription()));
                if((text.equals("gui")||text.equals("send")||text.contains("send comment")||
                    text.contains("gui binh luan")) && box.width()<width*.22f)return box;
            }
        }
        // VisionReader searches specifically for a red paper-plane adjacent to the text field.
        if(keyboardShowing() && f!=null && f.redSend!=null &&
           f.redSend.centerX()>textBox.right &&
           Math.abs(f.redSend.centerY()-textBox.centerY())<dp(55))return new Rect(f.redSend);
        return null;
    }
    private void scheduleHeartFromBubble(){
        if(userField==null)return;
        if(AuthApi.token(service).isEmpty()){
            message("❌ Hãy đăng nhập TikXu trước khi hẹn tap");return;
        }
        String raw=userField.getText().toString().trim();
        if(raw.startsWith("@"))raw=raw.substring(1);
        if(!raw.matches("[A-Za-z0-9._]{2,30}")){
            message("❌ ID TikTok không hợp lệ");return;
        }
        String time=hourField.getText().toString().trim();
        int duration=60;
        try{duration=Integer.parseInt(durationField.getText().toString().trim());}
        catch(Exception ignored){}
        if(duration<1||duration>1440){message("❌ Số phút phải từ 1 đến 1440");return;}
        long when=System.currentTimeMillis();
        if(!time.isEmpty()){
            try{
                if(!time.matches("(?:[01]\\d|2[0-3]):[0-5]\\d"))throw new Exception();
                String[] parts=time.split(":");
                Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
                c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(parts[0]));
                c.set(Calendar.MINUTE,Integer.parseInt(parts[1]));c.set(Calendar.SECOND,0);
                c.set(Calendar.MILLISECOND,0);
                if(c.getTimeInMillis()<=when)c.add(Calendar.DAY_OF_MONTH,1);
                when=c.getTimeInMillis();
            }catch(Exception e){message("Giờ bắt đầu phải là HH:mm, ví dụ 20:00");return;}
        }
        heartId=raw;scheduledAt=when;heartMinutes=duration;
        heartEndsAt=0;tapCount=0;gestureBusy=false;
        mode=Mode.HEART;running=true;paused=false;profileVerified=false;commentSent=false;
        frame=null;step=Step.HEART_SCHEDULE;stepAt=SystemClock.elapsedRealtime();
        message("✅ Bạn đã hẹn tap thành công @"+heartId+" lúc "+
            (time.isEmpty()?"ngay bây giờ":time)+" • "+goal+" tap");
        Toast.makeText(service,"✅ Đã hẹn tap • giữ Trợ năng và TikXu hoạt động",Toast.LENGTH_LONG).show();
        schedule();
    }
    private final Runnable clockTick=new Runnable(){
        @Override public void run(){
            if(floating==null)return;
            updateClock();handler.postDelayed(this,1000L);
        }
    };
    private void updateClock(){
        if(clockView!=null){
            SimpleDateFormat f=new SimpleDateFormat("HH:mm:ss",Locale.forLanguageTag("vi-VN"));
            f.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
            clockView.setText("🕒 "+f.format(new Date()));
        }
    }
    private void showTimer(int secs){
        message(String.format(Locale.ROOT,"⏳ Rương còn %02d:%02d • không rời LIVE",secs/60,secs%60));
    }
    private void message(String text){
        if(text.equals(status))return;status=text;
        if(statusView!=null)statusView.setText(text);
        if(miniCaption!=null){
            if(paused)miniCaption.setText("⚠ Tạm dừng");
            else if(step==Step.WAIT && text.contains("Rương còn")){
                miniCaption.setText("⏱ "+text.replaceAll(".*?(\\d{2}:\\d{2}).*","$1"));
            } else miniCaption.setText(mode==Mode.HEART?"❤️ Tap":"🎁 TikXu");
        }
        if(totalView!=null)totalView.setText("🪙 Xu thực nhận: "+total+"   •   🎁 Rương: "+successfulRums);
        if(timerView!=null){
            if(text.contains("Rương còn"))timerView.setText(text);
            else if(step!=Step.WAIT)timerView.setText(mode==Mode.HEART?"❤️ Ở nguyên phòng • không vuốt":"⏱ Quét 6s • kiểm tra lại 10s");
        }
    }
    private int dp(float n){return (int)(n*service.getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String value,int size,int color){
        TextView t=new TextView(service);t.setText(value);t.setTextColor(color);t.setTextSize(size);
        t.setPadding(dp(4),dp(5),dp(4),dp(5));return t;
    }
    private GradientDrawable bg(int color,int outline){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(15));d.setStroke(dp(1),outline);return d;
    }
    private EditText entry(String hint){
        EditText t=new EditText(service);t.setSingleLine(true);t.setTextSize(14);
        t.setTextColor(Color.WHITE);t.setHintTextColor(0xff9cafc7);t.setHint(hint);
        t.setBackground(bg(0xff14223e,0xff355473));
        t.setPadding(dp(10),0,dp(10),0);
        return t;
    }
    /** Compact 4-action overlay. Controls only expand on demand; all LIVE actions
     * keep a small, draggable avatar on screen instead of a full-sized panel. */
    private void showOverlay(){
        try{
            wm=(WindowManager)service.getSystemService(Context.WINDOW_SERVICE);
            FrameLayout host=new FrameLayout(service);
            LinearLayout panel=new LinearLayout(service);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setPadding(dp(11),dp(8),dp(11),dp(10));
            panel.setBackground(bg(0xf418263e,0xff39d9ed));

            LinearLayout header=new LinearLayout(service);
            header.setGravity(Gravity.CENTER_VERTICAL);
            headline=label("✦ TikXu • ĐIỂU TUẤN",15,0xff8af6ff);
            headline.setSingleLine(true);
            header.addView(headline,new LinearLayout.LayoutParams(0,dp(34),1));
            TextView shrink=label("−",26,0xffa8eff3);
            shrink.setGravity(Gravity.CENTER);
            header.addView(shrink,new LinearLayout.LayoutParams(dp(38),dp(34)));
            panel.addView(header);

            clockView=label("🕒 --:--:--",12,0xff9ff1d8);
            panel.addView(clockView);
            statusView=label("Sẵn sàng • chọn chế độ",12,Color.WHITE);
            statusView.setMaxLines(3);
            panel.addView(statusView);
            timerView=label("⏱ LIVE 6s • kiểm tra lại 10s",11,0xffffde9c);
            timerView.setMaxLines(2);
            panel.addView(timerView);
            totalView=label("🪙 Xu: 0   🎁 Rương: 0",11,0xff70e5c0);
            panel.addView(totalView);

            LinearLayout rowOne=new LinearLayout(service);
            TextView multi=quickButton("🎁 Nhiều phòng");
            TextView single=quickButton("🏠 1 phòng");
            rowOne.addView(multi,new LinearLayout.LayoutParams(0,dp(42),1));
            rowOne.addView(single,new LinearLayout.LayoutParams(0,dp(42),1));
            panel.addView(rowOne);
            LinearLayout rowTwo=new LinearLayout(service);
            TextView tap=quickButton("❤️ Tap tim");
            TextView config=quickButton("⚙ Cài đặt");
            rowTwo.addView(tap,new LinearLayout.LayoutParams(0,dp(42),1));
            rowTwo.addView(config,new LinearLayout.LayoutParams(0,dp(42),1));
            panel.addView(rowTwo);

            settingsPanel=new LinearLayout(service);
            settingsPanel.setOrientation(LinearLayout.VERTICAL);
            settingsPanel.setPadding(0,dp(6),0,dp(7));
            settingsPanel.setVisibility(View.GONE);
            settingsPanel.addView(label("TAP THEO ID • NHẬP HẸN GIỜ",12,0xff8cf1ff));
            userField=entry("@ID TikTok");
            settingsPanel.addView(userField,new LinearLayout.LayoutParams(-1,dp(42)));
            LinearLayout timeRow=new LinearLayout(service);
            hourField=entry("HH:mm (trống = ngay)");
            durationField=entry("Phút");
            durationField.setInputType(InputType.TYPE_CLASS_NUMBER);
            durationField.setText("60");
            timeRow.addView(hourField,new LinearLayout.LayoutParams(0,dp(42),2));
            timeRow.addView(durationField,new LinearLayout.LayoutParams(0,dp(42),1));
            settingsPanel.addView(timeRow);
            LinearLayout tapRow=new LinearLayout(service);
            countView=quickButton("10K tap ↻");
            tapRow.addView(countView,new LinearLayout.LayoutParams(0,dp(42),1));
            countView.setOnClickListener(v->{
                goalIdx=(goalIdx+1)%goals.length;
                goal=goals[goalIdx];
                countView.setText((goal/1000)+"K tap ↻");
            });
            TextView scheduleButton=quickButton("HẸN TAP ▶");
            scheduleButton.setTextColor(0xff83ffe2);
            tapRow.addView(scheduleButton,new LinearLayout.LayoutParams(0,dp(42),1));
            scheduleButton.setOnClickListener(v->{
                scheduleHeartFromBubble();
                if(running && mode==Mode.HEART && scheduledAt>0)setMini(true);
            });
            settingsPanel.addView(tapRow);
            panel.addView(settingsPanel);

            multi.setOnClickListener(v->{start(Mode.MULTI);setMini(true);});
            single.setOnClickListener(v->{start(Mode.SINGLE);setMini(true);});
            tap.setOnClickListener(v->{
                if(running && mode!=Mode.HEART)stop("Đổi sang chế độ Tap");
                settingsPanel.setVisibility(View.VISIBLE);
                message("❤️ Nhập @ID, giờ, số tap → bấm HẸN TAP");
            });
            config.setOnClickListener(v->{
                boolean open=settingsPanel.getVisibility()!=View.VISIBLE;
                settingsPanel.setVisibility(open?View.VISIBLE:View.GONE);
            });

            LinearLayout control=new LinearLayout(service);
            pauseBtn=quickButton("⏸ Tạm dừng");
            TextView end=quickButton("■ Dừng");
            end.setTextColor(0xffffb9c4);
            control.addView(pauseBtn,new LinearLayout.LayoutParams(0,dp(42),1));
            control.addView(end,new LinearLayout.LayoutParams(0,dp(42),1));
            panel.addView(control);
            pauseBtn.setOnClickListener(v->{
                if(!running){
                    message("Chưa chạy • hãy chọn Nhiều phòng, 1 phòng hoặc hẹn Tap");
                    return;
                }
                paused=!paused;
                pauseBtn.setText(paused?"▶ Tiếp tục":"⏸ Tạm dừng");
                if(paused)message("Tạm dừng • ở nguyên LIVE");
                else {
                    frame=null;lastError="";
                    if(step==Step.ICON||step==Step.SCAN||step==Step.VERIFY_OPEN)
                        stepAt=SystemClock.elapsedRealtime();
                    message("Đã tiếp tục • kiểm tra lại LIVE");
                }
            });
            end.setOnClickListener(v->{stop("Đã dừng");setMini(true);});
            shrink.setOnClickListener(v->setMini(true));

            int panelWidth=Math.min(dp(264),width-dp(16));
            ScrollView panelScroll=new ScrollView(service);
            panelScroll.setFillViewport(false);
            panelScroll.setVerticalScrollBarEnabled(false);
            panelScroll.addView(panel);
            host.addView(panelScroll,new FrameLayout.LayoutParams(panelWidth,-2));

            FrameLayout bubble=new FrameLayout(service);
            GradientDrawable ring=new GradientDrawable();
            ring.setShape(GradientDrawable.OVAL);
            ring.setColor(0xff2cdbea);
            bubble.setBackground(ring);
            ImageView photo=new ImageView(service);
            photo.setImageResource(R.drawable.tikxu_bubble_photo);
            photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
            GradientDrawable mask=new GradientDrawable();
            mask.setShape(GradientDrawable.OVAL);
            mask.setColor(Color.WHITE);
            photo.setBackground(mask);
            photo.setClipToOutline(true);
            bubble.addView(photo,new FrameLayout.LayoutParams(dp(51),dp(51),Gravity.CENTER));
            TextView bubbleStatus=label("TikXu",9,Color.WHITE);
            bubbleStatus.setSingleLine(true);
            bubbleStatus.setGravity(Gravity.CENTER);
            bubbleStatus.setPadding(dp(1),0,dp(1),0);
            bubbleStatus.setBackground(bg(0xea11223c,0xff3ad8e3));
            bubble.addView(bubbleStatus,new FrameLayout.LayoutParams(dp(48),dp(16),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL));
            host.addView(bubble,new FrameLayout.LayoutParams(dp(56),dp(56)));

            expandedPanel=panelScroll;miniPanel=bubble;miniCaption=bubbleStatus;
            floatingParams=new WindowManager.LayoutParams(dp(56),dp(56),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
            floatingParams.gravity=Gravity.TOP|Gravity.START;
            floatingParams.x=Math.max(dp(4),width-dp(65));
            floatingParams.y=dp(130);
            mini=true;panelScroll.setVisibility(View.GONE);bubble.setVisibility(View.VISIBLE);
            bubble.setOnTouchListener(dragOrTap(()->setMini(false)));
            headline.setOnTouchListener(dragOrTap(()->{}));
            wm.addView(host,floatingParams);floating=host;
            updateClock();handler.removeCallbacks(clockTick);handler.postDelayed(clockTick,1000L);
        }catch(Exception e){
            Toast.makeText(service,"Không mở được bóng nổi: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    private TextView quickButton(String text){
        TextView v=label(text,12,Color.WHITE);
        v.setGravity(Gravity.CENTER);
        v.setBackground(bg(0xff233958,0xff4d7097));
        return v;
    }
    /** Floating dot and expanded header both support dragging without blocking LIVE. */
    private View.OnTouchListener dragOrTap(Runnable click){
        return new View.OnTouchListener(){
            float downX,downY;int originalX,originalY;boolean dragging;
            @Override public boolean onTouch(View v,MotionEvent ev){
                if(floatingParams==null||wm==null||floating==null)return false;
                if(ev.getActionMasked()==MotionEvent.ACTION_DOWN){
                    downX=ev.getRawX();downY=ev.getRawY();
                    originalX=floatingParams.x;originalY=floatingParams.y;
                    dragging=false;return true;
                }
                if(ev.getActionMasked()==MotionEvent.ACTION_MOVE){
                    int dx=Math.round(ev.getRawX()-downX),dy=Math.round(ev.getRawY()-downY);
                    if(Math.abs(dx)>dp(6)||Math.abs(dy)>dp(6))dragging=true;
                    if(dragging){
                        int bubbleWidth=mini?dp(56):Math.min(dp(264),width-dp(16));
                        floatingParams.x=Math.max(0,Math.min(width-bubbleWidth,originalX+dx));
                        floatingParams.y=Math.max(dp(35),Math.min(height-dp(85),originalY+dy));
                        try{wm.updateViewLayout(floating,floatingParams);}catch(Exception ignored){}
                    }
                    return true;
                }
                if(ev.getActionMasked()==MotionEvent.ACTION_UP){if(!dragging)click.run();return true;}
                return true;
            }
        };
    }
    private void setMini(boolean collapse){
        if(floating==null||floatingParams==null||wm==null)return;
        mini=collapse;
        expandedPanel.setVisibility(collapse?View.GONE:View.VISIBLE);
        miniPanel.setVisibility(collapse?View.VISIBLE:View.GONE);
        floatingParams.width=collapse?dp(56):Math.min(dp(264),width-dp(16));
        floatingParams.height=collapse?dp(56):Math.min(dp(324),height-dp(130));
        floatingParams.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|
            (collapse?WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE:0);
        floatingParams.x=Math.max(0,Math.min(width-floatingParams.width,floatingParams.x));
        floatingParams.y=Math.max(dp(32),Math.min(height-(collapse?dp(72):floatingParams.height)-dp(20),floatingParams.y));
        try{wm.updateViewLayout(floating,floatingParams);}catch(Exception ignored){}
    }
    private void checkLicense(){
        waitingLicense=true;lastLicense=SystemClock.elapsedRealtime();
        new Thread(()->{
            String error=null;
            try{JSONObject me=AuthApi.request(service,"GET","/v1/me",null,true);
                if(me.optBoolean("emergency_stop"))error="ADMIN đã dừng hệ thống";
            }catch(Exception e){error="Phiên đăng nhập/mạng lỗi: "+e.getMessage();}
            final String reason=error;
            handler.post(()->{waitingLicense=false;if(running&&reason!=null)stop(reason);});
        },"TikXu-AccessCheck").start();
    }
}

package com.example.tikxu;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** HTTPS-only account API. NEVER contains a client-side admin credential. */
public final class AuthApi {
    private static final String SP="tikxu_auth", KEY_ALIAS="tikxu_token_aes";
    private AuthApi() {}
    private static SharedPreferences prefs(Context c) {return c.getSharedPreferences(SP,Context.MODE_PRIVATE);}
    // Public service endpoint, not a password. A fixed URL avoids manual entry mistakes.
    private static final String SERVER_URL="https://dieu-tuan-tikxu-api.tukuba41007.workers.dev";
    public static String apiUrl(Context c) { return SERVER_URL; }
    public static void setApiUrl(Context c,String url) { /* Configured in app. */ }
    private static SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        KeyStore.Entry entry=store.getEntry(KEY_ALIAS,null);
        if(entry instanceof KeyStore.SecretKeyEntry) return ((KeyStore.SecretKeyEntry)entry).getSecretKey();
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build());
        return gen.generateKey();
    }
    private static String encrypt(String s) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] encoded=cipher.doFinal(s.getBytes(StandardCharsets.UTF_8));
        byte[] iv=cipher.getIV();byte[] all=new byte[iv.length+encoded.length];
        System.arraycopy(iv,0,all,0,iv.length);
        System.arraycopy(encoded,0,all,iv.length,encoded.length);
        return Base64.encodeToString(all,Base64.NO_WRAP);
    }
    private static String decrypt(String s) throws Exception {
        byte[] all=Base64.decode(s,Base64.NO_WRAP);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,all,0,12));
        return new String(cipher.doFinal(all,12,all.length-12),StandardCharsets.UTF_8);
    }
    public static void saveLogin(Context c,JSONObject data) throws Exception {
        prefs(c).edit().putString("token_encrypted",encrypt(data.getString("token")))
            .putString("role",data.getString("role"))
            .putString("username",data.getString("username"))
            .putLong("expires_at",data.optLong("license_expires_at",0)).apply();
    }
    public static String token(Context c) {
        try {return decrypt(prefs(c).getString("token_encrypted",""));}
        catch(Exception ignored){return "";}
    }
    public static boolean isAdmin(Context c){return "ADMIN".equals(prefs(c).getString("role",""));}
    public static String username(Context c){return prefs(c).getString("username","");}
    public static void clear(Context c){prefs(c).edit().remove("token_encrypted").remove("role").remove("username").remove("expires_at").apply();}
    public static JSONObject request(Context c,String method,String route,JSONObject body,boolean authorized) throws Exception {
        String host=apiUrl(c);
        if(!host.startsWith("https://")) throw new IllegalStateException("Chưa cấu hình địa chỉ máy chủ HTTPS");
        HttpURLConnection connection=(HttpURLConnection)new URL(host+route).openConnection();
        connection.setConnectTimeout(10000);connection.setReadTimeout(10000);
        connection.setRequestMethod(method);connection.setRequestProperty("Accept","application/json");
        if(authorized) {
            String t=token(c);if(t.length()<20)throw new IllegalStateException("Chưa đăng nhập");
            connection.setRequestProperty("Authorization","Bearer "+t);
        }
        if(body!=null) {
            connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
            try(OutputStream out=connection.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}
        }
        int code=connection.getResponseCode();
        InputStream stream=code>=400?connection.getErrorStream():connection.getInputStream();
        if(stream==null)throw new IllegalStateException("Máy chủ không phản hồi");
        try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] data=new byte[4096];int n;
            while((n=in.read(data))!=-1){out.write(data,0,n);if(out.size()>1024*1024)throw new IllegalStateException("Dữ liệu quá lớn");}
            JSONObject response=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
            if(code>=400)throw new IllegalStateException(response.optString("error","Lỗi máy chủ: "+code));
            return response;
        } finally {connection.disconnect();}
    }
}

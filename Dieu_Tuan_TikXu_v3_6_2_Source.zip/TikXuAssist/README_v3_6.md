# ĐIỂU TUẤN • TikXu v3.6 (bản đổi hình)

- Bóng nổi mini dùng ảnh người do chủ ứng dụng cung cấp, cắt chân dung và bo tròn; vẫn có thể kéo và chạm mở bảng.
- Biểu tượng app trên Android và avatar tại màn hình đăng nhập đổi sang icon neon trái tim mới.
- Giữ nguyên mã săn rương và tap của v3.5; bản này chỉ đổi giao diện hình và tăng version.
- Chưa kiểm nghiệm chạy trên TikTok thực tế.
- Không cần thay Cloudflare Worker hoặc database.

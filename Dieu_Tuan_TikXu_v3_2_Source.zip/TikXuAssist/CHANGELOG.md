# v3.2 Accounts / ADMIN
- Bỏ khóa offline và dự định gửi mật khẩu Gmail; thêm đăng nhập tên người dùng + mật khẩu qua HTTPS.
- Thêm backend Cloudflare Workers + D1: ADM (bí mật cấu hình riêng), user mặc định 45 ngày; kiểm tra và thực thi phân quyền máy chủ.
- Quản trị user: tạo, xem hạn, gia hạn, khóa/mở, reset mật khẩu; thông báo và dừng khẩn cấp (polling).
- Dashboard ADMIN: chỉnh chờ săn room, thống kê và nhật ký cục bộ, tùy chỉnh lớp nền neon.
- Service đọc hạn dùng/blocked/remote-stop định kỳ; không có mạng hoặc không còn quyền thì dừng.
- Cải thiện bảo vệ room / chờ 15 giây, đồng hồ nổi vẫn thấy khi thu nhỏ.
- Còn chưa test Android Build/LIVE thực tế; backend chưa tự triển khai.

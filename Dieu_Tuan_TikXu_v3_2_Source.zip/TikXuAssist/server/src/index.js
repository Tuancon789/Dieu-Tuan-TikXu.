const encoder = new TextEncoder();
const DAY = 86400000;
const ITERATIONS = 180000;
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store',
    'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer' }
});
const fail = (message, code = 400) => json({error: message}, code);
const base64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)));
const hex = (buf) => [...new Uint8Array(buf)].map(x=>x.toString(16).padStart(2,'0')).join('');
const random = (size) => crypto.getRandomValues(new Uint8Array(size));
const hashToken = async (token) => hex(await crypto.subtle.digest('SHA-256', encoder.encode(token)));
async function passwordHash(password, saltB64) {
  const salt = Uint8Array.from(atob(saltB64), ch => ch.charCodeAt(0));
  const material = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:ITERATIONS,hash:'SHA-256'}, material, 256));
}
const safeEquals = (a,b) => {
  const x=encoder.encode(a),y=encoder.encode(b);
  if(x.length!==y.length) return false;
  let mismatch=0; for(let i=0;i<x.length;i++) mismatch|=(x[i]^y[i]); return mismatch===0;
};
const cleanUsername = x => typeof x==='string' && /^[a-zA-Z0-9_]{3,32}$/.test(x) ? x : null;
const passOk = p => typeof p==='string' && p.length>=8 && p.length<=128;
const numDays = x => Number.isInteger(x) && x>=1 && x<=3650 ? x : null;
const nonce = () => base64(random(32)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/g,'');
async function body(req) { try { return await req.json(); } catch { return null; } }
async function setting(env,key) { return (await env.DB.prepare('SELECT value FROM settings WHERE name=?').bind(key).first())?.value ?? ''; }
async function issueToken(env, userId, admin) {
  const token = nonce(), now=Date.now();
  await env.DB.prepare('INSERT INTO sessions(token_hash,user_id,is_admin,expires_at,created_at) VALUES(?,?,?,?,?)')
    .bind(await hashToken(token),userId, admin?1:0,now + (admin?12:24)*3600000,now).run();
  return token;
}
async function authorize(req,env) {
  const match = /^Bearer ([A-Za-z0-9_-]{30,})$/.exec(req.headers.get('Authorization')||'');
  if(!match) return null;
  const item=await env.DB.prepare(`SELECT s.user_id,s.is_admin,s.expires_at AS session_expires,u.username,
    u.expires_at AS license_expires_at,u.blocked FROM sessions s
    LEFT JOIN users u ON u.id=s.user_id WHERE s.token_hash=?`).bind(await hashToken(match[1])).first();
  if (!item || item.session_expires<=Date.now()) return null;
  if (!item.is_admin && (!item.username || item.blocked || item.license_expires_at<=Date.now())) return null;
  return {...item,role:item.is_admin?'ADMIN':'USER',username:item.is_admin?'ADM':item.username};
}
async function limited(req,env,username) {
  const ip = req.headers.get('CF-Connecting-IP') ?? 'unknown';
  const key = hex(await crypto.subtle.digest('SHA-256',encoder.encode(ip+'|'+username.toLowerCase())));
  const now=Date.now(); let r=await env.DB.prepare('SELECT count,reset_at FROM login_attempts WHERE key=?').bind(key).first();
  if(r?.reset_at > now && r.count>=8) return {key,blocked:true};
  return {key,blocked:false,count:r?.reset_at>now?r.count:0,reset_at:r?.reset_at>now?r.reset_at:now+600000};
}
async function badAttempt(env,l) {
  await env.DB.prepare('INSERT INTO login_attempts(key,count,reset_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET count=excluded.count,reset_at=excluded.reset_at')
    .bind(l.key,l.count+1,l.reset_at).run();
}
async function login(req,env) {
  const p=await body(req); const username=cleanUsername(p?.username);
  if (!username || typeof p?.password!=='string') return fail('Tên đăng nhập hoặc mật khẩu không hợp lệ');
  const l=await limited(req,env,username); if(l.blocked) return fail('Thử quá nhiều lần, đợi 10 phút',429);
  if(username.toUpperCase()==='ADM') {
    if(!env.ADMIN_PASSWORD || !safeEquals(await hashToken(p.password),await hashToken(env.ADMIN_PASSWORD))) {
      await badAttempt(env,l); return fail('Sai tài khoản hoặc mật khẩu',401);
    }
    await env.DB.prepare('DELETE FROM login_attempts WHERE key=?').bind(l.key).run();
    return json({token:await issueToken(env,null,true),role:'ADMIN',username:'ADM',license_expires_at:null,
      emergency_stop:(await setting(env,'emergency_stop'))==='true',notice:await setting(env,'notice')});
  }
  const user=await env.DB.prepare('SELECT * FROM users WHERE username=?').bind(username).first();
  if(!user || !safeEquals(await passwordHash(p.password,user.salt),user.password_hash)) {
    await badAttempt(env,l); return fail('Sai tài khoản hoặc mật khẩu',401);
  }
  if(user.blocked) return fail('Tài khoản đã bị khóa',403);
  if(user.expires_at <= Date.now()) return fail('Tài khoản đã hết hạn, liên hệ ADMIN để gia hạn',403);
  await env.DB.prepare('DELETE FROM login_attempts WHERE key=?').bind(l.key).run();
  return json({token:await issueToken(env,user.id,false),role:'USER',username:user.username,
    license_expires_at:user.expires_at,emergency_stop:(await setting(env,'emergency_stop'))==='true',notice:await setting(env,'notice')});
}
async function adminRoute(req,env,path) {
  if(req.method==='GET' && path==='/v1/admin/users') {
    const data=await env.DB.prepare('SELECT id,username,expires_at,blocked,created_at,updated_at FROM users ORDER BY created_at DESC LIMIT 500').all();
    return json({users:data.results});
  }
  if(req.method==='POST' && path==='/v1/admin/users') {
    const p=await body(req), username=cleanUsername(p?.username),days=p?.days??45;
    if(!username || username.toUpperCase()==='ADM' || !passOk(p?.password) || !numDays(days))
      return fail('Tên đăng nhập 3–32 ký tự, mật khẩu ít nhất 8 ký tự và hạn 1–3650 ngày');
    const salt=base64(random(16)), hashed=await passwordHash(p.password,salt), now=Date.now();
    try { const r=await env.DB.prepare('INSERT INTO users(username,salt,password_hash,expires_at,created_at,updated_at) VALUES(?,?,?,?,?,?)')
      .bind(username,salt,hashed,now+days*DAY,now,now).run();
      return json({ok:true,id:r.meta.last_row_id,username,expires_at:now+days*DAY},201);
    } catch {return fail('Tài khoản đã tồn tại hoặc dữ liệu không hợp lệ',409);}
  }
  const match=/^\/v1\/admin\/users\/(\d+)\/(extend|block|password)$/.exec(path);
  if(req.method==='POST' && match) {
    const id=Number(match[1]), action=match[2], p=await body(req);
    const current=await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(id).first();
    if(!current) return fail('Không thấy tài khoản',404);
    if(action==='extend') {
      if(!numDays(p?.days)) return fail('Chọn 1–3650 ngày');
      const expires=Math.max(Date.now(),current.expires_at)+p.days*DAY;
      await env.DB.prepare('UPDATE users SET expires_at=?,updated_at=? WHERE id=?').bind(expires,Date.now(),id).run();
      return json({ok:true,expires_at:expires});
    }
    if(action==='block') {
      if(typeof p?.blocked!=='boolean') return fail('Thiếu trạng thái blocked');
      await env.DB.prepare('UPDATE users SET blocked=?,updated_at=? WHERE id=?').bind(p.blocked?1:0,Date.now(),id).run();
      await env.DB.prepare('DELETE FROM sessions WHERE user_id=?').bind(id).run();
      return json({ok:true,blocked:p.blocked});
    }
    if(!passOk(p?.password)) return fail('Mật khẩu mới phải có ít nhất 8 ký tự');
    const salt=base64(random(16));
    await env.DB.prepare('UPDATE users SET salt=?,password_hash=?,updated_at=? WHERE id=?')
      .bind(salt,await passwordHash(p.password,salt),Date.now(),id).run();
    await env.DB.prepare('DELETE FROM sessions WHERE user_id=?').bind(id).run();
    return json({ok:true});
  }
  if(req.method==='POST' && path==='/v1/admin/emergency') {
    const p=await body(req); if(typeof p?.stopped!=='boolean') return fail('Thiếu stopped');
    await env.DB.prepare("UPDATE settings SET value=? WHERE name='emergency_stop'").bind(p.stopped?'true':'false').run();
    return json({ok:true,emergency_stop:p.stopped});
  }
  if(req.method==='POST' && path==='/v1/admin/notice') {
    const p=await body(req); if(typeof p?.text!=='string'||p.text.length>500) return fail('Thông báo quá dài');
    await env.DB.prepare("UPDATE settings SET value=? WHERE name='notice'").bind(p.text).run();
    return json({ok:true});
  }
  return fail('Không tồn tại chức năng ADMIN',404);
}
export default {
  async fetch(req,env) {
    try {
      const path=new URL(req.url).pathname;
      if(req.method==='GET'&&path==='/v1/health') return json({status:'ok'});
      if(req.method==='POST'&&path==='/v1/login') return login(req,env);
      const me=await authorize(req,env); if(!me) return fail('Phiên đăng nhập hết hạn, hoặc tài khoản bị khóa/hết hạn',401);
      if(req.method==='GET'&&path==='/v1/me') return json({role:me.role,username:me.username,
        license_expires_at:me.license_expires_at,emergency_stop:(await setting(env,'emergency_stop'))==='true',
        notice:await setting(env,'notice')});
      if(req.method==='POST'&&path==='/v1/logout') {
        const token=req.headers.get('Authorization').slice(7);
        await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await hashToken(token)).run();
        return json({ok:true});
      }
      if(path.startsWith('/v1/admin/')) {
        if(me.role!=='ADMIN') return fail('Chỉ ADMIN có quyền này',403);
        return adminRoute(req,env,path);
      }
      return fail('Không tìm thấy đường dẫn',404);
    } catch (e) {console.error('API error',e?.message);return fail('Lỗi máy chủ',500);}
  }
};

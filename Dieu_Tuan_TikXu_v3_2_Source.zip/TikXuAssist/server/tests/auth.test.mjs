import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../src/index.js';

function fakeDB() {
  const db={sessions:new Map(),users:new Map(),attempts:new Map(),settings:new Map([['notice',''],['emergency_stop','false']]),nextId:1};
  db.prepare=(sql)=>{
    let params=[];
    const stmt={bind(...args){params=args;return stmt;},async first(){
      if(sql.includes('login_attempts WHERE'))return db.attempts.get(params[0])??null;
      if(sql.includes('settings WHERE'))return {value:db.settings.get(params[0])??''};
      if(sql.includes('SELECT * FROM users WHERE username'))return [...db.users.values()].find(u=>u.username.toLowerCase()===params[0].toLowerCase())??null;
      if(sql.includes('SELECT * FROM users WHERE id'))return db.users.get(params[0])??null;
      if(sql.includes('FROM sessions s')){
        const s=db.sessions.get(params[0]); if(!s)return null;
        const u=s.user_id?db.users.get(s.user_id):null;
        return {user_id:s.user_id,is_admin:s.is_admin,session_expires:s.expires_at,
          username:u?.username,license_expires_at:u?.expires_at,blocked:u?.blocked};
      }
      return null;
    },async all(){
      if(sql.startsWith('SELECT id,username'))return {results:[...db.users.values()].map(({id,username,expires_at,blocked,created_at,updated_at})=>({id,username,expires_at,blocked,created_at,updated_at}))};
      return {results:[]};
    },async run(){
      if(sql.includes('INSERT INTO sessions')){db.sessions.set(params[0],{user_id:params[1],is_admin:params[2],expires_at:params[3]});return {meta:{}};}
      if(sql.includes('INSERT INTO users')){
        const id=db.nextId++;db.users.set(id,{id,username:params[0],salt:params[1],password_hash:params[2],expires_at:params[3],blocked:0,created_at:params[4],updated_at:params[5]});return {meta:{last_row_id:id}};
      }
      if(sql.includes('UPDATE users SET expires_at')){Object.assign(db.users.get(params[2]),{expires_at:params[0],updated_at:params[1]});return {};}
      if(sql.includes('UPDATE users SET blocked')){Object.assign(db.users.get(params[2]),{blocked:params[0],updated_at:params[1]});return {};}
      if(sql.includes('UPDATE users SET salt')){Object.assign(db.users.get(params[3]),{salt:params[0],password_hash:params[1],updated_at:params[2]});return {};}
      if(sql.includes('DELETE FROM sessions WHERE user_id')){for(const [k,v] of db.sessions)if(v.user_id===params[0])db.sessions.delete(k);return {};}
      if(sql.includes('INSERT INTO login_attempts')){db.attempts.set(params[0],{count:params[1],reset_at:params[2]});return {};}
      if(sql.includes('DELETE FROM login_attempts')){db.attempts.delete(params[0]);return {};}
      if(sql.includes('UPDATE settings')){db.settings.set(sql.includes('emergency_stop')?'emergency_stop':'notice',params[0]);return {};}
      if(sql.includes('DELETE FROM sessions WHERE token_hash')){db.sessions.delete(params[0]);return {};}
      return {};
    }};return stmt;
  };
  return db;
}
async function call(env,method,path,payload,token){
  const headers={'Content-Type':'application/json'};
  if(token)headers.Authorization='Bearer '+token;
  const req=new Request('https://example.workers.dev'+path,{method,headers,body:payload?JSON.stringify(payload):undefined});
  const resp=await worker.fetch(req,env);
  return {status:resp.status,data:await resp.json()};
}
test('health, ADMIN creation, 45-day user expiry, server role enforcement, block',async()=>{
  const env={DB:fakeDB(),ADMIN_PASSWORD:'test-admin-password-not-published'};
  let r=await call(env,'GET','/v1/health');assert.equal(r.status,200);
  r=await call(env,'POST','/v1/login',{username:'ADM',password:env.ADMIN_PASSWORD});
  assert.equal(r.status,200);assert.equal(r.data.role,'ADMIN');const adminToken=r.data.token;
  r=await call(env,'POST','/v1/admin/users',{username:'khach001',password:'test-password-001',days:45},adminToken);
  assert.equal(r.status,201);assert.ok(r.data.expires_at-Date.now()>44*86400000);
  r=await call(env,'POST','/v1/login',{username:'khach001',password:'test-password-001'});
  assert.equal(r.status,200);const userToken=r.data.token;
  r=await call(env,'GET','/v1/admin/users',null,userToken);assert.equal(r.status,403);
  r=await call(env,'POST','/v1/admin/users/1/extend',{days:7},adminToken);assert.equal(r.status,200);
  r=await call(env,'POST','/v1/admin/users/1/block',{blocked:true},adminToken);assert.equal(r.status,200);
  r=await call(env,'GET','/v1/me',null,userToken);assert.equal(r.status,401);
  r=await call(env,'POST','/v1/login',{username:'khach001',password:'test-password-001'});assert.equal(r.status,403);
});

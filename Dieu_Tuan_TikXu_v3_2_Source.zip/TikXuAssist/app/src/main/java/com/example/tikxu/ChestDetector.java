package com.example.tikxu;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Heuristic for TikTok UI SCREENSHOTS ONLY; no network or TikTok API.
 * Without a detected countdown we do NOT guess where to click.
 */
public final class ChestDetector {
    public enum Kind { NONE, CHEST, BAG }
    public enum Requirement { NONE, COMMENT, SHARE, FAN_CLUB }
    public static final class Result {
        public final Kind kind;
        public final Integer seconds;
        public final Rect icon;
        public final Rect claimButton;
        public final boolean modalOpen;
        public final Requirement requirement;
        public final String summary;
        public final boolean hasAnyTimer;
        Result(Kind kind, Integer seconds, Rect icon, Rect claimButton,
               boolean modalOpen, Requirement requirement, boolean any, String summary) {
            this.kind=kind; this.seconds=seconds; this.icon=icon;
            this.claimButton=claimButton; this.modalOpen=modalOpen;
            this.requirement=requirement; this.hasAnyTimer=any; this.summary=summary;
        }
    }
    private static final class Line {
        final String value;
        final Rect bounds;
        Line(String value, Rect bounds) { this.value=value; this.bounds=bounds; }
    }
    private static final Pattern TIME = Pattern.compile("(?<!\\d)(\\d{1,2})\\s*[:：]\\s*(\\d{2})(?!\\d)");
    private static String norm(String raw) {
        return Normalizer.normalize(raw.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").replace('đ', 'd').replaceAll("\\s+", " ").trim();
    }
    private static boolean hasAny(String value, String... options) {
        for (String k:options) if (value.contains(k)) return true;
        return false;
    }
    public static Result detect(Text text, Bitmap bitmap, boolean allowChest, boolean allowBag) {
        int width=bitmap.getWidth(), height=bitmap.getHeight();
        List<Line> lines=new ArrayList<>();
        StringBuilder all=new StringBuilder();
        for (Text.TextBlock block:text.getTextBlocks()) {
            for (Text.Line line:block.getLines()) {
                Rect r=line.getBoundingBox();
                if (r!=null) {
                    String s=norm(line.getText());
                    lines.add(new Line(s,new Rect(r))); all.append(' ').append(s);
                }
            }
        }
        String full=all.toString();
        boolean chestHeader=false, bagHeader=false;
        // A chat message may say "đã gửi Rương Báu". Count ONLY a heading in
        // the central modal area, not arbitrary text elsewhere in the LIVE.
        for (Line line:lines) {
            if (line.bounds.centerY()<height*0.33f || line.bounds.centerY()>height*0.69f) continue;
            if (line.value.length()<=32 && hasAny(line.value,"ruong bau","ruong xu","lucky box"))
                chestHeader=true;
            if (line.value.length()<=55 && hasAny(line.value,"tui qua se mo","tui qua"))
                bagHeader=true;
        }
        boolean modalOpen=chestHeader || bagHeader;
        Requirement requirement=Requirement.NONE;
        if (modalOpen && hasAny(full,"chia se phien live de tham gia","chia se live de tham gia")) requirement=Requirement.SHARE;
        else if (modalOpen && hasAny(full,"binh luan de tham gia","gui binh luan","comment to join")) requirement=Requirement.COMMENT;
        else if (modalOpen && hasAny(full,"tham gia fan club","tham gia cau lac bo","join fan club")) requirement=Requirement.FAN_CLUB;
        Kind modalKind=bagHeader?Kind.BAG:(chestHeader?Kind.CHEST:Kind.NONE);

        // Locate a countdown in the top-left TikTok LIVE quick-icon row.
        Kind iconKind=Kind.NONE; Integer iconSeconds=null; Rect iconTarget=null;
        boolean anyTimer=false;
        for (Line line:lines) {
            Matcher matcher=TIME.matcher(line.value);
            while (matcher.find()) {
                int mm=Integer.parseInt(matcher.group(1)), ss=Integer.parseInt(matcher.group(2));
                if (mm>59 || ss>59) continue;
                anyTimer=true;
                Rect r=line.bounds;
                // LIVE icon countdowns in screenshots are normally left of center and
                // under the LIVE account header. The bound filters out score timers.
                if (r.centerX()>width*0.47f || r.centerY()<height*0.105f || r.centerY()>height*0.32f)
                    continue;
                Kind k=classifyColor(bitmap,r);
                if (k==Kind.NONE || (k==Kind.CHEST && !allowChest) || (k==Kind.BAG && !allowBag)) continue;
                Rect hit=iconRect(r,width,height);
                // Prefer the earliest supported icon when both types exist.
                if (iconTarget==null || hit.left<iconTarget.left) {
                    iconTarget=hit; iconKind=k; iconSeconds=mm*60+ss;
                }
            }
        }
        if (modalKind==Kind.CHEST && !allowChest || modalKind==Kind.BAG && !allowBag) modalKind=Kind.NONE;
        Kind kind = modalKind!=Kind.NONE?modalKind:iconKind;
        Integer seconds=iconSeconds;
        // A modal often has its own clock separate from the small icon.
        if (modalOpen) {
            for (Line line:lines) {
                Matcher m=TIME.matcher(line.value);
                if (m.find() && line.bounds.centerY()>height*0.34f) {
                    int mm=Integer.parseInt(m.group(1)), ss=Integer.parseInt(m.group(2));
                    if (mm<=59 && ss<=59) { seconds=mm*60+ss; break; }
                }
            }
        }
        Rect claim=null;
        if (modalOpen && requirement==Requirement.NONE) {
            for (Line line:lines) {
                String s=line.value;
                // White-list short positive claim labels, never 'Gửi'/'Nạp' or 'Tham gia'.
                if (hasAny(s,"gui","nap","tang","send","tham gia","join","mua")) continue;
                if (!hasAny(s,"nhan","mo ruong","claim","collect","open now")) continue;
                if (s.length()>28 || line.bounds.centerY()<height*0.45f) continue;
                claim=new Rect(line.bounds); break;
            }
        }
        String type=kind==Kind.CHEST?"Rương Báu":kind==Kind.BAG?"Túi quà":"Chưa thấy biểu tượng";
        String summary=type;
        if (seconds!=null) summary+=String.format(Locale.ROOT," • %02d:%02d",seconds/60,seconds%60);
        if (requirement==Requirement.SHARE) summary+=" • cần chia sẻ";
        if (requirement==Requirement.COMMENT) summary+=" • cần bình luận";
        if (requirement==Requirement.FAN_CLUB) summary+=" • cần Fan Club";
        return new Result(kind,seconds,iconTarget,claim,modalOpen,requirement,anyTimer,summary);
    }
    private static Rect iconRect(Rect timer,int w,int h) {
        int dx=(int)(w*0.013f), yUp=(int)(w*0.07f);
        int minTop=(int)(h*0.105f);
        return new Rect(Math.max(0,timer.left-dx),Math.max(minTop,timer.top-yUp),
            Math.min(w,timer.right+dx),Math.min(h,timer.bottom+(int)(w*0.012f)));
    }
    private static Kind classifyColor(Bitmap bmp, Rect timer) {
        int w=bmp.getWidth(), h=bmp.getHeight();
        int half=(int)(w*0.046f);
        int cx=timer.centerX();
        int top=Math.max((int)(h*0.10f),timer.top-(int)(w*0.075f));
        int bottom=Math.max(top+2,Math.min(h,timer.top+(int)(w*0.012f)));
        int purple=0, red=0, count=0;
        float[] hsv=new float[3];
        for (int y=top;y<bottom;y+=3) for (int x=Math.max(0,cx-half);x<Math.min(w,cx+half);x+=3) {
            Color.colorToHSV(bmp.getPixel(x,y),hsv);
            if (hsv[1]<0.45f || hsv[2]<0.32f) continue;
            if (hsv[0]>=250 && hsv[0]<=325) purple++;
            if ((hsv[0]<25 || hsv[0]>336) && hsv[1]>0.52f) red++;
            count++;
        }
        if (count<8) return Kind.NONE;
        if (purple>=Math.max(6,red*1.3)) return Kind.BAG;
        if (red>=Math.max(6,purple*1.3)) return Kind.CHEST;
        return Kind.NONE;
    }
}

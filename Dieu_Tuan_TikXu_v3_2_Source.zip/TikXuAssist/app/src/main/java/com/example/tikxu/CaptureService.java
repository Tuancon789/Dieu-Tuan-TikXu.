package com.example.tikxu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;


import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Prototype: OCR stays on this phone, never uploads screen images. */
public class CaptureService extends Service {
    public static final String ACTION_START = "com.example.tikxu.START";
    public static final String ACTION_RECORD_TOGGLE = "com.example.tikxu.RECORD_TOGGLE";
    public static final String EXTRA_AUTO_RECORD = "recordAfterConsent";
    public static volatile boolean activeCapture = false;
    public static volatile boolean activeRecording = false;
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final String CHANNEL = "tikxu_detection";
    private static final int NOTIFICATION_ID = 77;

    private WindowManager windowManager;
    private WindowManager.LayoutParams overlayParams;
    private View overlay;
    private TextView messageView;
    private TextView modeView;
    private TextView countdownView;
    private TextView miniView;
    private long countdownReadAt=0;
    private int countdownLast=-1;
    private LinearLayout overlayActions;
    private TextView recordButton;
    private TextView recordingLabel;
    private LiveRecorder recorder;
    private int captureWidth;
    private int captureHeight;
    private long lastBlackWarning;
    private boolean overlayCollapsed=false;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private HandlerThread worker;
    private Handler workerHandler;
    private final Handler main = new Handler(android.os.Looper.getMainLooper());
    private TextRecognizer recognizer;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private volatile boolean shutdown;
    private long lastScan;
    private long lastAlert;
    private long lastTap;
    private long lastLowCountdownAt;
    private boolean armed = true;
    private long lastOpen;
    private long roomStart;
    private long lastSwipe;
    private long protectedRoomUntil=0;
    private long lastGiftSeenAt=0;
    private long lastLicenseCheck=0;
    private volatile boolean licenseOk=false;
    private int swipes=0;
    private int emptyStreak=0;
    private volatile boolean paused=false;
    private SharedPreferences prefs;

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("tikxu", MODE_PRIVATE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Nhận diện rương xu",
            NotificationManager.IMPORTANCE_DEFAULT));
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (AuthApi.token(this).isEmpty()) {stopSelf();return START_NOT_STICKY;}
        if (ACTION_RECORD_TOGGLE.equals(intent.getAction())) {
            if (projection != null) toggleRecording();
            else showMessage("Hãy bấm BẮT ĐẦU QUÉT và cấp quyền màn hình trước khi quay");
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;
        if (projection != null) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }
        if (resultCode != android.app.Activity.RESULT_OK || data == null) {
            stopSelf(); return START_NOT_STICKY;
        }
        Notification notification = notification("Đang theo dõi màn hình, chạm để mở ứng dụng");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else startForeground(NOTIFICATION_ID, notification);
        createOverlay();
        roomStart=SystemClock.elapsedRealtime();
        validateLicense();
        initializeProjection(resultCode, data);
        if (intent.getBooleanExtra(EXTRA_AUTO_RECORD, false) && workerHandler != null)
            workerHandler.post(this::startRecordingInternal);
        return START_NOT_STICKY;
    }

    /** Server decides: even if local APK/preferences are modified, expired/blocked
     * users lose service access at next validation (at most 60 seconds). */
    private void validateLicense() {
        long now=SystemClock.elapsedRealtime();
        lastLicenseCheck=now;
        new Thread(() -> {
            try {
                org.json.JSONObject me=AuthApi.request(this,"GET","/v1/me",null,true);
                if(me.optBoolean("emergency_stop",false))throw new IllegalStateException("ADMIN tạm dừng toàn bộ quét");
                licenseOk=true;
                String notice=me.optString("notice","");
                if(!notice.isEmpty())showMessage("ADMIN: "+notice);
            } catch(Exception e) {
                licenseOk=false;
                showMessage("Không thể xác nhận hạn tài khoản: "+e.getMessage());
                main.post(this::stopSelf);
            }
        },"TikXu-Check-Account").start();
        main.postDelayed(()->{if(!shutdown && activeCapture)validateLicense();},60000);
    }

    private void logEvent(String event) {
        String line=new java.text.SimpleDateFormat("HH:mm:ss",java.util.Locale.US).format(new java.util.Date())+" "+event;
        String old=prefs.getString("log_recent","");
        prefs.edit().putString("log_recent",(line+"\n"+old).substring(0,Math.min(2800,(line+"\n"+old).length()))).apply();
    }

    private Notification notification(String message) {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(this, 0, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("ĐIỂU TUẤN • TikXu")
            .setContentText(message)
            .setContentIntent(open)
            .setOngoing(true)
            .build();
    }

    private void initializeProjection(int resultCode, Intent data) {
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        try {
            projection = manager.getMediaProjection(resultCode, data);
            if (projection == null) throw new IllegalStateException("No projection");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { main.post(() -> stopSelf()); }
            }, main);
            DisplayMetrics metrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            int width = metrics.widthPixels;
            int height = metrics.heightPixels;
            captureWidth = width;
            captureHeight = height;
            worker = new HandlerThread("TikXu-OCR"); worker.start();
            workerHandler = new Handler(worker.getLooper());
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(r -> processLatestFrame(r, width, height), workerHandler);
            virtualDisplay = projection.createVirtualDisplay("TikXuScreen", width, height,
                metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, workerHandler);
            recorder = new LiveRecorder(this);
            activeCapture = true;
            showMessage("Đang tìm rương xu trên TikTok LIVE…");
        } catch (Exception e) {
            showMessage("Không thể khởi tạo đọc màn hình: " + e.getClass().getSimpleName());
            main.postDelayed(this::stopSelf, 3000);
        }
    }

    /** One consented MediaProjection supplies BOTH OCR and video recording. */
    private void processLatestFrame(ImageReader imageReader, int width, int height) {
        Image img = null;
        Bitmap bitmap = null;
        try {
            img = imageReader.acquireLatestImage();
            if (img == null || shutdown) return;
            long now = SystemClock.elapsedRealtime();
            boolean scan = now - lastScan >= 850 && busy.compareAndSet(false, true);
            boolean record = recorder != null && recorder.isRecording();
            if (!scan && !record) return;
            if (scan) lastScan = now;
            Image.Plane plane = img.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int padding = plane.getRowStride() - plane.getPixelStride() * width;
            bitmap = Bitmap.createBitmap(width + padding / plane.getPixelStride(),
                height, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);
            Bitmap frame = Bitmap.createBitmap(bitmap, 0, 0, width, height);
            bitmap.recycle(); bitmap = null;
            if (record) {
                try {
                    recorder.addFrame(frame, now);
                    if (recorder.seemsBlack() && now-lastBlackWarning>12_000) {
                        lastBlackWarning=now;
                        showMessage("Video đang đen: TikTok/Android có thể chặn ghi hình");
                    }
                } catch (Exception e) {
                    String reason=e.getClass().getSimpleName();
                    recorder.discard();
                    activeRecording=false;
                    main.post(() -> updateRecordingUi("Quay không tương thích: "+reason));
                }
            }
            if (scan) {
                Task<Text> task = recognizer.process(InputImage.fromBitmap(frame, 0));
                task.addOnSuccessListener(text -> {
                    if (!shutdown) analyzeResult(ChestDetector.detect(text, frame,
                        prefs.getBoolean("chest_enabled",true),prefs.getBoolean("bag_enabled",true)));
                }).addOnFailureListener(e -> showMessage("OCR chưa đọc được: " + e.getMessage()))
                  .addOnCompleteListener(t -> { frame.recycle(); busy.set(false); });
            } else frame.recycle();
        } catch (Exception e) {
            busy.set(false);
        } finally {
            if (bitmap != null) bitmap.recycle();
            if (img != null) img.close();
        }
    }

    private void toggleRecording() {
        if (workerHandler == null) return;
        workerHandler.post(() -> {
            if (recorder!=null && recorder.isRecording()) stopRecordingInternal();
            else startRecordingInternal();
        });
    }

    private void startRecordingInternal() {
        if (shutdown || projection==null || recorder==null || recorder.isRecording()) return;
        try {
            recorder.start(captureWidth,captureHeight);
            activeRecording=true;
            main.post(() -> updateRecordingUi("Đang quay • 8 FPS • không thu âm thanh"));
        } catch(Exception e) {
            activeRecording=false;
            main.post(() -> updateRecordingUi("Không bắt đầu quay: "+e.getMessage()));
        }
    }

    private void stopRecordingInternal() {
        if (recorder==null || !recorder.isRecording()) return;
        try {
            String saved=recorder.stop();
            main.post(() -> updateRecordingUi(saved));
        } catch(Exception e) {
            main.post(() -> updateRecordingUi("Không lưu được MP4: "+e.getMessage()));
        } finally { activeRecording=false; }
    }

    private void updateRecordingUi(String message) {
        if (recordButton != null)
            recordButton.setText(activeRecording ? "■ Dừng quay" : "⏺ Quay LIVE");
        if (recordingLabel!=null) {
            recordingLabel.setText(activeRecording ? "● ĐANG QUAY MP4" : "○ Không quay");
            recordingLabel.setTextColor(activeRecording ? 0xffff6978 : 0xff80dcff);
        }
        refreshMode();
        if (message!=null) showMessage(message);
    }

    private void analyzeResult(ChestDetector.Result res) {
        if (paused || !licenseOk) { showMessage(!licenseOk ? "Đang kiểm tra quyền sử dụng…" : "Đang tạm dừng — chạm Tiếp tục"); return; }
        long now=SystemClock.elapsedRealtime();
        showMessage(res.summary);
        if(res.seconds!=null && res.kind!=ChestDetector.Kind.NONE){
            countdownLast=res.seconds;countdownReadAt=now;
            main.post(this::updateClock);
        }
        if (!TapAccessibilityService.isTikTokForeground()) return;

        if (res.kind==ChestDetector.Kind.NONE) {
            emptyStreak++;
            // OCR can miss a frame while an active modal/countdown is visible.
            // Never swipe away from a protected room.
            int wait=Math.max(5,Math.min(60,prefs.getInt("hunt_wait_secs",15)));
            if(prefs.getBoolean("auto_swipe",false) && emptyStreak>=6 &&
                swipes<20 && now-roomStart>=wait*1000L &&
                now-lastSwipe>=wait*1000L && now>protectedRoomUntil &&
                now-lastGiftSeenAt>=15000) {
                if (TapAccessibilityService.swipeToNextLive()) {
                    swipes++;lastSwipe=now;roomStart=now;emptyStreak=0;
                    countdownLast=-1;countdownReadAt=0;
                    prefs.edit().putInt("stat_swipes",prefs.getInt("stat_swipes",0)+1).apply();
                    logEvent("Chuyển LIVE sau "+wait+" giây không tìm thấy quà");
                    showMessage("Chưa thấy quà • LIVE khác ("+swipes+"/20)");
                }
            }
            return;
        }
        if(lastGiftSeenAt==0 || now-lastGiftSeenAt>4000) {
            prefs.edit().putInt("stat_detect",prefs.getInt("stat_detect",0)+1).apply();
            logEvent("Phát hiện "+res.summary);
        }
        lastGiftSeenAt=now;
        emptyStreak=0;
        // A detected countdown keeps the LIVE locked through its end + 15s.
        // Missing OCR frames must not close/swipe an active chest.
        if(res.seconds!=null) protectedRoomUntil=Math.max(protectedRoomUntil,
            now+Math.min(res.seconds,3600)*1000L+15000L);
        else protectedRoomUntil=Math.max(protectedRoomUntil,now+30000L);
        roomStart=now;
        // Only tap an icon if its OWN countdown was OCR-located and its color
        // matched a gift type, not based on an absolute blind coordinate.
        if (prefs.getBoolean("auto_open",false) && !res.modalOpen && res.icon!=null &&
            res.seconds!=null && now-lastOpen>30000) {
            int x=(int)res.icon.exactCenterX(), y=(int)res.icon.exactCenterY();
            if (TapAccessibilityService.tapOnce(x,y)) {
                lastOpen=now;
                protectedRoomUntil=Math.max(protectedRoomUntil,now+30000);
                logEvent("Thử mở biểu tượng: "+res.summary);
                showMessage("Đã thử mở biểu tượng "+res.summary);
            }
            return;
        }
        if (res.requirement != ChestDetector.Requirement.NONE) {
            String need=res.requirement==ChestDetector.Requirement.SHARE?"Chia sẻ → Sao chép liên kết":
                res.requirement==ChestDetector.Requirement.COMMENT?"Nhập bình luận → xác nhận gửi":
                "Tham gia Fan Club (thao tác thủ công)";
            showMessage("Túi quà yêu cầu: "+need);
            return; // No automatic sending, posts, purchases or joins.
        }
        if (res.seconds != null) {
            if (res.seconds>=8) { armed=true; lastLowCountdownAt=0; }
            if (res.seconds>0 && res.seconds<=5) {
                lastLowCountdownAt=now;
                if (now-lastAlert>25000) {
                    lastAlert=now;
                    NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
                    nm.notify(NOTIFICATION_ID,notification(res.summary+" — sắp mở"));
                    Vibrator vb=(Vibrator)getSystemService(VIBRATOR_SERVICE);
                    if (vb!=null && vb.hasVibrator()) vb.vibrate(VibrationEffect.createOneShot(180,
                        VibrationEffect.DEFAULT_AMPLITUDE));
                }
            }
        }
        if (!prefs.getBoolean("auto_tap",false) || res.claimButton==null || !res.modalOpen || !armed) return;
        boolean opensNow = res.seconds!=null && res.seconds==0 ||
            res.seconds==null && lastLowCountdownAt>0 && now-lastLowCountdownAt<5000;
        if (opensNow && now-lastTap>25000 && TapAccessibilityService.tapOnce(
            (int)res.claimButton.exactCenterX(),(int)res.claimButton.exactCenterY())) {
            armed=false;lastTap=now;
            protectedRoomUntil=Math.max(protectedRoomUntil,now+15000L);
            prefs.edit().putInt("stat_claims",prefs.getInt("stat_claims",0)+1).apply();
            logEvent("Thử chạm Nhận/Mở; chờ 15 giây sau kết quả");
            showMessage("Đã thử chạm Nhận/Mở • chờ 15 giây kiểm tra rương khác");
        }
    }

    private void createOverlay() {
        if (overlay != null) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(12));
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[] {0xee12102c, 0xee1b1845});
        shape.setCornerRadius(dp(18));
        shape.setStroke(dp(1), 0xffad61ff); panel.setBackground(shape);

        TextView heading = new TextView(this);
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView portrait = new ImageView(this);
        portrait.setImageResource(R.drawable.tuan_avatar);
        portrait.setContentDescription("Ảnh ĐIỂU TUẤN");
        titleRow.addView(portrait, new LinearLayout.LayoutParams(dp(34), dp(34)));
        heading.setText("  ĐIỂU TUẤN • TikXu ✦");
        heading.setTextSize(14); heading.setTypeface(null, Typeface.BOLD); heading.setTextColor(0xfff4eaff);
        titleRow.addView(heading);
        panel.addView(titleRow);
        messageView = new TextView(this);
        messageView.setText("Chuẩn bị quét màn hình…");
        messageView.setTextColor(0xffe2e8f0); messageView.setTextSize(12);
        panel.addView(messageView);
        countdownView = new TextView(this);
        countdownView.setText("--:--  •  Chưa tìm thấy rương");
        countdownView.setTextColor(0xff6af4e8);
        countdownView.setTextSize(20);
        countdownView.setTypeface(null,Typeface.BOLD);
        panel.addView(countdownView);
        main.postDelayed(this::clockTick,1000);
        modeView = new TextView(this);
        modeView.setTextSize(11); modeView.setTextColor(0xff93c5fd);
        panel.addView(modeView);
        recordingLabel = new TextView(this);
        recordingLabel.setTextSize(11);
        panel.addView(recordingLabel);
        refreshMode();
        TextView mini=overlayButton("▾ Thu nhỏ");
        miniView=mini;
        titleRow.addView(mini, new LinearLayout.LayoutParams(0, dp(34), 1));
        overlayActions=new LinearLayout(this);
        overlayActions.setOrientation(LinearLayout.VERTICAL);
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView chest=overlayButton("🪙 Nhặt rương");
        chest.setOnClickListener(v->{
            boolean enabled=!prefs.getBoolean("chest_enabled",true);
            prefs.edit().putBoolean("chest_enabled",enabled).apply(); refreshMode();
        });
        actions.addView(chest,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView bag=overlayButton("🎁 Nhặt túi");
        bag.setOnClickListener(v->{
            boolean enabled=!prefs.getBoolean("bag_enabled",true);
            prefs.edit().putBoolean("bag_enabled",enabled).apply(); refreshMode();
        });
        actions.addView(bag,new LinearLayout.LayoutParams(0,dp(42),1));
        overlayActions.addView(actions);
        LinearLayout control=new LinearLayout(this);
        control.setOrientation(LinearLayout.HORIZONTAL);
        TextView swipe=overlayButton("🔎 Săn room");
        swipe.setOnClickListener(v->{
            boolean enabled=!prefs.getBoolean("auto_swipe",false);
            prefs.edit().putBoolean("auto_swipe",enabled).apply();
            roomStart=SystemClock.elapsedRealtime(); emptyStreak=0; refreshMode();
        });
        control.addView(swipe,new LinearLayout.LayoutParams(0,dp(38),1));
        TextView pause=overlayButton("⏯ Dừng/Tiếp");
        pause.setOnClickListener(v->{ paused=!paused; refreshMode(); });
        control.addView(pause,new LinearLayout.LayoutParams(0,dp(38),1));
        TextView stop=overlayButton("✕");
        stop.setOnClickListener(v->stopSelf());
        control.addView(stop,new LinearLayout.LayoutParams(0,dp(38),0.35f));
        overlayActions.addView(control);
        recordButton=overlayButton("⏺ Quay LIVE");
        recordButton.setOnClickListener(v -> toggleRecording());
        LinearLayout.LayoutParams recParams = new LinearLayout.LayoutParams(-1, dp(39));
        recParams.topMargin=dp(5);
        overlayActions.addView(recordButton,recParams);
        panel.addView(overlayActions);
        updateRecordingUi(null);
        mini.setOnClickListener(v->{
            overlayCollapsed=!overlayCollapsed;
            mini.setText(overlayCollapsed?"▣ Mở rộng":"▾ Thu nhỏ");
            overlayActions.setVisibility(overlayCollapsed?View.GONE:View.VISIBLE);
            messageView.setVisibility(overlayCollapsed?View.GONE:View.VISIBLE);
            // Countdown remains visible in collapsed mode.
            modeView.setVisibility(overlayCollapsed?View.GONE:View.VISIBLE);
            recordingLabel.setVisibility(overlayCollapsed?View.GONE:View.VISIBLE);
            if(overlay!=null) windowManager.updateViewLayout(panel,overlayParams);
        });

        overlayParams = new WindowManager.LayoutParams(dp(310), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        // Start below TikTok's small gift icons; don't obscure the OCR target row.
        overlayParams.x = dp(18); overlayParams.y = dp(250);
        final int[] orig = {0,0}; final float[] down = {0,0};
        titleRow.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    orig[0] = overlayParams.x; orig[1] = overlayParams.y;
                    down[0] = e.getRawX(); down[1] = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    overlayParams.x = orig[0] + (int)(e.getRawX() - down[0]);
                    overlayParams.y = orig[1] + (int)(e.getRawY() - down[1]);
                    windowManager.updateViewLayout(panel, overlayParams);
                    return true;
            }
            return true;
        });
        try { windowManager.addView(panel, overlayParams); overlay = panel; }
        catch (Exception e) { /* overlay permission can be revoked by the user */ }
    }

    private void clockTick(){
        if(shutdown)return;
        updateClock();
        main.postDelayed(this::clockTick,1000);
    }
    private void updateClock(){
        if(countdownView==null)return;
        if(countdownLast<0){countdownView.setText("--:--  •  Đang tìm quà");return;}
        long elapsed=Math.max(0,(SystemClock.elapsedRealtime()-countdownReadAt)/1000);
        long left=Math.max(0,countdownLast-elapsed);
        boolean estimated=elapsed>3;
        countdownView.setText(String.format(java.util.Locale.US,"%02d:%02d",left/60,left%60)+
            (estimated?"  ≈ ước tính":"  ● đang đếm"));
        countdownView.setTextColor(estimated?0xffffcb84:0xff6af4e8);
    }

    private TextView overlayButton(String label) {
        TextView t = new TextView(this);
        t.setText(label); t.setTextColor(Color.WHITE); t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        GradientDrawable pill = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[] {0xff7843d6, 0xff2456b8});
        pill.setCornerRadius(dp(12));
        t.setBackground(pill);
        t.setPadding(dp(4), dp(2), dp(4), dp(2));
        return t;
    }

    private void refreshMode() {
        if (modeView == null) return;
        boolean enabled = prefs.getBoolean("auto_tap", false);
        modeView.setText("Rương:"+(prefs.getBoolean("chest_enabled",true)?"✓":"—")+
          "  Túi:"+(prefs.getBoolean("bag_enabled",true)?"✓":"—")+
          "  Săn:"+(prefs.getBoolean("auto_swipe",false)?"✓":"—")+
          "  Tự chạm:"+(enabled?"✓":"—")+
          "  Quay:"+(activeRecording?"●":"—")+(paused?" • TẠM DỪNG":""));
    }

    private void showMessage(String value) {
        main.post(() -> {
            if (messageView != null) messageView.setText(value);
        });
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    @Override public void onDestroy() {
        shutdown = true;
        activeCapture=false;
        if (recorder!=null && recorder.isRecording()) stopRecordingInternal();
        activeRecording=false;
        if (reader != null) { reader.setOnImageAvailableListener(null, null); reader.close(); reader = null; }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (projection != null) { projection.stop(); projection = null; }
        if (worker != null) { worker.quitSafely(); worker = null; }
        if (overlay != null) { windowManager.removeView(overlay); overlay = null; }
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}

package com.example.tikxu;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;

import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Records frames captured by CaptureService's EXISTING, consented MediaProjection.
 * No second MediaProjection or VirtualDisplay is created, avoiding recorder conflict.
 * Video only: no microphone/audio and no upload. Protected content remains black.
 * This experimental CPU YUV path is deliberately limited to 540px/8 fps.
 */
public final class LiveRecorder {
    private static final long FRAME_INTERVAL_MS = 125; // up to 8 fps, modest CPU
    private final Context context;
    private final ContentResolver resolver;
    private MediaCodec codec;
    private MediaMuxer muxer;
    private Uri videoUri;
    private ParcelFileDescriptor pfd;
    private File legacyOutput;
    private String savedName;
    private int w, h;
    private int track = -1;
    private boolean muxerStarted, recording;
    private long startMs, previousPtsUs, lastFrameMs;
    private int[] pixels;
    private int outputSamples;
    private int blankStreak;
    private boolean protectedImageLikely;
    private final MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();

    public LiveRecorder(Context context) {
        this.context = context.getApplicationContext();
        this.resolver = this.context.getContentResolver();
    }

    public synchronized boolean isRecording() { return recording; }
    public synchronized boolean seemsBlack() { return protectedImageLikely; }
    public synchronized String getFileName() { return savedName; }

    /** Must be called AFTER MediaProjection consent and initialization. */
    public synchronized void start(int sourceW, int sourceH) throws Exception {
        if (recording) return;
        if (sourceW <= 0 || sourceH <= 0) throw new IllegalArgumentException("Invalid dimensions");
        // Keep orientation/aspect, rounded to even YUV dimensions. Cap to ~540x960.
        float scale = Math.min(1f, Math.min(540f / sourceW, 960f / sourceH));
        w = Math.max(2, (int)(sourceW * scale) & ~1);
        h = Math.max(2, (int)(sourceH * scale) & ~1);
        pixels = new int[w * h];
        startMs = SystemClock.elapsedRealtime();
        previousPtsUs = -1;
        lastFrameMs = 0;
        outputSamples = 0;
        blankStreak = 0;
        protectedImageLikely = false;
        savedName = "TikXu_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
            .format(new Date()) + ".mp4";
        try {
            MediaFormat format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);
            format.setInteger(MediaFormat.KEY_FRAME_RATE, 8);
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
            format.setInteger(MediaFormat.KEY_BIT_RATE, Math.max(550_000, w * h * 2));
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            codec.start();
            createDestination();
            recording = true;
        } catch (Exception ex) {
            discard();
            throw ex;
        }
    }

    private void createDestination() throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, savedName);
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TikXu");
            cv.put(MediaStore.Video.Media.IS_PENDING, 1);
            videoUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
            if (videoUri == null) throw new IllegalStateException("Cannot create Movies/TikXu item");
            pfd = resolver.openFileDescriptor(videoUri, "w");
            if (pfd == null) throw new IllegalStateException("Cannot open video file");
            muxer = new MediaMuxer(pfd.getFileDescriptor(),
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        } else {
            File dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            if (dir == null) throw new IllegalStateException("Movies directory not available");
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create video directory");
            legacyOutput = new File(dir, savedName);
            muxer = new MediaMuxer(legacyOutput.getAbsolutePath(),
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        }
    }

    public synchronized void addFrame(Bitmap fullFrame, long atMs) throws Exception {
        if (!recording || atMs - lastFrameMs < FRAME_INTERVAL_MS) return;
        lastFrameMs = atMs;
        Bitmap scaled = Bitmap.createScaledBitmap(fullFrame, w, h, false);
        try { scaled.getPixels(pixels, 0, w, 0, 0, w, h); }
        finally { if (scaled != fullFrame) scaled.recycle(); }
        inspectBlack();
        drain(false);
        int index = codec.dequeueInputBuffer(0);
        if (index < 0) return; // skip frame rather than stall OCR/live overlay
        Image input = codec.getInputImage(index);
        if (input == null) throw new IllegalStateException("Encoder does not support image input");
        try { convertToYuv420(input); }
        finally { input.close(); }
        long pts = Math.max(previousPtsUs + 1, (atMs - startMs) * 1000);
        previousPtsUs = pts;
        codec.queueInputBuffer(index, 0, w * h * 3 / 2, pts, 0);
        drain(false);
    }

    // A pitch-black image suggests protected content; a dark LIVE does not
    // necessarily mean protected. Warn only on very consistent near-black.
    private void inspectBlack() {
        int nearBlack=0, samples=0;
        for (int i=0; i<pixels.length; i+=Math.max(1,pixels.length/400)) {
            int p=pixels[i];
            if (((p>>16)&255)<9 && ((p>>8)&255)<9 && (p&255)<9) nearBlack++;
            samples++;
        }
        blankStreak = nearBlack > samples*0.98f ? blankStreak+1 : 0;
        if (blankStreak>=18) protectedImageLikely=true;
    }

    private static byte clamp(int val) { return (byte)Math.max(0,Math.min(255,val)); }
    private void convertToYuv420(Image image) {
        Image.Plane[] planes=image.getPlanes();
        if (planes.length < 3) throw new IllegalStateException("YUV input planes missing");
        ByteBuffer yy=planes[0].getBuffer(), uu=planes[1].getBuffer(), vv=planes[2].getBuffer();
        int ry=planes[0].getRowStride(), py=planes[0].getPixelStride();
        int ru=planes[1].getRowStride(), pu=planes[1].getPixelStride();
        int rv=planes[2].getRowStride(), pv=planes[2].getPixelStride();
        for (int y=0;y<h;y+=2) {
            for (int x=0;x<w;x+=2) {
                int ur=0, vr=0;
                for(int dy=0;dy<2;dy++) for(int dx=0;dx<2;dx++) {
                    int p=pixels[(y+dy)*w+x+dx];
                    int r=(p>>16)&255,g=(p>>8)&255,b=p&255;
                    int luminance=((66*r+129*g+25*b+128)>>8)+16;
                    yy.put((y+dy)*ry+(x+dx)*py,clamp(luminance));
                    ur+=((-38*r-74*g+112*b+128)>>8)+128;
                    vr+=((112*r-94*g-18*b+128)>>8)+128;
                }
                uu.put((y/2)*ru+(x/2)*pu,clamp(ur/4));
                vv.put((y/2)*rv+(x/2)*pv,clamp(vr/4));
            }
        }
    }

    private void drain(boolean finish) {
        if (codec==null) return;
        int idle=0;
        while (true) {
            int id = codec.dequeueOutputBuffer(bufferInfo, finish?10_000:0);
            if (id==MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!finish || ++idle>=20) break;
                continue;
            }
            if (id==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (muxerStarted) throw new IllegalStateException("Output changed twice");
                track = muxer.addTrack(codec.getOutputFormat());
                muxer.start(); muxerStarted=true;
                continue;
            }
            if (id<0) continue;
            ByteBuffer data=codec.getOutputBuffer(id);
            if (data != null && muxerStarted && bufferInfo.size>0 &&
                (bufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0) {
                data.position(bufferInfo.offset);
                data.limit(bufferInfo.offset+bufferInfo.size);
                muxer.writeSampleData(track,data,bufferInfo);
                outputSamples++;
            }
            boolean eos=(bufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
            codec.releaseOutputBuffer(id,false);
            if (eos) break;
        }
    }

    /** Finish MP4 in Gallery's Movies/TikXu on Android 10+. */
    public synchronized String stop() throws Exception {
        if (!recording) return "Chưa bắt đầu quay";
        recording = false;
        Exception problem=null;
        try {
            int in = codec.dequeueInputBuffer(100_000);
            if (in>=0) codec.queueInputBuffer(in,0,0,Math.max(0,previousPtsUs+1),
                MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            drain(true);
            if (!muxerStarted || outputSamples==0)
                throw new IllegalStateException("Không có khung hình video để lưu");
            muxer.stop();
        } catch (Exception e) { problem=e; }
        finally {
            releaseEncoder();
            if (problem==null && videoUri!=null && Build.VERSION.SDK_INT>=29) {
                ContentValues ready=new ContentValues();
                ready.put(MediaStore.Video.Media.IS_PENDING,0);
                resolver.update(videoUri,ready,null,null);
            }
            if (problem!=null) cleanupFailedFile();
        }
        if (problem!=null) throw problem;
        videoUri=null; // Saved video must never be deleted by a later failed session.
        legacyOutput=null;
        return "Đã lưu vào Video/Movies/TikXu: " + savedName;
    }

    public synchronized void discard() {
        recording = false;
        releaseEncoder();
        cleanupFailedFile();
    }

    private void releaseEncoder() {
        if (codec!=null) {
            try { codec.stop(); } catch(Exception ignored) {}
            try { codec.release(); } catch(Exception ignored) {}
            codec=null;
        }
        if (muxer!=null) {
            try { muxer.release(); } catch(Exception ignored) {}
            muxer=null;
        }
        try { if (pfd!=null) pfd.close(); } catch(Exception ignored) {}
        pfd=null;
        muxerStarted=false;
    }

    private void cleanupFailedFile() {
        if (videoUri!=null) {
            try { resolver.delete(videoUri,null,null); } catch(Exception ignored) {}
            videoUri=null;
        }
        if (legacyOutput!=null) {
            try { legacyOutput.delete(); } catch(Exception ignored) {}
            legacyOutput=null;
        }
    }
}

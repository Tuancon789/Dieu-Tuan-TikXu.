# ĐIỂU TUẤN • TikXu v3.2 — đăng nhập tài khoản & quản trị

## Trạng thái (cần đọc trước)

Đây là **mã nguồn Android + máy chủ xác thực Cloudflare Workers/D1**, chưa phải APK đã biên dịch hoặc dịch vụ máy chủ đã chạy trên Internet. Mật khẩu ADMIN **không** nằm trong ZIP/APK/GitHub. Muốn dùng tài khoản trên nhiều điện thoại: phải triển khai Worker/D1 và thiết lập bí mật `ADMIN_PASSWORD` trước. Không có máy chủ → màn hình đăng nhập sẽ báo chưa cấu hình HTTPS; không có đường vòng mở khóa offline.

Tên đăng nhập quản trị: `ADM`. Mật khẩu quản trị là giá trị chủ app tự nhập ở bước `wrangler secret put ADMIN_PASSWORD` (dùng mật khẩu ADMIN đã tự chọn trong cuộc trò chuyện, không ghi mật khẩu vào GitHub). Mật khẩu này có thể thay đổi sau này bằng cách đặt lại Cloudflare secret. Khi nhập mật khẩu, ký tự được che bằng dấu chấm.

## Có trong mã nguồn Android v3.2

- Đăng nhập **tên người dùng + mật khẩu** qua HTTPS; backend xác định vai trò ADMIN/USER và ngày hết hạn; **không dùng mật khẩu offline cũ**.
- Tài khoản thường mặc định **45 ngày tính từ lúc tạo**, tự chặn khi hết hạn; ngày hết hạn hiển thị trong app, tính trên máy chủ chứ không theo giờ điện thoại.
- **Admin Center** riêng (người dùng USER không thấy nút): tạo user, danh sách người dùng, gia hạn số ngày nhập tùy ý, khóa/mở khóa, thay mật khẩu người dùng.
- Admin Center: chỉnh thời gian chờ room 15/30/60 giây, xem thống kê và nhật ký trên thiết bị, gửi thông báo khi ứng dụng kiểm tra phiên, nút dừng khẩn cấp, bật/tắt hiệu ứng neon.
- Backend đảm bảo API quản trị chỉ nhận phiên ADMIN, không chỉ dựa vào việc ẩn nút giao diện.
- Phiên đăng nhập do server cấp, mã thông báo phiên được mã hóa bằng Android Keystore trong app. ADMIN phiên 12 giờ, USER 24 giờ; khi hết phiên đăng nhập lại.
- Ứng dụng đối chiếu trạng thái với server trước khi quét và mỗi 60 giây trong khi quét. Hết hạn, khóa, mất kết nối hoặc ADMIN tạm dừng → dừng quét. Thao tác từ xa không tức thì; có độ trễ tối đa khoảng 60 giây trong phiên quét bình thường.
- Bảng nổi hiển thị giờ rương/túi đang đếm (đánh dấu ≈ ước tính nếu OCR bị hụt); khi thu nhỏ vẫn xem được giờ; mặc định giữ room 15 giây khi không thấy quà, bảo vệ room khi có đồng hồ và chờ thêm sau khi thử nhận.
- Giữ ảnh nền và avatar, chế độ quay màn hình thử nghiệm, nút Nhặt rương/Nhặt túi, nút TikTok chủ app.

## Chức năng có giới hạn

- **Thông báo ADMIN:** chỉ được đọc khi người dùng đăng nhập hoặc khi app đang kiểm tra phiên. Đây **chưa phải push notification** tới thiết bị đang offline.
- **Thống kê / nhật ký:** số thao tác thử nhận và quét trên **thiết bị ADMIN đó**, không phải tổng xu thực nhận hoặc thống kê mọi máy. Backend hiện chỉ quản lý tài khoản và trạng thái.
- **Tùy chỉnh giao diện:** bật/tắt lớp neon tối, chưa phải trình chỉnh ảnh/màu tùy ý.
- **Dừng khẩn cấp:** thiết bị nhận ở lần kiểm tra `/v1/me` tiếp theo, không tức thì. Người dùng có thể tự gỡ app, vì vậy không phải hệ thống khóa thiết bị.
- Quét hình ảnh, tự mở rương, tự chạm và ghi hình vẫn **chưa được kiểm thử trên TikTok LIVE thực tế**. TikTok có thể thay đổi giao diện/chặn tự động hóa hoặc ghi hình. Không tự động đăng bình luận, gửi link, tham gia Fan Club, tặng quà, hoặc nạp xu. Không tắt Play Protect để ép cài đặt nếu có cảnh báo.
- **Gmail đổi mã 00:00 đã loại bỏ** theo yêu cầu mới: dùng tài khoản đăng nhập và hạn dùng, ADMIN gia hạn thủ công.

## 1. Tạo backend Cloudflare (bắt buộc để đăng nhập được)

Bạn cần tài khoản Cloudflare và một máy có Node.js 20+ cài được `npm`/`npx` (có thể dùng GitHub Codespaces thay vì máy tính cá nhân). Mở thư mục `TikXuAssist/server/`:

```bash
npm install
npx wrangler login
npx wrangler d1 create tikxu-users
```

Lệnh tạo D1 trả về `database_id`. Điền ID đó vào `server/wrangler.toml`, thay `REPLACE_WITH_YOUR_D1_DATABASE_ID`.

```bash
npx wrangler d1 migrations apply tikxu-users --remote
npx wrangler secret put ADMIN_PASSWORD
npx wrangler deploy
```

Khi được hỏi ở lệnh `secret put`, **tự nhập mật khẩu ADMIN của mình trong terminal**. Không chép mật khẩu vào mã nguồn, workflow GitHub, URL hay ảnh chụp gửi người khác. Sau `deploy`, Cloudflare trả ra địa chỉ HTTPS dạng `https://dieutuan-tikxu-auth.<subdomain>.workers.dev`.

**Không dùng mật khẩu ADMIN đơn giản lâu dài** nếu mở server ra Internet. Nên thay thành mật khẩu dài độc nhất, giữ kín tài khoản Cloudflare và bật bảo mật 2 lớp ở Cloudflare. Để bảo vệ việc đăng nhập, server dùng PBKDF2-SHA256 (salt khác nhau mỗi user), giới hạn lần thử trong cửa sổ 10 phút, token phiên ngẫu nhiên được băm trong DB, và kiểm tra quyền ở mỗi API. Đây vẫn chỉ là hệ thống mẫu cần đánh giá bảo mật trước khi phân phối công khai.

## 2. Xuất APK v3.2 bằng GitHub Actions

File gói dự án có dạng `TikXuAssist/...`. Tải lên kho GitHub file `Dieu_Tuan_TikXu_v3_2_Source.zip` (không giải nén). Giữ workflow v3.1 từng Build thành công và đổi bước giải nén thành:

```yaml
- name: Extract source
  run: |
    unzip -q Dieu_Tuan_TikXu_v3_2_Source.zip
    test -f TikXuAssist/app/build.gradle
```

Trong workflow mẫu có thể thêm biến cấu hình API:

```yaml
- name: Build debug APK
  working-directory: TikXuAssist
  env:
    TIKXU_API_URL: ${{ vars.TIKXU_API_URL }}
  run: gradle --no-daemon :app:assembleDebug
```

Tạo repo variable `TIKXU_API_URL` chứa địa chỉ Worker HTTPS. Nếu chưa đặt biến, người dùng vẫn có thể nhập địa chỉ máy chủ HTTPS ngay trên màn hình đăng nhập Android. Không lưu khóa/mật khẩu ADMIN trong repo variable, mã Android hoặc mã GitHub công khai.

Vào Actions → Run workflow; nếu thành công tải Artifact `DIEU-TUAN-TikXu-v3.2-APK`, giải nén rồi cài `app-debug.apk`. **Chưa kiểm thử Build v3.2 trên GitHub hoặc trên thiết bị thật trong gói này.**

## 3. Sử dụng ADMIN / USER

1. Nhập URL Worker HTTPS trong app, nhập tài khoản `ADM` và mật khẩu ADMIN đã khai báo bằng secret để đăng nhập.
2. Chọn **QUẢN TRỊ ADMIN • TÀI KHOẢN** → nhập username, mật khẩu user (ít nhất 8 ký tự), mặc định 45 ngày → **TẠO TÀI KHOẢN**.
3. Chọn **TẢI DANH SÁCH** → **+ GIA HẠN**, **KHÓA** hoặc **MỞ KHÓA**, **ĐỔI MẬT KHẨU USER**.
4. Trên điện thoại khác, cài APK, nhập cùng địa chỉ Worker, username và password user → đăng nhập; chức năng quản trị không hiển thị.
5. Muốn thay đổi hạn: vào ADMIN chọn user, nhập số ngày, bấm **Gia hạn**. Hệ thống cộng ngày từ ngày hết hạn hiện tại nếu còn hạn; nếu đã hết, cộng từ thời điểm hiện tại.

Không gửi mật khẩu ADMIN, mã đăng nhập user hoặc token phiên lên chat. Hạn dùng và quyền vai trò được kiểm tra trên server, nhưng người có quyền hệ thống ở điện thoại vẫn có thể gỡ APK hoặc chỉnh sửa một phiên bản mã nguồn công khai; đừng coi app như công cụ bảo vệ dữ liệu ngân hàng.

## Thử nghiệm backend

```bash
cd server
node --test tests/auth.test.mjs
```

Bài kiểm tra có backend giả lập D1 để kiểm tra: đăng nhập ADMIN, tạo user 45 ngày, chặn USER dùng API ADMIN, gia hạn và khóa user. Việc này **không thay thế kiểm thử trên Cloudflare thật hoặc Android thật**.

# ĐIỂU TUẤN • TikXu — Portrait beta v0.2

Bản mã nguồn Android đã nâng cấp giao diện với **ảnh gốc của chủ app** làm nền màn hình đăng nhập và màn hình điều khiển. Bảng nổi có ảnh đại diện và viền tím-xanh; mật khẩu nhập bằng trường **che ký tự (••••)**, không bao giờ hiển thị nội dung đã nhập trên màn hình. Mật khẩu được đối chiếu với một chuỗi băm trong mã, không cần đăng nhập TikTok. Tuy nhiên, khóa offline nhúng trong APK không thể bảo mật tuyệt đối trước người có kỹ năng phân tích APK.

## Tình trạng tính năng

- Đã tích hợp: nền ảnh thật, avatar, giao diện tối/neon, màn hình đăng nhập che ký tự; OCR cũ và bảng nổi.
- Chưa xác nhận: nhận diện biểu tượng chưa mở, phân biệt đầy đủ Rương Báu / Túi quà và thao tác bấm nhận chuẩn theo nhiều giao diện TikTok. Nút tự mở trên dashboard hiện là thử nghiệm và **không đồng nghĩa tính năng đã hoạt động**.
- Chế độ tự bấm đang mặc định TẮT và có thể bị TikTok giới hạn. Không tự bấm nút Gửi/Nạp, không tự bình luận, chia sẻ hoặc tham gia Fan Club.
- Không có quyền INTERNET; OCR được xử lý trong máy và không tải hình màn hình lên máy chủ.

## Xuất APK bằng GitHub Actions

1. Chỉ tải ảnh cá nhân lên kho GitHub **RIÊNG TƯ** nếu không muốn người khác tải ảnh, vì mã nguồn bản này chứa ảnh của chủ app. Kho Public sẽ công khai cả ảnh.
2. Tải file ZIP này lên repository GitHub, ví dụ `Dieu_Tuan_TikXu_Portrait_v2_Source.zip`.
3. Giữ workflow tại `.github/workflows/build-apk.yml` (bên cạnh ZIP ở repository). Sử dụng `actions/setup-java@v4`, `android-actions/setup-android@v4`, `gradle/actions/setup-gradle@v4` và Gradle 8.9.
4. Workflow giải nén ZIP rồi chạy `gradle :app:assembleDebug` trong thư mục dự án.
5. Tải artifact APK (ZIP) từ Actions, giải nén và cài file `app-debug.apk` trên Android.

Đây là **mã nguồn chưa được biên dịch/kiểm thử trong môi trường này**, chưa phải bản APK hoàn thiện.

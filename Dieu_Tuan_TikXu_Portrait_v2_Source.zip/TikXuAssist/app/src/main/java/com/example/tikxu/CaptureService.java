package com.example.tikxu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;


import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Prototype: OCR stays on this phone, never uploads screen images. */
public class CaptureService extends Service {
    public static final String ACTION_START = "com.example.tikxu.START";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";
    private static final String CHANNEL = "tikxu_detection";
    private static final int NOTIFICATION_ID = 77;

    private WindowManager windowManager;
    private WindowManager.LayoutParams overlayParams;
    private View overlay;
    private TextView messageView;
    private TextView modeView;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private HandlerThread worker;
    private Handler workerHandler;
    private final Handler main = new Handler(android.os.Looper.getMainLooper());
    private TextRecognizer recognizer;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private volatile boolean shutdown;
    private long lastScan;
    private long lastAlert;
    private long lastTap;
    private long lastLowCountdownAt;
    private boolean armed = true;
    private SharedPreferences prefs;

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("tikxu", MODE_PRIVATE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Nhận diện rương xu",
            NotificationManager.IMPORTANCE_DEFAULT));
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;
        if (projection != null) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }
        if (resultCode != android.app.Activity.RESULT_OK || data == null) {
            stopSelf(); return START_NOT_STICKY;
        }
        Notification notification = notification("Đang theo dõi màn hình, chạm để mở ứng dụng");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else startForeground(NOTIFICATION_ID, notification);
        createOverlay();
        initializeProjection(resultCode, data);
        return START_NOT_STICKY;
    }

    private Notification notification(String message) {
        Intent openApp = new Intent(this, MainActivity.class);
        PendingIntent open = PendingIntent.getActivity(this, 0, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("ĐIỂU TUẤN • TikXu")
            .setContentText(message)
            .setContentIntent(open)
            .setOngoing(true)
            .build();
    }

    private void initializeProjection(int resultCode, Intent data) {
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        try {
            projection = manager.getMediaProjection(resultCode, data);
            if (projection == null) throw new IllegalStateException("No projection");
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { main.post(() -> stopSelf()); }
            }, main);
            DisplayMetrics metrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            int width = metrics.widthPixels;
            int height = metrics.heightPixels;
            worker = new HandlerThread("TikXu-OCR"); worker.start();
            workerHandler = new Handler(worker.getLooper());
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(r -> processLatestFrame(r, width, height), workerHandler);
            virtualDisplay = projection.createVirtualDisplay("TikXuScreen", width, height,
                metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, workerHandler);
            showMessage("Đang tìm rương xu trên TikTok LIVE…");
        } catch (Exception e) {
            showMessage("Không thể khởi tạo đọc màn hình: " + e.getClass().getSimpleName());
            main.postDelayed(this::stopSelf, 3000);
        }
    }

    private void processLatestFrame(ImageReader imageReader, int width, int height) {
        Image img = null;
        Bitmap bitmap = null;
        try {
            img = imageReader.acquireLatestImage();
            if (img == null || shutdown) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastScan < 850 || !busy.compareAndSet(false, true)) return;
            lastScan = now;
            Image.Plane plane = img.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int padding = plane.getRowStride() - plane.getPixelStride() * width;
            bitmap = Bitmap.createBitmap(width + padding / plane.getPixelStride(),
                height, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);
            Bitmap frame = Bitmap.createBitmap(bitmap, 0, 0, width, height);
            bitmap.recycle(); bitmap = null;
            Task<Text> task = recognizer.process(InputImage.fromBitmap(frame, 0));
            task.addOnSuccessListener(text -> {
                if (!shutdown) analyzeResult(ChestDetector.detect(text, width, height));
            }).addOnFailureListener(e -> showMessage("OCR chưa đọc được: " + e.getMessage()))
              .addOnCompleteListener(t -> { frame.recycle(); busy.set(false); });
        } catch (Exception e) {
            busy.set(false);
        } finally {
            if (bitmap != null) bitmap.recycle();
            if (img != null) img.close();
        }
    }

    private void analyzeResult(ChestDetector.Result res) {
        showMessage(res.summary);
        if (!res.chestVisible) return;
        if (res.seconds != null) {
            if (res.seconds >= 8) { armed = true; lastLowCountdownAt = 0; } // new chest
            if (res.seconds > 0 && res.seconds <= 5) lastLowCountdownAt = SystemClock.elapsedRealtime();
            if (res.seconds > 0 && res.seconds <= 5) {
                long now = SystemClock.elapsedRealtime();
                if (now - lastAlert > 25000) {
                    lastAlert = now;
                    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                    Notification n = notification("Rương xu còn khoảng " + res.seconds + " giây (ước lượng)");
                    nm.notify(NOTIFICATION_ID, n);
                    Vibrator vibrator = (Vibrator)getSystemService(VIBRATOR_SERVICE);
                    if (vibrator != null && vibrator.hasVibrator()) {
                        if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(220,
                            VibrationEffect.DEFAULT_AMPLITUDE));
                        else vibrator.vibrate(220);
                    }
                }
            }
        }
        if (!prefs.getBoolean("auto_tap", false) || res.claimButton == null || !armed) return;
        // Either see 00:00, or see the claim button shortly after an observed
        // 1–5 second countdown disappears. Never tap while a positive timer is present.
        long now = SystemClock.elapsedRealtime();
        boolean justOpened = (res.seconds != null && res.seconds == 0) ||
            (res.seconds == null && lastLowCountdownAt > 0 && now - lastLowCountdownAt < 6500);
        if (!justOpened || !TapAccessibilityService.isTikTokForeground()) return;
        if (now - lastTap < 25000) return;
        boolean sent = TapAccessibilityService.tapOnce((int)res.claimButton.exactCenterX(),
            (int)res.claimButton.exactCenterY());
        if (sent) {
            armed = false;
            lastTap = now;
            showMessage("Đã thử bấm 1 lần. Không đảm bảo nhận được xu.");
        }
    }

    private void createOverlay() {
        if (overlay != null) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(12));
        GradientDrawable shape = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[] {0xee12102c, 0xee1b1845});
        shape.setCornerRadius(dp(18));
        shape.setStroke(dp(1), 0xffad61ff); panel.setBackground(shape);

        TextView heading = new TextView(this);
        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        ImageView portrait = new ImageView(this);
        portrait.setImageResource(R.drawable.tuan_avatar);
        portrait.setContentDescription("Ảnh ĐIỂU TUẤN");
        titleRow.addView(portrait, new LinearLayout.LayoutParams(dp(34), dp(34)));
        heading.setText("  ĐIỂU TUẤN • TikXu ✦");
        heading.setTextSize(14); heading.setTypeface(null, Typeface.BOLD); heading.setTextColor(0xfff4eaff);
        titleRow.addView(heading);
        panel.addView(titleRow);
        messageView = new TextView(this);
        messageView.setText("Chuẩn bị quét màn hình…");
        messageView.setTextColor(0xffe2e8f0); messageView.setTextSize(12);
        panel.addView(messageView);
        modeView = new TextView(this);
        modeView.setTextSize(11); modeView.setTextColor(0xff93c5fd);
        panel.addView(modeView);
        refreshMode();
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView toggle = overlayButton("Đổi chế độ");
        toggle.setOnClickListener(v -> {
            boolean enabled = !prefs.getBoolean("auto_tap", false);
            prefs.edit().putBoolean("auto_tap", enabled).apply();
            refreshMode();
        });
        actions.addView(toggle, new LinearLayout.LayoutParams(0, dp(37), 1));
        TextView stop = overlayButton("Dừng");
        stop.setOnClickListener(v -> stopSelf());
        actions.addView(stop, new LinearLayout.LayoutParams(0, dp(37), 1));
        panel.addView(actions);

        overlayParams = new WindowManager.LayoutParams(dp(260), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.START;
        overlayParams.x = dp(18); overlayParams.y = dp(115);
        final int[] orig = {0,0}; final float[] down = {0,0};
        titleRow.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    orig[0] = overlayParams.x; orig[1] = overlayParams.y;
                    down[0] = e.getRawX(); down[1] = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    overlayParams.x = orig[0] + (int)(e.getRawX() - down[0]);
                    overlayParams.y = orig[1] + (int)(e.getRawY() - down[1]);
                    windowManager.updateViewLayout(panel, overlayParams);
                    return true;
            }
            return true;
        });
        try { windowManager.addView(panel, overlayParams); overlay = panel; }
        catch (Exception e) { /* overlay permission can be revoked by the user */ }
    }

    private TextView overlayButton(String label) {
        TextView t = new TextView(this);
        t.setText(label); t.setTextColor(Color.WHITE); t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        GradientDrawable pill = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[] {0xff7843d6, 0xff2456b8});
        pill.setCornerRadius(dp(12));
        t.setBackground(pill);
        t.setPadding(dp(4), dp(2), dp(4), dp(2));
        return t;
    }

    private void refreshMode() {
        if (modeView == null) return;
        boolean enabled = prefs.getBoolean("auto_tap", false);
        modeView.setText(enabled ? "Tự bấm thử: BẬT • rủi ro tài khoản" : "Tự bấm thử: TẮT • chỉ cảnh báo");
    }

    private void showMessage(String value) {
        main.post(() -> {
            if (messageView != null) messageView.setText(value);
        });
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    @Override public void onDestroy() {
        shutdown = true;
        if (reader != null) { reader.setOnImageAvailableListener(null, null); reader.close(); reader = null; }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (projection != null) { projection.stop(); projection = null; }
        if (worker != null) { worker.quitSafely(); worker = null; }
        if (overlay != null) { windowManager.removeView(overlay); overlay = null; }
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
